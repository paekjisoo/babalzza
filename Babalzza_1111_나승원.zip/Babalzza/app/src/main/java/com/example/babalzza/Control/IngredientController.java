package com.example.babalzza.Control;

import android.content.Context;

import com.example.babalzza.Boundary.IngredientManageForm;
import com.example.babalzza.Entity.IngredientDatabase;
import com.example.babalzza.Entity.Ingredient;

import java.util.ArrayList;

import static com.example.babalzza.Boundary.IngredientManageForm.adapter;
import static com.example.babalzza.Boundary.IngredientManageForm.ingredientList;
import static com.example.babalzza.Boundary.IngredientManageForm.myIngredients;

public class IngredientController {
    /*
    public static void addIngredient(String name, Integer quantity, String duedate) {
        Ingredient ingredient = new Ingredient("",0,"");

        ingredient.setName(name);
        ingredient.setQuantity(quantity);
        ingredient.setDueDate(duedate);

        ingredient.saveIngredient(ingredient);
    }
     */

    public static void addIngredient(IngredientDatabase ingredientDatabase, Context context, String name, Integer quantity, String duedate) {
        ingredientDatabase.InsertData(name, quantity, duedate);
        ingredientList = ingredientDatabase.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    /*
    public void addIngredient(DatabaseController dbController, Context context, String name, Integer quantity, String duedate) {
        dbController.InsertData(name, quantity, duedate);
        ingredientList = dbController.getAllIngredients();
        adapter = new IngredientListAdapter(context, ingredientList);
        gridvsample.setAdapter(adapter);
    }
     */

    public static void readIngredient(ArrayList<Ingredient> IngredientList) {
        //Ingredient.showIngredient(IngredientList);
    }
}
