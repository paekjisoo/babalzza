package com.example.test_ingredient.Entity;

import java.io.Serializable;

public class UserIngredient implements Serializable {
    private Integer userigd_id;
    private Integer user_id;
    private Integer igd_id;
    private Integer amount;
    private Integer reservedamount;
    private String buydate;
    private String expirationdate;

    public UserIngredient(){}
    public UserIngredient(Integer userigd_id, Integer user_id, Integer igd_id, Integer amount, Integer reservedamount, String buydate, String expirationdate) {
        this.userigd_id = userigd_id;
        this.user_id = user_id;
        this.igd_id = igd_id;
        this.amount = amount;
        this.reservedamount = reservedamount;
        this.buydate = buydate;
        this.expirationdate = expirationdate;
    }

    public Integer getUserigd_id() {
        return userigd_id;
    }

    public void setUserigd_id(Integer userigd_id) {
        this.userigd_id = userigd_id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getIgd_id() {
        return igd_id;
    }

    public void setIgd_id(Integer igd_id) {
        this.igd_id = igd_id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getReservedamount() {
        return reservedamount;
    }

    public void setReservedamount(Integer reservedamount) {
        this.reservedamount = reservedamount;
    }

    public String getBuydate() {
        return buydate;
    }

    public void setBuydate(String buydate) {
        this.buydate = buydate;
    }

    public String getExpirationdate() {
        return expirationdate;
    }

    public void setExpirationdate(String expirationdate) {
        this.expirationdate = expirationdate;
    }
}
