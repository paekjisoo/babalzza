package com.example.test_ingredient.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test_ingredient.Controller.IngredientController;
import com.example.test_ingredient.Entity.Ingredient;
import com.example.test_ingredient.R;
import com.example.test_ingredient.Entity.UserIngredient;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.util.ArrayList;

public class UserIngredient_Activity extends AppCompatActivity {

    private IngredientController ingredientController;
    private ArrayList<UserIngredient> userIngredientList;
    private ArrayList<Ingredient> ingredientList;
    private UserIngredientAdaper adapter;
    private int gridItemId;

    FloatingActionButton fab;
    GridView userigd_gv;
    AlertDialog.Builder builder;
    AlertDialog dialog;

    TextView tv_name;
    TextView tv_type;

    TextView tv_amount;
    TextView tv_buydate;
    TextView tv_expdate;
    TextView tv_textamount;
    TextView tv_textbuydate;
    TextView tv_textexpdate;

    EditText edit_amount;
    EditText edit_buydate;
    EditText edit_expdate;

    Button btn_addMemo;
    Button btn_saveupdate;
    Button btn_updateigd;
    Button btn_deleteigd;

    SharedPreferences csvload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_main);

        csvload = getSharedPreferences("is_csv_loaded", Activity.MODE_PRIVATE);
        ingredientController = new IngredientController(this);

        String result = csvload.getString("is_csv_loaded", "");
        if (result==""){
            ingredientController.csvToDB_Ingredient(this);
            ingredientController.csvToDB_UserIngredient(this);
            SharedPreferences.Editor editor = csvload.edit();
            editor.putString("is_csv_loaded", "done");
            editor.commit();
        }

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        userigd_gv = (GridView)findViewById(R.id.userigd_gv);

        userIngredientList = ingredientController.getAllUserIngredients();
        ingredientList = ingredientController.getAllingredients();

        adapter = new UserIngredientAdaper(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addintent = new Intent(UserIngredient_Activity.this, AddUserIngredient_Activity.class);
                UserIngredient_Activity.this.startActivity(addintent);
            }
        });

        // gridview 아이템 클릭 효과 선언
        userigd_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                gridItemId = position;
                final View popup = inflater_dg.inflate(R.layout.userigd_detail, null);

                tv_name= popup.findViewById(R.id.detail_name);
                tv_type= popup.findViewById(R.id.detail_type);

                tv_amount= popup.findViewById(R.id.detail_amount);
                tv_buydate= popup.findViewById(R.id.detail_buydate);
                tv_expdate= popup.findViewById(R.id.detail_expdate);
                tv_textamount= popup.findViewById(R.id.textAmount);
                tv_textbuydate= popup.findViewById(R.id.textBuydate);
                tv_textexpdate= popup.findViewById(R.id.textExpdate);

                edit_amount = popup.findViewById(R.id.editAmount);
                edit_buydate = popup.findViewById(R.id.editBuydate);
                edit_expdate = popup.findViewById(R.id.editExpirationDate);

                Integer index_igd = userIngredientList.get(position).getIgd_id();
                tv_name.setText(ingredientList.get(index_igd).getName());
                tv_type.setText(ingredientList.get(index_igd).getCode());
//                String amountwithunit = userIngredientList.get(position).getAmount()+" "+ingredientList.get(index_igd).getMeasure();
                Integer amount = userIngredientList.get(position).getAmount();
                tv_amount.setText(amount.toString());
                tv_buydate.setText(userIngredientList.get(position).getBuydate());
                tv_expdate.setText(userIngredientList.get(position).getExpirationdate());

                builder.setView(popup);

                btn_addMemo = popup.findViewById(R.id.addMemo);
                btn_saveupdate = popup.findViewById(R.id.saveUpdate);
                btn_updateigd = popup.findViewById(R.id.updateIngredient);
                btn_deleteigd = popup.findViewById(R.id.deleteIngredient);

                // Update 클릭 효과
                btn_updateigd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tv_name.setVisibility(View.VISIBLE);

                        tv_amount.setVisibility(View.GONE);
                        edit_amount.setVisibility((View.VISIBLE));
                        edit_amount.setText(tv_amount.getText());

                        tv_buydate.setVisibility(View.GONE);
                        edit_buydate.setVisibility((View.VISIBLE));
                        edit_buydate.setText(tv_buydate.getText());

                        btn_addMemo.setVisibility(View.GONE);
                        btn_updateigd.setVisibility(View.GONE);
                        btn_deleteigd.setVisibility(View.GONE);
                        btn_saveupdate.setVisibility(View.VISIBLE);}
                });

                // Delete 클릭 효과
                btn_deleteigd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = tv_name.getText().toString();
                        dialog.dismiss();

                        builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                        builder.setMessage(name +" 을(를) 삭제하시겠습니까?");
                        builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ingredientController.deleteUserIngredient(position);
                                updatePage();
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();
                    }
                });

                btn_saveupdate.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        String name = tv_name.getText().toString();
                        Integer amount = Integer.parseInt(edit_amount.getText().toString());
                        String buydate = edit_buydate.getText().toString();

                        UserIngredient edituserigd = userIngredientList.get(position);
                        edituserigd.setAmount(amount);
                        edituserigd.setBuydate(buydate);

                        ingredientController.updateUserIngredient(edituserigd, position);
                        dialog.dismiss();

                        builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                        builder.setMessage(name +" 이(가) 수정되었습니다");
                        builder.setNeutralButton("확인", null);
                        builder.create().show();
                    }
                });

                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        userIngredientList = ingredientController.getAllUserIngredients();
        adapter = new UserIngredientAdaper(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);
    }

    public void updatePage() {
        userIngredientList = ingredientController.getAllUserIngredients();
        adapter = new UserIngredientAdaper(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);
    }


    public class UserIngredientAdaper extends BaseAdapter{
        private ArrayList<UserIngredient> userIngredientList;
        private ArrayList<Ingredient> ingredientList;

        public UserIngredientAdaper(ArrayList<UserIngredient> userIngredientList, ArrayList<Ingredient> ingredientList) {
            this.userIngredientList = userIngredientList;
            this.ingredientList = ingredientList;
        }

        @Override
        public int getCount() {
            return userIngredientList.size();
        }

        @Override
        public Object getItem(int i) {
            return userIngredientList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int position = i;
            final Context context = viewGroup.getContext();

            if (view == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.userigd_item, viewGroup, false);
            }

            ImageView userigdImage = (ImageView) view.findViewById(R.id.userigdImage);
            TextView userigdname = (TextView) view.findViewById(R.id.userigdName);

            userigdImage.setImageResource(R.drawable.useritemimage);
            UserIngredient userigditem = userIngredientList.get(position);
            int userigditem_igdid = userigditem.getIgd_id();
            userigdname.setText(ingredientList.get(userigditem_igdid).getName());

            return view;
        }
    }

}
