package com.example.test_ingredient.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test_ingredient.Controller.IngredientController;
import com.example.test_ingredient.Entity.Ingredient;
import com.example.test_ingredient.R;
import com.example.test_ingredient.Entity.UserIngredient;

import java.util.ArrayList;

public class AddUserIngredient_Activity extends AppCompatActivity {

    private IngredientController ingredientController;
    private ArrayList<UserIngredient> userIngredientList;
    private ArrayList<Ingredient> ingredientList;
    private IngredientAdaper adapter;

    GridView igd_gv;
    TextView nText;
    EditText qText, dText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_add);

        ingredientController = new IngredientController(this);
        igd_gv = (GridView)findViewById(R.id.igd_gv);

        ingredientList = ingredientController.getAllingredients();
        userIngredientList = ingredientController.getAllUserIngredients();

        adapter = new IngredientAdaper(ingredientList);
        igd_gv.setAdapter(adapter);

        igd_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String name = ingredientList.get(position).getName();
                UserIngredient selectedIgd = new UserIngredient();
                selectedIgd.setUserigd_id(userIngredientList.size()+1);
                selectedIgd.setUser_id(1);
                selectedIgd.setIgd_id(ingredientList.get(position).getIgd_id()-1);
                selectedIgd.setAmount(0);
                selectedIgd.setReservedamount(0);
                selectedIgd.setBuydate("");
                selectedIgd.setExpirationdate("");

                add(selectedIgd, name);
            }
        });
    }

    void add(final UserIngredient selecteduserIgd, String name){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View view = inflater_dg.inflate(R.layout.userigd_addpopup, null);
        builder.setView(view);

        nText = (TextView)view.findViewById(R.id.showName);
        nText.setText(name);
        qText = (EditText)view.findViewById(R.id.editQuantity);
        dText = (EditText)view.findViewById(R.id.editDuedate);

        builder.setPositiveButton("추가", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                int amount = Integer.parseInt(qText.getText().toString());
                String buydate = dText.getText().toString();
                UserIngredient useringredient = selecteduserIgd;
                useringredient.setAmount(amount);
                useringredient.setBuydate(buydate);

                ingredientController.insertUserIngredient(selecteduserIgd);

            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public class IngredientAdaper extends BaseAdapter {
        private ArrayList<Ingredient> ingredientList;

        public IngredientAdaper(ArrayList<Ingredient> ingredientList) {
            this.ingredientList = ingredientList;
        }

        @Override
        public int getCount() {
            return ingredientList.size();
        }

        @Override
        public Object getItem(int i) {
            return ingredientList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int position = i;
            final Context context = viewGroup.getContext();

            if (view == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.userigd_item, viewGroup, false);
            }

            ImageView userigdImage = (ImageView) view.findViewById(R.id.userigdImage);
            TextView userigdname = (TextView) view.findViewById(R.id.userigdName);

            userigdImage.setImageResource(R.drawable.useritemimage);
            userigdname.setText(ingredientList.get(i).getName());

            return view;
        }
    }

}
