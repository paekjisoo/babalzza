package com.example.test_ingredient.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.test_ingredient.Entity.Ingredient;
import com.example.test_ingredient.Entity.UserIngredient;
import com.example.test_ingredient.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class IngredientController extends SQLiteOpenHelper{
    private static final String dbName = "igdtest.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final int dbVersion = 1;
    String CREATE_INGREDIENT = "CREATE TABLE Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";

    private SQLiteDatabase db;

    public IngredientController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        onCreate(db);
    }

    // 전체 식재료 create
    public boolean insertIngredient(Ingredient newigd){
        ContentValues cv = new ContentValues();
        cv.put("igd_id", newigd.getIgd_id());
        cv.put("name", newigd.getName());
        cv.put("image", "");
        cv.put("code", newigd.getCode());
        cv.put("measure", newigd.getMeasure());
        cv.put("refrigeratedterm", newigd.getRefrigeratedterm());
        cv.put("freezedterm", newigd.getFreezedterm());
        return db.insert(T_INGREDIENT, null, cv)!= -1;
    }


    // 전체 식재료 read
    public ArrayList<Ingredient> getAllingredients(){
        ArrayList<Ingredient> ingredientsList = new ArrayList<Ingredient>();
        String query = "SELECT * FROM Ingredient";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                Ingredient oneigd = new Ingredient();
                oneigd.setIgd_id(c.getInt(0));
                oneigd.setName(c.getString(1));
                oneigd.setImage("");
                oneigd.setCode(c.getString(3));
                oneigd.setMeasure(c.getString(4));
                oneigd.setRefrigeratedterm(c.getString(5));
                oneigd.setFreezedterm(c.getString(6));

                ingredientsList.add(oneigd);
            }
        }
        return ingredientsList;
    }

    // 이용자 보유 식재료 create
    public boolean insertUserIngredient(UserIngredient newuserigd){
        ContentValues cv = new ContentValues();
        cv.put("userigd_id", newuserigd.getUserigd_id());
        cv.put("user_id", newuserigd.getUser_id());
        cv.put("igd_id", newuserigd.getIgd_id());
        cv.put("amount", newuserigd.getAmount());
        cv.put("reservedamount", newuserigd.getReservedamount());
        cv.put("buydate", newuserigd.getBuydate());
        cv.put("expirationdate", newuserigd.getExpirationdate());
        return db.insert(T_USERINGREDIENT, null, cv)!= -1;
    }


    // 이용자 보유 식재료 read
    public ArrayList<UserIngredient> getAllUserIngredients(){
        ArrayList<UserIngredient> useringredientsList = new ArrayList<UserIngredient>();
        String query = "SELECT * FROM UserIngredient";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                UserIngredient oneuserigd = new UserIngredient();
                oneuserigd.setUserigd_id(c.getInt(0));
                oneuserigd.setUser_id(c.getInt(1));
                oneuserigd.setIgd_id(c.getInt(2));
                oneuserigd.setAmount(c.getInt(3));
                oneuserigd.setReservedamount(c.getInt(4));
                oneuserigd.setBuydate(c.getString(5));
                oneuserigd.setExpirationdate(c.getString(6));

                useringredientsList.add(oneuserigd);
            }
        }
        return useringredientsList;
    }

    // 이용자 보유 식재료 update
    public boolean updateUserIngredient(UserIngredient edituserigd, Integer userigd_id){
        ContentValues cv = new ContentValues();
        cv.put("amount", edituserigd.getAmount());
        cv.put("buydate", edituserigd.getBuydate());
        cv.put("expirationdate", edituserigd.getExpirationdate());
        String[] params = new String[]{Integer.toString(userigd_id+1)};
        int result = db.update(T_USERINGREDIENT, cv, "userigd_id=?", params);
        return result >0;
    }

    // 이용자 보유 식재료 delete
    public boolean deleteUserIngredient(Integer userigd_id){
        String[] params = new String[]{Integer.toString(userigd_id+1)};
        int result = db.delete(T_USERINGREDIENT, "userigd_id=?", params);
        return result >0;
    }

    public void csvToDB_Ingredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.ingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Ingredient csvigd = new Ingredient();
                    String[] list = line.split(",");

                    csvigd.setIgd_id(Integer.parseInt(list[0]));
                    csvigd.setName(list[1]);
                    csvigd.setImage(list[2]);
                    csvigd.setCode(list[3]);
                    csvigd.setMeasure(list[4]);
                    csvigd.setRefrigeratedterm(list[5]);
                    csvigd.setFreezedterm(list[6]);

                    insertIngredient(csvigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_UserIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.useringredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    UserIngredient csvuserigd = new UserIngredient();
                    String[] list = line.split(",");

                    csvuserigd.setUserigd_id(Integer.parseInt(list[0]));
                    csvuserigd.setUser_id(Integer.parseInt(list[1]));
                    csvuserigd.setIgd_id(Integer.parseInt(list[2]));
                    csvuserigd.setAmount(Integer.parseInt(list[3]));
                    csvuserigd.setReservedamount(Integer.parseInt(list[4]));
                    csvuserigd.setBuydate(list[5]);
                    csvuserigd.setExpirationdate(list[6]);

                    insertUserIngredient(csvuserigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


}
