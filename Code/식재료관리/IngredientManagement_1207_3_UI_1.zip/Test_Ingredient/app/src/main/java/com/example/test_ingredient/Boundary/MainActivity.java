package com.example.test_ingredient.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.test_ingredient.Controller.IngredientController;
import com.example.test_ingredient.Entity.UserIngredient;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.example.test_ingredient.R;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    IngredientController ingredientController;
    static ArrayList<UserIngredient> userIngredientArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_main);


        SharedPreferences csvload;

        csvload = getSharedPreferences("is_csv_loaded", Activity.MODE_PRIVATE);
        ingredientController = new IngredientController(this);

        String result = csvload.getString("is_csv_loaded", "");
        if (result==""){
            ingredientController.csvToDB_Ingredient(this);
            ingredientController.csvToDB_UserIngredient(this);
            SharedPreferences.Editor editor = csvload.edit();
            editor.putString("is_csv_loaded", "done");
            editor.commit();
        }
        ingredientController = new IngredientController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();

        //bottomNavigationView 에서 클릭
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        if(userIngredientArrayList.isEmpty()) {
                            Intent intent = new Intent(MainActivity.this, NoIngredient.class);
                            startActivity(intent);
                        }
                        else {
                            Intent intent = new Intent(MainActivity.this, UserIngredient_Activity.class);
                            startActivity(intent);
                        }
                        return true;
                    case R.id.schedule:
                        Toast.makeText(MainActivity.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.memo:
                        Toast.makeText(MainActivity.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    return false;
                }
            });

        }

    }
