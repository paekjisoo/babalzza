package com.example.prototypingreadpractice;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class GridViewActivity extends AppCompatActivity {
    Button btnAdd, btnClear;
    GridView lstView;
    EditText txtCompanyName;
    DatabaseController dbController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridlayout);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnClear = (Button) findViewById(R.id.btnClear);
        txtCompanyName = (EditText) findViewById(R.id.txtCompanyName);
        lstView = (GridView) findViewById(R.id.lstView);

        FillList();
    }

    public void AddData(View v) {
        try {
            if (TextUtils.isEmpty(txtCompanyName.getText().toString()))
                Toast.makeText(this, "Please enter Company name", Toast.LENGTH_SHORT).show();
            else {
                dbController = new DatabaseController(this);
                String s = dbController.InsertData(txtCompanyName.getText().toString());
                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
                FillList();
                txtCompanyName.setText("");
            }
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void ClearData(View v) {
        txtCompanyName.setText("");
    }

    public void FillList() {
        try {
            int[] id = {R.id.txtListElement};
            String[] CompanyName = new String[]{"CompanyName"};
            if (dbController == null)
                dbController = new DatabaseController(this);
            SQLiteDatabase sqlDb = dbController.getReadableDatabase();
            Cursor c = dbController.getCompanies();

            SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                    R.layout.list_template, c, CompanyName, id, 0);
            lstView.setAdapter(adapter);

        } catch (Exception ex) {
            Toast.makeText(GridViewActivity.this, ex.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }

}