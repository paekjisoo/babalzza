package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainIngredients extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "MainIngredients.db";
    private static final int DATABASE_VERSION = 1;
    public static MainIngredients mainIngredients;

    public MainIngredients (Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS MainIngredients ( _id INTEGER PRIMARY KEY not null, name text not null , classifier text not null, code INTEGER not null, duedate text not null)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query;
        query = "DROP TABLE IF EXISTS MainIngredients";
        db.execSQL(query);
        onCreate(db);
    }

    public String InsertData(Integer id, String name, String classifier, Integer code, String duedate) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "insert into  MainIngredients (id, name, classifier, code, duedate) values ('" + id + "'," + name + ",'" + classifier + "', " + code + ", " + duedate +")";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public ArrayList<MainIngredients.TestIngredients> getAllIngredients(Context ct) {
        ArrayList<MainIngredients.TestIngredients> ingredients = new ArrayList<TestIngredients>();
        try {
            InputStream in = ct.getResources().openRawResource(R.raw.test);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);

                String line;
                while ((line = br.readLine().trim()) != null) {
                    String[] list = line.split(",".trim());

                    Integer id = Integer.parseInt(list[0].trim(),10);
                    String name = list[1].trim();
                    String classifier = list[2].trim();
                    Integer code = Integer.parseInt(list[3].trim(),10);
                    String duedate = list[4].trim();

                    MainIngredients.TestIngredients ing = new MainIngredients.TestIngredients(id, name, classifier, code, duedate);
                    ingredients.add(ing);
                }
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return ingredients;
    }

    public class TestIngredients {
        private Integer id;
        private String name;
        private String classifier;
        private Integer code;
        private String duedate;

        public TestIngredients(Integer id, String name, String classifier, Integer code, String duedate) {
            super();
            this.id=id;
            this.name = name;
            this.classifier = classifier;
            this.code = code;
            this.duedate = duedate;
        }

        public Integer getId() {return id;}
        public void setId(Integer id) {this.id = id;}

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }

        public String getClassifier() {
            return classifier;
        }
        public void setClassifier(String classifier) {
            this.classifier = classifier;
        }

        public Integer getCode() {
            return code;
        }
        public void setCode(Integer code) {
            this.code = code;
        }

        public String getDueDate() {
            return duedate;
        }
        public void setDueDate(String duedate) {
            this.duedate = duedate;
        }
    }
}
