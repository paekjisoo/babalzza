package com.example.babalzza.Control;

import android.content.Context;

import com.example.babalzza.Boundary.IngredientManageForm;
import com.example.babalzza.Entity.MainIngredients;
import com.example.babalzza.Entity.UserIngredient;

import java.util.ArrayList;

import static com.example.babalzza.Boundary.IngredientManageForm.adapter;
import static com.example.babalzza.Boundary.IngredientManageForm.ingredientList;
import static com.example.babalzza.Boundary.IngredientManageForm.myIngredients;
import static com.example.babalzza.Boundary.IngredientAdditionForm.testIngredients;

public class IngredientController {

    public static void addIngredient(UserIngredient userIngredient, Context context, String name, Integer quantity, String duedate) {
        userIngredient.InsertData(name, quantity, duedate);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static ArrayList<UserIngredient.Ingredient> readIngredient(UserIngredient userIngredient, ArrayList<UserIngredient.Ingredient> IngredientList) {
        ingredientList = userIngredient.getAllIngredients();

        return ingredientList;
    }

    public static void deleteIngredient(UserIngredient userIngredient, Context context, String id){
        userIngredient.delete(id);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    // read 읽어오기
    public static ArrayList<MainIngredients.TestIngredients> getIngredientList(Context ct, MainIngredients mainIngredients, ArrayList<MainIngredients.TestIngredients> IngredientList) {
        testIngredients = mainIngredients.getAllIngredients(ct);

        return testIngredients;
    }
}
