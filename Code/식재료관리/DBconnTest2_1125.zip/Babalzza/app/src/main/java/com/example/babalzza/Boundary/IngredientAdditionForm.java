package com.example.babalzza.Boundary;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzza.Control.IngredientController;
import com.example.babalzza.Entity.MainIngredients;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class IngredientAdditionForm extends AppCompatActivity {

    private ImageButton ib1_1, ib1_2, ib2_1, ib2_2;
    private EditText nText, qText, dText;
    private String name; private Integer quantity; private String duedate;
    private FloatingActionButton fab;

    public static GridView IngredientsDB;
    public static IngredientAdditionForm.IngredientDBAdapter dbadapter;
    public static ArrayList<MainIngredients.TestIngredients> testIngredients;
    public static MainIngredients mainIngredients;

    @Override
    // 식자재 버튼 create
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_add);

        //test from here

        IngredientsDB = (GridView)findViewById(R.id.allIngredients);
        testIngredients = new ArrayList<MainIngredients.TestIngredients>();

        if (mainIngredients == null)
            mainIngredients = new MainIngredients(getApplicationContext());

        testIngredients = IngredientController.getIngredientList(getApplicationContext(), mainIngredients, testIngredients);

        dbadapter = new IngredientAdditionForm.IngredientDBAdapter(getApplicationContext(), testIngredients);
        IngredientsDB.setAdapter(dbadapter);

        IngredientsDB.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(IngredientAdditionForm.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                AlertDialog dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });
        //test till here

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);

        /*
        ib1_1 = (ImageButton) findViewById(R.id.imageButton1_1);
        ib1_2 = (ImageButton) findViewById(R.id.imageButton1_2);
        ib2_1 = (ImageButton) findViewById(R.id.imageButton2_1);
        ib2_2 = (ImageButton) findViewById(R.id.imageButton2_2);

        ib1_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        ib1_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        ib2_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        ib2_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });

         */


        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                add();
            }
        });
    }

    void add(/*final Context context /*, final NoteAdapter adapter*/){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View view = inflater_dg.inflate(R.layout.fridge_add_popup, null);
        builder.setView(view);
        builder.setPositiveButton("추가", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                nText = (EditText)view.findViewById(R.id.showName);
                qText = (EditText)view.findViewById(R.id.showQuantity);
                dText = (EditText)view.findViewById(R.id.showDuedate);

                name = nText.getText().toString();
                quantity = Integer.parseInt(qText.getText().toString());
                duedate = dText.getText().toString();

                // added version
                IngredientController.addIngredient(IngredientManageForm.userIngredient, getApplicationContext(), name, quantity, duedate);

                // IngredientController.addIngredient(name, quantity, duedate);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public static class IngredientDBAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<MainIngredients.TestIngredients> ingredient_list;

        public IngredientDBAdapter(Context context, ArrayList<MainIngredients.TestIngredients> ingredient_list) {
            this.context = context;
            this.ingredient_list = ingredient_list;
        }

        @Override
        public int getCount() {
            return ingredient_list.size();
        }

        @Override
        public Object getItem(int position) {
            return ingredient_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.ingredient, null);

            ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
            TextView ing_name = (TextView)v.findViewById(R.id.showName);

            ing_name.setText(ingredient_list.get(position).getName());
            ing_image.setImageResource(R.drawable.tkaruqtkf);

            return v;
        }
    }
}
