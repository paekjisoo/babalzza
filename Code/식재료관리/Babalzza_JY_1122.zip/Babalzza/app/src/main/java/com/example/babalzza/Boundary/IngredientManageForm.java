package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.babalzza.Control.IngredientController;
import com.example.babalzza.Entity.IngredientDatabase;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class IngredientManageForm extends AppCompatActivity {

    private FloatingActionButton fab;

    public static GridView myIngredients;
    public static IngredientListAdapter adapter;
    public static ArrayList<Ingredient> ingredientList;
    public static IngredientDatabase ingredientDatabase;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_main);

        // findViewById를 통한 xml 내 객체 선언
        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        myIngredients = (GridView)findViewById(R.id.myIngredient);

        ingredientList = new ArrayList<Ingredient>();

        if(ingredientDatabase == null)
            ingredientDatabase = new IngredientDatabase(getApplicationContext());

        ingredientList = ingredientDatabase.getAllIngredients();

        adapter = new IngredientListAdapter(getApplicationContext(), ingredientList);
        myIngredients.setAdapter(adapter);

        // floating action button 클릭 효과 선언
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "추가", Toast.LENGTH_SHORT).show();
                Intent addintent= new Intent(IngredientManageForm.this, IngredientAdditionForm.class);
                IngredientManageForm.this.startActivity(addintent);
            }
        });

        // gridview 아이템 클릭 효과 선언
        myIngredients.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(IngredientManageForm.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                final View popup = inflater_dg.inflate(R.layout.my_ingredient, null);

                TextView show_name = (TextView)popup.findViewById(R.id.showName);
                TextView show_quantity = (TextView)popup.findViewById(R.id.showQuantity);
                TextView show_duedate = (TextView)popup.findViewById(R.id.showDuedate);

                show_name.setText(ingredientList.get(position).getName());
                show_quantity.setText(ingredientList.get(position).getId().toString());
                show_duedate.setText(ingredientList.get(position).getDueDate());

                builder.setView(popup);

                // Jaeyoung 1120 Button 구현 및 연결
                Button addMemo = popup.findViewById(R.id.addMemo);
                Button updateIngredient = popup.findViewById(R.id.updateIngredient);
                Button deleteIngredient = popup.findViewById(R.id.deleteIngredient);

                /*addMemo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 장보기메모에 추가
                    }
                });
                /*updateIngredient.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ContentValues updateRowValue = new ContentValues();
                        updateRowValue.put("name", );
                        updateRowValue.put("quantity", );
                        updateRowValue.put("dueDate", );
                        ingredientDatabase.update(updateRowValue, ingredientList.get(position).toString());
                    }
                });*/ // new popup needed
                deleteIngredient.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        IngredientController.deleteIngredient(ingredientDatabase, getApplicationContext(), ingredientList.get(position).getId().toString());
                        //ingredientDatabase.delete(ingredientList.get(position).getId().toString());
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });
    }

    public static class IngredientListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<Ingredient> ingredient_list;

        public IngredientListAdapter(Context context, ArrayList<Ingredient> ingredient_list) {
            this.context = context;
            this.ingredient_list = ingredient_list;
        }

        @Override
        public int getCount() {
            return ingredient_list.size();
        }

        @Override
        public Object getItem(int position) {
            return ingredient_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.ingredient, null);

            ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
            TextView ing_name = (TextView)v.findViewById(R.id.showName);

            ing_name.setText(ingredient_list.get(position).getName());
            ing_image.setImageResource(R.drawable.tkaruqtkf);

            return v;
        }
    }
}