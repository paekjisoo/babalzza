package com.example.babalzza.Entity;

public class Ingredient {
    private Integer id;
    private String name;
    private Integer quantity;
    private String duedate;

    public Ingredient (String name, Integer quantity, String duedate) {
        super();
        this.name = name;
        this.quantity = quantity;
        this.duedate = duedate;
    }
    public Ingredient (Integer id, String name, Integer quantity, String duedate) {
        super();
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.duedate = duedate;
    }
    public Integer getId() {return id;}
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    public String getDueDate() {
        return duedate;
    }
    public void setDueDate(String duedate) {
        this.duedate = duedate;
    }
}
