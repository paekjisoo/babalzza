package com.example.prototypingreadpractice;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class GridViewActivity extends AppCompatActivity {
    Button btnAdd, btnClear;
    GridView lstView;
    EditText txtIngredient;
    DatabaseController dbController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridlayout);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnClear = (Button) findViewById(R.id.btnClear);
        txtIngredient = (EditText) findViewById(R.id.txtIngredient);
        lstView = (GridView) findViewById(R.id.IngredientView);

        FillList();
    }

    public void AddData(View v) {
        try {
            if (TextUtils.isEmpty(txtIngredient.getText().toString()))
                Toast.makeText(this, "Please enter Ingredient name", Toast.LENGTH_SHORT).show();
            else {
                dbController = new DatabaseController(this);
                String s = dbController.InsertData(txtIngredient.getText().toString());
                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
                FillList();
                txtIngredient.setText("");
            }
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void ClearData(View v) {
        txtIngredient.setText("");
    }

    public void FillList() {
        try {
            int[] id = {R.id.txtListElement};
            String[] IngredientName = new String[]{"IngredientName"};
            if (dbController == null)
                dbController = new DatabaseController(this);
            SQLiteDatabase sqlDb = dbController.getReadableDatabase();
            Cursor c = dbController.getIngredients();

            SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                    R.layout.list_template, c, IngredientName, id, 0);
            lstView.setAdapter(adapter);

        } catch (Exception ex) {
            Toast.makeText(GridViewActivity.this, ex.getMessage().toString(), Toast.LENGTH_SHORT).show();
        }
    }

}