package com.example.babalzza.Entity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class UserIngredient extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "InnerDatabase(SQLite).db";
    private static final int DATABASE_VERSION = 1;

    public UserIngredient(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS UserIngredient ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name text not null , quantity INTEGER not null, duedate text not null)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old,
                            int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS UserIngredient";
        database.execSQL(query);
        onCreate(database);
    }

    public String InsertData(String name, Integer quantity, String duedate) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "insert into  UserIngredient (name, quantity, duedate) values ('" + name + "'," + quantity + ",'" + duedate + "')";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public Cursor getIngredients() {
        try {
            String selectQuery = "SELECT * FROM UserIngredient";
            SQLiteDatabase database = this.getWritableDatabase();
            Cursor cursor = database.rawQuery(selectQuery, null);
            return cursor;
        } catch (Exception ex) {
            return null;
        }
    }

    public ArrayList<UserIngredient.Ingredient> getAllIngredients() {
        String query = "SELECT * FROM UserIngredient";
        ArrayList<Ingredient> ingredients = new ArrayList<Ingredient>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                Integer id = c.getInt(0);
                String name = c.getString(1);
                Integer quantity = c.getInt(2);
                String duedate = c.getString(3);

                Ingredient ing = new Ingredient(id, name, quantity, duedate);

                ingredients.add(ing);
            }
        }

        return ingredients;
    }


    //Jaeyoung 2019.11.22 update
    //UD function

    public String update(ContentValues values, String id){
        try{
            SQLiteDatabase database = this.getWritableDatabase();
            database.update("UserIngredient", values, "_id ="+id, null);
            database.close();
            return "Updated Successfully";
        }catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public String delete(String id){
        try{
            SQLiteDatabase database = this.getWritableDatabase();
            database.delete("UserIngredient", "_id ="+id, null);
            database.close();
            return "Deleted Successfully";
        }catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public class Ingredient {
        private Integer id;
        private String name;
        private Integer quantity;
        private String duedate;

        public Ingredient (String name, Integer quantity, String duedate) {
            super();
            this.name = name;
            this.quantity = quantity;
            this.duedate = duedate;
        }
        public Ingredient (Integer id, String name, Integer quantity, String duedate) {
            super();
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.duedate = duedate;
        }
        public Integer getId() {return id;}
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public Integer getQuantity() {
            return quantity;
        }
        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }
        public String getDueDate() {
            return duedate;
        }
        public void setDueDate(String duedate) {
            this.duedate = duedate;
        }
    }
}