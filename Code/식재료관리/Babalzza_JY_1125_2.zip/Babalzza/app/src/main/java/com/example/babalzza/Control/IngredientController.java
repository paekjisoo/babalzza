package com.example.babalzza.Control;

import android.content.ContentValues;
import android.content.Context;

import com.example.babalzza.Boundary.IngredientManageForm;
import com.example.babalzza.Entity.UserIngredient;
import com.example.babalzza.Entity.UserIngredient.Ingredient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import static com.example.babalzza.Boundary.IngredientManageForm.adapter;
import static com.example.babalzza.Boundary.IngredientManageForm.ingredientList;
import static com.example.babalzza.Boundary.IngredientManageForm.myIngredients;


public class IngredientController {

    public static void addIngredient(UserIngredient userIngredient, Context context, String name, Integer quantity, String duedate) {
        userIngredient.InsertData(name, quantity, duedate);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static ArrayList<UserIngredient.Ingredient> readIngredient(UserIngredient userIngredient, ArrayList<UserIngredient.Ingredient> IngredientList) {
        ingredientList = userIngredient.getAllIngredients();

        return ingredientList;
    }

    public static void updateIngredient(UserIngredient userIngredient, ContentValues updateRowValue, Context context, String id){
        userIngredient.update(updateRowValue, id);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static void deleteIngredient(UserIngredient userIngredient, Context context, String id){
        userIngredient.delete(id);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static void sort(int type, UserIngredient userIngredient, Context context){
        ArrayList<Ingredient> ingredientList = userIngredient.getAllIngredients();
        /*switch (type) {
            case 1:
                Collections.sort(ingredientList, new Comparator() {
                    @Override
                    public int compare(UserIngredient.Ingredient u1, UserIngredient.Ingredient u2){
                        return u1.getName().compareTo(u2.getName());
                    }
                });
            case 2:
                Collections.sort(ingredientList, new Comparator() {
                    @Override
                    public int compare(UserIngredient.Ingredient u1, UserIngredient.Ingredient u2) {
                        return u1.getDueDate().compareTo(u2.getDueDate());
                    }
                });
            case 3:
        }*/
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }
}
