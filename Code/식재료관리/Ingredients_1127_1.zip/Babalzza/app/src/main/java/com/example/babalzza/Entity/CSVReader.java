package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class CSVReader extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "Test.db";
    private static final int DATABASE_VERSION = 1;

    public CSVReader(Context ct) {
        super(ct, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String MenuIngredient;
        String MenuScore;
        String Ingredient;

        MenuIngredient = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER PRIMARY KEY not null, igd_id INTEGER not null," +
                "igdtype text not null , igdamount double not null)";
        MenuScore = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
                "score double not null , recentassign text not null)";
        Ingredient = "CREATE TABLE IF NOT EXISTS Ingredient (id INTEGER PRIMARY KEY not null, name text not null , image image, " +
                "code INTEGER not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";

        db.execSQL(MenuIngredient);
        db.execSQL(MenuScore);
        db.execSQL(Ingredient);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String MenuIngredient;
        String MenuScore;
        String Ingredient;

        MenuIngredient = "DROP TABLE IF EXISTS MenuIngredient";
        MenuScore = "DROP TABLE IF EXISTS MenuScore";
        Ingredient = "DROP TABLE IF EXISTS Ingredient";

        db.execSQL(MenuIngredient);
        db.execSQL(MenuScore);
        db.execSQL(Ingredient);

        onCreate(db);
    }
}
