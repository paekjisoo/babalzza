package com.example.babalzza.Control;

import android.content.ContentValues;
import android.content.Context;

import com.example.babalzza.Boundary.IngredientManageForm;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.Entity.UserIngredient;
import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static com.example.babalzza.Boundary.IngredientManageForm.adapter;
import static com.example.babalzza.Boundary.IngredientManageForm.ingredientList;
import static com.example.babalzza.Boundary.IngredientManageForm.myIngredients;

public class IngredientController {

    public static void addIngredient(UserIngredient userIngredient, Context context, String name, Integer quantity, String duedate) {
        userIngredient.InsertData(name, quantity, duedate);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static ArrayList<UserIngredient.Ingredient> readIngredient(UserIngredient userIngredient, ArrayList<UserIngredient.Ingredient> IngredientList) {
        ingredientList = userIngredient.getAllIngredients();

        return ingredientList;
    }

    public static void updateIngredient(UserIngredient userIngredient, ContentValues updateRowValue, Context context, String id){
        userIngredient.update(updateRowValue, id);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static void deleteIngredient(UserIngredient userIngredient, Context context, String id){
        userIngredient.delete(id);
        ingredientList = userIngredient.getAllIngredients();
        adapter = new IngredientManageForm.IngredientListAdapter(context, ingredientList);
        myIngredients.setAdapter(adapter);
    }

    public static ArrayList<Ingredient> getIngredientsList(Context ct) {
        ArrayList<Ingredient> ingredientArrayList = new ArrayList<>();
        ingredientArrayList = Ingredient.getIngredientsList(ct);

        return ingredientArrayList;
    }
}
