package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MenuIngredient extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 3;

    private Integer menu_id;
    private Integer igd_id;
    private String igdtype;
    private double igdamount;

    public MenuIngredient(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);

        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS MenuIngredient (_id INTEGER PRIMARY KEY AUTOINCREMENT, menu_id INTEGER not null, igd_id INTEGER not null," +
                "igdtype text not null , igdamount double not null)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query;
        query = "DROP TABLE IF EXISTS MenuIngredient";
        db.execSQL(query);
        onCreate(db);
    }

    public String InsertData(Integer menu_id, Integer igd_id, String igdtype, double igdamount) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into MenuIngredient (menu_id, igd_id, igdtype, igdamount) values " +
                    "(" + menu_id + "," + igd_id + ",'" + igdtype + "'," + igdamount + ")";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public static void csvToDB(Context ct) {
        try {
            InputStream in = ct.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient menuIngredient = new MenuIngredient(ct);
                    String[] list = line.split(",");

                    Integer menu_id = Integer.parseInt(list[0]);
                    int igd_id = Integer.parseInt(list[1]);
                    String igdtype = list[2];
                    double igdamount = Double.parseDouble(list[3]);

                    menuIngredient.InsertData(menu_id, igd_id, igdtype, igdamount);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public Integer getIng_id() {
        return igd_id;
    }

    public void setIng_id(Integer ing_id) {
        this.igd_id = ing_id;
    }

    public String getIgdtype() {
        return igdtype;
    }

    public void setIgdtype(String igdtype) {
        this.igdtype = igdtype;
    }

    public double getIgdamount() {
        return igdamount;
    }

    public void setIgdamount(double igdamount) {
        this.igdamount = igdamount;
    }
}
