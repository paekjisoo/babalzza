package com.example.babalzza.Boundary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.babalzza.Control.IngredientController;
import com.example.babalzza.Entity.Menu;
import com.example.babalzza.Entity.MenuIngredient;
import com.example.babalzza.Entity.MenuScore;
import com.example.babalzza.Entity.UserIngredient;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class IngredientManageForm extends AppCompatActivity {

    private FloatingActionButton fab;
    private int gridItemId;
    public static GridView myIngredients;
    public static IngredientListAdapter adapter;
    public static ArrayList<UserIngredient.Ingredient> ingredientList;
    public static UserIngredient userIngredient;
    public static ArrayList<Menu> menuArrayList;

    AlertDialog.Builder builder;
    AlertDialog dialog;
    TextView show_name;
    TextView show_quantity;
    TextView show_duedate;
    EditText edit_quantity;
    EditText edit_duedate;
    Button addMemo;
    Button updateIngredient;
    Button deleteIngredient;
    Button saveUpdate;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_main);
        // //
        menuArrayList = Menu.getMenuList(getApplicationContext());
        MenuScore.csvToDB(getApplicationContext());
        MenuIngredient.csvToDB(getApplicationContext());
        // //

        // findViewById를 통한 xml 내 객체 선언
        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        myIngredients = (GridView)findViewById(R.id.myIngredient);

        if(userIngredient == null)
            userIngredient = new UserIngredient(getApplicationContext());

        ingredientList = IngredientController.readIngredient(userIngredient, ingredientList);

        adapter = new IngredientListAdapter(getApplicationContext(), ingredientList);
        myIngredients.setAdapter(adapter);

        // floating action button 클릭 효과 선언
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "추가", Toast.LENGTH_SHORT).show();
                Intent addintent= new Intent(IngredientManageForm.this, IngredientAdditionForm.class);
                IngredientManageForm.this.startActivity(addintent);
            }
        });

        // gridview 아이템 클릭 효과 선언
        myIngredients.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                builder = new AlertDialog.Builder(IngredientManageForm.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                gridItemId = position;
                final View popup = inflater_dg.inflate(R.layout.user_ingredient, null);

                TextView show_type= popup.findViewById(R.id.showType);
                TextView show_state = popup.findViewById(R.id.showState);


                show_name = (TextView)popup.findViewById(R.id.showName);
                show_quantity = (TextView)popup.findViewById(R.id.showQuantity);
                show_duedate = (TextView)popup.findViewById(R.id.showExpirationDate);

                edit_quantity = popup.findViewById(R.id.editQuantity);
                edit_duedate = popup.findViewById(R.id.editExpirationDate);

                show_name.setText(ingredientList.get(position).getName());
                show_quantity.setText(ingredientList.get(position).getQuantity().toString());
                show_duedate.setText(ingredientList.get(position).getDuedate());

                builder.setView(popup);

                // Jaeyoung 1120 Button 구현 및 연결
                addMemo = popup.findViewById(R.id.addMemo);
                updateIngredient = popup.findViewById(R.id.updateIngredient);
                deleteIngredient = popup.findViewById(R.id.deleteIngredient);
                saveUpdate = popup.findViewById(R.id.saveUpdate);

                // Update 클릭 효과
                updateIngredient.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        updateIngredient.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                show_name.setVisibility(View.VISIBLE);
                                show_quantity.setVisibility(View.GONE);
                                edit_quantity.setVisibility((View.VISIBLE));
                                edit_quantity.setText(show_quantity.getText());
                                show_duedate.setVisibility(View.GONE);
                                edit_duedate.setVisibility((View.VISIBLE));
                                edit_duedate.setText(show_duedate.getText());
                                addMemo.setVisibility(View.GONE);
                                updateIngredient.setVisibility(View.GONE);
                                deleteIngredient.setVisibility(View.GONE);
                                saveUpdate.setVisibility(View.VISIBLE);}
                        });
                    }
                });

                // Delete 클릭 효과
                deleteIngredient.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = show_name.getText().toString();
                        dialog.dismiss();

                        builder = new AlertDialog.Builder(IngredientManageForm.this);
                        builder.setMessage(name +" 을(를) 삭제하시겠습니까?");
                        builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                IngredientController.deleteIngredient(userIngredient, getApplicationContext(), ingredientList.get(position).getId().toString());
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();
                    }
                });

                saveUpdate.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        String name = show_name.getText().toString();
                        Integer quantity = Integer.parseInt(edit_quantity.getText().toString());
                        String duedate = edit_duedate.getText().toString();

                        ContentValues updateRowValue = new ContentValues();
                        updateRowValue.put("name", name);
                        updateRowValue.put("quantity", quantity);
                        updateRowValue.put("dueDate", duedate);

                        IngredientController.updateIngredient(userIngredient, updateRowValue, getApplicationContext(), ingredientList.get(position).getId().toString());
                        dialog.dismiss();
                        builder = new AlertDialog.Builder(IngredientManageForm.this);
                        builder.setMessage(name +" 이(가) 수정되었습니다");
                        builder.setNeutralButton("확인", null);
                        builder.create().show();
                    }
                });

                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.sort_type_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        switch(item.getItemId()){
            case R.id.sortByName:
                IngredientController.sort(1, userIngredient, getApplicationContext());
                return true;
            case R.id.sortByState:
                IngredientController.sort(2, userIngredient, getApplicationContext());
                return true;
            case R.id.sortByType:
                IngredientController.sort(3, userIngredient, getApplicationContext());
                return true;
        }
        return false;
    }

    public static class IngredientListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<UserIngredient.Ingredient> ingredient_list;

        public IngredientListAdapter(Context context, ArrayList<UserIngredient.Ingredient> ingredient_list) {
            this.context = context;
            this.ingredient_list = ingredient_list;
        }

        @Override
        public int getCount() {
            return ingredient_list.size();
        }

        @Override
        public Object getItem(int position) {
            return ingredient_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.ingredient, null);

            ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
            TextView ing_name = (TextView)v.findViewById(R.id.showName);

            ing_name.setText(ingredient_list.get(position).getName());
            ing_image.setImageResource(R.drawable.tkaruqtkf);

            return v;
        }
    }
}