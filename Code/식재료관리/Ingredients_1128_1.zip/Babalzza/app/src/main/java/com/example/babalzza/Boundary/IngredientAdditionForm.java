package com.example.babalzza.Boundary;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzza.Control.IngredientController;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.Entity.UserIngredient;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class IngredientAdditionForm extends AppCompatActivity {

    private TextView nText;
    private EditText qText, dText;
    private String name; private Integer quantity; private String duedate;
    private FloatingActionButton fab;
    public static GridView gridView;
    public static ArrayList<Ingredient> ingredientsInfoList;
    public static IngredientListAdapter adapter;

    @Override
    // 식자재 버튼 create
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_add);

        // 1126 나승원 추가
        ingredientsInfoList = new ArrayList<Ingredient>();

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        gridView = (GridView) findViewById(R.id.ingredients);

        // 1126 나승원 추가
        ingredientsInfoList = IngredientController.getIngredientsList(getApplicationContext());

        adapter = new IngredientListAdapter(getApplicationContext(), ingredientsInfoList);
        gridView.setAdapter(adapter);

        IngredientController.getIngredientsList(getApplicationContext());

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String name;
                name = ingredientsInfoList.get(position).getName();
                add(name);
            }
        });
    }

    /*
    1126 나승원 수정
    add 함수에 이름을 String 값으로 받아서 추가 시 바로 입력
     */
    void add(final String s){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View view = inflater_dg.inflate(R.layout.fridge_add_popup, null);
        builder.setView(view);

        builder.setPositiveButton("추가", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                nText = (TextView)view.findViewById(R.id.showName);
                qText = (EditText)view.findViewById(R.id.showQuantity);
                dText = (EditText)view.findViewById(R.id.showDuedate);

                nText.setText(s);

                name = nText.getText().toString();
                quantity = Integer.parseInt(qText.getText().toString());
                duedate = dText.getText().toString();

                IngredientController.addIngredient(IngredientManageForm.userIngredient, getApplicationContext(), name, quantity, duedate);
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public static class IngredientListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<Ingredient> ingredient_list;

        public IngredientListAdapter(Context context, ArrayList<Ingredient> ingredient_list) {
            this.context = context;
            this.ingredient_list = ingredient_list;
        }

        @Override
        public int getCount() {
            return ingredient_list.size();
        }

        @Override
        public Object getItem(int position) {
            return ingredient_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.ingredient, null);

            ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
            TextView ing_name = (TextView)v.findViewById(R.id.showName);

            ing_name.setText(ingredient_list.get(position).getName());
            ing_image.setImageResource(R.drawable.tkaruqtkf);

            return v;
        }
    }
}
