package com.example.babalzza.Entity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.Image;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Ingredient extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 1;

    private Integer id;
    private String name;
    private Image image;
    private Integer code;
    private String measure;
    private String refrigeratedterm;
    private String freezedterm;

    public Ingredient(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS Ingredient (id INTEGER PRIMARY KEY not null, name text not null , image image, " +
                "code INTEGER not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query;
        query = "DROP TABLE IF EXISTS Ingredient";
        db.execSQL(query);
        onCreate(db);
    }

    public static ArrayList<Ingredient> getIngredientsList(Context ct) {
        ArrayList<Ingredient> ingredientArrayList = new ArrayList<>();
        InputStream in = ct.getResources().openRawResource(R.raw.ingredient);
        try {
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Ingredient ing = new Ingredient(ct);
                    String[] list = line.split(",");

                    Integer id = Integer.parseInt(list[0]);
                    String name = list[1];
                    ing.setName(name);
                    Integer code = Integer.parseInt(list[3]);
                    ing.setCode(code);
                    String measure = list[4];
                    ing.setMeasure(measure);
                    String refrigeratedterm = list[5];
                    ing.setRefrigeratedterm(refrigeratedterm);
                    String freezedterm = list[6];
                    ing.setFreezedterm(freezedterm);

                    ing.InsertData(id, name, code, measure, refrigeratedterm, freezedterm);
                    ingredientArrayList.add(ing);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return ingredientArrayList;
    }

    public String InsertData(Integer id, String name, Integer code, String measure, String refrigeratedterm, String freezedterm) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into Ingredient (id, name, code, measure, refrigeratedterm, freezedterm) values " +
                    "(" + id + ",'" + name + "'," + code + ",'" + measure + "','" + refrigeratedterm + "','" + freezedterm + "')";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMeasure(String measure) { return measure; }

    public void setMeasure(String measure) { this.measure = measure; }

    public String getRefrigeratedterm() {
        return refrigeratedterm;
    }

    public void setRefrigeratedterm(String refrigeratedterm) {
        this.refrigeratedterm = refrigeratedterm;
    }

    public String getFreezedterm() {
        return freezedterm;
    }

    public void setFreezedterm(String freezedterm) {
        this.freezedterm = freezedterm;
    }
}
