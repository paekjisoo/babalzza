package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Menu extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 1;

    private Integer id;
    private String name;
    private String code;
    private String country;
    private String time;
    private String level;
    private String recipelink;

    public Menu(Context applicationcontext, Integer id, String name, String code, String country, String time, String level, String recipelink) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);

        this.id = id;
        this.name = name;
        this.code = code;
        this.country = country;
        this.time = time;
        this.level = level;
        this.recipelink = recipelink;

        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS Menu (id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
                "country text not null, time text not null, level text not null, recipelink text not null)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query;
        query = "DROP TABLE IF EXISTS Menu";
        db.execSQL(query);
        onCreate(db);
    }

    public static ArrayList<Menu> getMenuList(Context ct) {
        ArrayList<Menu> menuArrayList = new ArrayList<>();
        try {
            InputStream in = ct.getResources().openRawResource(R.raw.menu);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Menu menu = new Menu(ct,0,"","","","","","");
                    String[] list = line.split(",");

                    int id = Integer.parseInt(list[0]);
                    menu.setId(id);
                    String name = list[1];
                    menu.setName(name);
                    String code = list[2];
                    menu.setCode(code);
                    String country = list[3];
                    menu.setCountry(country);
                    String time = list[4];
                    menu.setTime(time);
                    String level = list[5];
                    menu.setLevel(level);
                    String recipelink = list[6];
                    menu.setRecipelink(recipelink);

                    menu.InsertData(id, name, code, country, time, level, recipelink);
                    menuArrayList.add(menu);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return menuArrayList;
    }

    public String InsertData(Integer id, String name, String code, String country, String time, String level, String recipelink) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into Menu (id, name, code, country, time, level, recipelink) values " +
                    "(" + id + ",'" + name + "','" + code + "','" + country + "','" + time + "','" + level + "','" + recipelink + "')";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getRecipelink() {
        return recipelink;
    }

    public void setRecipelink(String recipelink) {
        this.recipelink = recipelink;
    }
}
