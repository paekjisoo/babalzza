package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class AllEntityTable extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "UserDB.db";
    private static final int DATABASE_VERSION = 1;

    public AllEntityTable(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name text not null , quantity INTEGER not null, duedate text not null)";;
        String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (id INTEGER PRIMARY KEY not null, name text not null , image image, " +
                "code INTEGER not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
        String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
                "country text not null, time text not null, level text not null, recipelink text not null)";
        String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (_id INTEGER PRIMARY KEY AUTOINCREMENT, menu_id INTEGER not null, igd_id INTEGER not null," +
                "igdtype text not null , igdamount double not null)";
        String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
                "score double not null , recentassign text not null)";

        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_USERINGREDIENT = "DROP TABLE IF EXISTS UserIngredient";
        String DROP_INGREDIENT = "DROP TABLE IF EXISTS Ingredient";
        String DROP_MENU = "DROP TABLE IF EXISTS Menu";
        String DROP_MENUINGREDIENT = "DROP TABLE IF EXISTS MenuIngredient";
        String DROP_MENUSCORE = "DROP TABLE IF EXISTS MenuScore";

        db.execSQL(DROP_INGREDIENT);
        db.execSQL(DROP_MENU);
        db.execSQL(DROP_MENUINGREDIENT);
        db.execSQL(DROP_USERINGREDIENT);
        db.execSQL(DROP_MENUSCORE);

        onCreate(db);
    }
}
