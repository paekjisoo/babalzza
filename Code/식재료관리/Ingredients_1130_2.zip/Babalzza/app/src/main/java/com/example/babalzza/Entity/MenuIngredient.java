package com.example.babalzza.Entity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MenuIngredient extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 1;

    private Integer menu_id;
    private Integer igd_id;
    private String igdtype;
    private double igdamount;

    public MenuIngredient(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null , igd_id INTEGER not null," +
                " amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
        String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null , image image, " +
                "code INTEGER not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
        String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
                "country text not null, time text not null, level text not null, recipelink text not null)";
        String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
                "igdtype text not null , igdamount double not null, PRIMARY KEY (menu_id, igd_id))";
        String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
                "score double not null , recentassign text not null, PRIMARY KEY (user_id, menu_id))";
        String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory(user_id INTEGER NOT NULL, menu_id INTEGER NOT NULL," +
                " meal text NOT NULL, result text not null, PRIMARY KEY (user_id, menu_id))";

        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_USERINGREDIENT = "DROP TABLE IF EXISTS UserIngredient";
        String DROP_INGREDIENT = "DROP TABLE IF EXISTS Ingredient";
        String DROP_MENU = "DROP TABLE IF EXISTS Menu";
        String DROP_MENUINGREDIENT = "DROP TABLE IF EXISTS MenuIngredient";
        String DROP_MENUSCORE = "DROP TABLE IF EXISTS MenuScore";
        String DROP_SCHEDULEHISTORY = "DROP TABLE IF EXISTS ScheduleHistory";

        db.execSQL(DROP_INGREDIENT);
        db.execSQL(DROP_MENU);
        db.execSQL(DROP_MENUINGREDIENT);
        db.execSQL(DROP_USERINGREDIENT);
        db.execSQL(DROP_MENUSCORE);
        db.execSQL(DROP_SCHEDULEHISTORY);

        onCreate(db);
    }

    public String InsertData(Integer menu_id, Integer igd_id, String igdtype, double igdamount) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into MenuIngredient (menu_id, igd_id, igdtype, igdamount) values " +
                    "(" + menu_id + "," + igd_id + ",'" + igdtype + "'," + igdamount + ")";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public static void csvToDB(Context ct) {
        try {
            InputStream in = ct.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient menuIngredient = new MenuIngredient(ct);
                    String[] list = line.split(",");

                    Integer menu_id = Integer.parseInt(list[0]);
                    int igd_id = Integer.parseInt(list[1]);
                    String igdtype = list[2];
                    double igdamount = Double.parseDouble(list[3]);

                    menuIngredient.InsertData(menu_id, igd_id, igdtype, igdamount);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public Integer getIng_id() {
        return igd_id;
    }

    public void setIng_id(Integer ing_id) {
        this.igd_id = ing_id;
    }

    public String getIgdtype() {
        return igdtype;
    }

    public void setIgdtype(String igdtype) {
        this.igdtype = igdtype;
    }

    public double getIgdamount() {
        return igdamount;
    }

    public void setIgdamount(double igdamount) {
        this.igdamount = igdamount;
    }

}
