package com.example.babalzza.Entity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class UserIngredient extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 1;

    private Integer userigd_id;
    private Integer user_id;
    private Integer igd_id;
    private Integer amount;
    private Integer reservedamount;
    private String buydate;
    private String expirationdate;

    public UserIngredient(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null , igd_id INTEGER not null," +
                " amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
        String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null , image image, " +
                "code INTEGER not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
        String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
                "country text not null, time text not null, level text not null, recipelink text not null)";
        String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
                "igdtype text not null , igdamount double not null, PRIMARY KEY (menu_id, igd_id))";
        String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
                "score double not null , recentassign text not null, PRIMARY KEY (user_id, menu_id))";
        String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory(user_id INTEGER NOT NULL, menu_id INTEGER NOT NULL," +
                " meal text NOT NULL, result text not null, PRIMARY KEY (user_id, menu_id))";

        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int version_old, int current_version) {
        String DROP_USERINGREDIENT = "DROP TABLE IF EXISTS UserIngredient";
        String DROP_INGREDIENT = "DROP TABLE IF EXISTS Ingredient";
        String DROP_MENU = "DROP TABLE IF EXISTS Menu";
        String DROP_MENUINGREDIENT = "DROP TABLE IF EXISTS MenuIngredient";
        String DROP_MENUSCORE = "DROP TABLE IF EXISTS MenuScore";
        String DROP_SCHEDULEHISTORY = "DROP TABLE IF EXISTS ScheduleHistory";

        db.execSQL(DROP_INGREDIENT);
        db.execSQL(DROP_MENU);
        db.execSQL(DROP_MENUINGREDIENT);
        db.execSQL(DROP_USERINGREDIENT);
        db.execSQL(DROP_MENUSCORE);
        db.execSQL(DROP_SCHEDULEHISTORY);

        onCreate(db);
    }

    public ArrayList<UserIngredient> getAllUserIngredient(Context ct) {
        String query = "SELECT * FROM UserIngredient";
        ArrayList<UserIngredient> userIngredientArrayList = new ArrayList<UserIngredient>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);

        if (c != null) {
            while (c.moveToNext()) {
                UserIngredient userIngredient = new UserIngredient(ct);

                userIngredient.setUserigd_id(c.getInt(0));
                userIngredient.setUser_id(c.getInt(1));
                userIngredient.setIgd_id(c.getInt(2));
                userIngredient.setAmount(c.getInt(3));
                userIngredient.setReservedamount(c.getInt(4));
                userIngredient.setBuydate(c.getString(5));
                userIngredient.setExpirationdate(c.getString(6));

                userIngredientArrayList.add(userIngredient);
            }
        }
        database.close();
        return userIngredientArrayList;
    }

    public String InsertData(Integer user_id, Integer igd_id, Integer amount, Integer reservedamount, String buydate, String expirationdate) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into UserIngredient (user_id, igd_id, amount, reservedamount, buydate, expirationdate) " +
                    "values (" + user_id + "," + igd_id + ", " + amount + ", " + reservedamount + ", '" + buydate + "', '" + expirationdate + "')";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public static void csvToDB(Context ct) {
        try {
            InputStream in = ct.getResources().openRawResource(R.raw.useringredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    UserIngredient userIngredient = new UserIngredient(ct);
                    String[] list = line.split(",");

                    // autoincrement로 설정되어 필요없음
                    Integer userigd_id = Integer.parseInt(list[0]);

                    Integer user_id = Integer.parseInt(list[1]);
                    Integer igd_id = Integer.parseInt(list[2]);
                    Integer amount = Integer.parseInt(list[3]);
                    Integer reservedamount = Integer.parseInt(list[4]);
                    String buydate = list[5];
                    String expirationdate = list[6];

                    userIngredient.InsertData(user_id, igd_id, amount, reservedamount, buydate, expirationdate);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String InsertData(String name, Integer quantity, String duedate) {
        SQLiteDatabase database = this.getWritableDatabase();
        try {
            String query = "insert into UserIngredient (name, quantity, duedate) values ('" + name + "'," + quantity + ",'" + duedate + "')";
            database.execSQL(query);
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage();
        } finally {
            database.close();
        }
    }

    public Cursor getIngredients() {
        try {
            String selectQuery = "SELECT * FROM UserIngredient";
            SQLiteDatabase database = this.getWritableDatabase();
            Cursor cursor = database.rawQuery(selectQuery, null);
            return cursor;
        } catch (Exception ex) {
            return null;
        }
    }

    public ArrayList<UserIngredient.Ingredient> getAllIngredients() {
        String query = "SELECT * FROM UserIngredient";
        ArrayList<Ingredient> ingredients = new ArrayList<Ingredient>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                Integer id = c.getInt(0);
                String name = c.getString(1);
                Integer quantity = c.getInt(2);
                String duedate = c.getString(3);

                Ingredient ing = new Ingredient(id, name, quantity, duedate);

                ingredients.add(ing);
            }
        }
        database.close();
        return ingredients;
    }


    //Jaeyoung 2019.11.22 update
    //UD function

    public String update(ContentValues values, String whereClause){
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            database.update("UserIngredient", values, whereClause, null);
            database.close();
            return "Updated Successfully";
        } catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public String delete(String id){
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            database.delete("UserIngredient", "userigd_id ="+id, null);
            database.close();
            return "Deleted Successfully";
        } catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public Integer getUserigd_id() {
        return userigd_id;
    }

    public void setUserigd_id(Integer userigd_id) {
        this.userigd_id = userigd_id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getIgd_id() {
        return igd_id;
    }

    public void setIgd_id(Integer igd_id) {
        this.igd_id = igd_id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getReservedamount() {
        return reservedamount;
    }

    public void setReservedamount(Integer reservedamount) {
        this.reservedamount = reservedamount;
    }

    public String getBuydate() {
        return buydate;
    }

    public void setBuydate(String buydate) {
        this.buydate = buydate;
    }

    public String getExpirationdate() {
        return expirationdate;
    }

    public void setExpirationdate(String expirationdate) {
        this.expirationdate = expirationdate;
    }

    public class Ingredient {
        private Integer id;
        private String name;
        private Integer quantity;
        private String duedate;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }

        public String getDuedate() {
            return duedate;
        }

        public void setDuedate(String duedate) {
            this.duedate = duedate;
        }


        public Ingredient (Integer id, String name, Integer quantity, String duedate) {
            super();
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.duedate = duedate;
        }
    }
}