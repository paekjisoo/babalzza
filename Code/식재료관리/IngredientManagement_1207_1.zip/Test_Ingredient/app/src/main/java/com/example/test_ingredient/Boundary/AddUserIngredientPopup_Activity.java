package com.example.test_ingredient.Boundary;

import android.app.AlertDialog;
import android.app.DatePickerDialog;

import java.text.SimpleDateFormat;

import android.content.DialogInterface;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.test_ingredient.Controller.IngredientController;
import com.example.test_ingredient.Entity.Ingredient;
import com.example.test_ingredient.Entity.UserIngredient;
import com.example.test_ingredient.R;

public class AddUserIngredientPopup_Activity extends AppCompatActivity {

    Ingredient ingredient;

    int y = 0, m = 0, d = 0;
    int ytoday = 2019, mtoday = 11, dtoday = 7;
    int expirationDue;
    int p;

    TextView showBuyDate;
    Button editBuyDate;
    Spinner reserveType;
    TextView showExpirationDateRefrigerated;
    TextView showExpirationDateFreezed;
    Button editExpirationDate;
    TextView getExpirationDate;
    Button buttonSaveIngredient;
    String dueDate;
    IngredientController ingredientController;
    TextView showName;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_addpopup);

        ingredient = (Ingredient) getIntent().getSerializableExtra("ingredient");
        ingredientController = new IngredientController(this);

        ImageView showImage = findViewById(R.id.showImage);
        final EditText editQuantity = findViewById(R.id.editQuantity);
        showExpirationDateRefrigerated = findViewById(R.id.showExpirationDateRefrigerated);
        showExpirationDateFreezed = findViewById(R.id.showExpirationDateFreezed);
        editExpirationDate = findViewById(R.id.buttonEditExpirationDate);
        getExpirationDate = findViewById(R.id.editExpirationDate);

        // 식재료명, 단위
        showName = findViewById(R.id.showName);
        TextView unit = findViewById(R.id.unit);


        showName.setText(ingredient.getName());
        unit.setText(ingredient.getMeasure());

        // 구매일 설정
        showBuyDate = findViewById(R.id.showBuyDate);
        editBuyDate = findViewById(R.id.buttonEditBuyDate);

        editBuyDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBuyDate();
            }
        });

        //보관방법 설정
        showExpirationDateRefrigerated.setText("유통기한이 표시됩니다");
        reserveType = findViewById(R.id.reserveType);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.reserveType,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reserveType.setAdapter(adapter);
        //보관방법에 따른 유통기한 설정
        reserveType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (y == 0) {
                    showExpirationDateRefrigerated.setText("유통기한이 표시됩니다");
                    return;
                }
                p = position;
                switch (position) {
                    case 1:
                        expirationDue = Integer.parseInt(ingredient.getRefrigeratedterm());
                        String expirationDate = changeDate(y, m, d, expirationDue);
                        showExpirationDateRefrigerated.setText(expirationDate);
                        showExpirationDateRefrigerated.setVisibility(View.VISIBLE);
                        showExpirationDateFreezed.setVisibility(View.GONE);
                        editExpirationDate.setVisibility(View.GONE);
                        getExpirationDate.setVisibility(View.GONE);
                        dueDate = expirationDate;
                        break;
                    case 2:
                        expirationDue = Integer.parseInt(ingredient.getFreezedterm());
                        expirationDate = changeDate(y, m, d, expirationDue);
                        dueDate = expirationDate;
                        showExpirationDateFreezed.setText(expirationDate);
                        showExpirationDateRefrigerated.setVisibility(View.GONE);
                        showExpirationDateFreezed.setVisibility(View.VISIBLE);
                        editExpirationDate.setVisibility(View.GONE);
                        getExpirationDate.setVisibility(View.GONE);
                        break;
                    case 0:
                        showExpirationDateRefrigerated.setVisibility(View.GONE);
                        showExpirationDateFreezed.setVisibility(View.GONE);
                        editExpirationDate.setVisibility(View.VISIBLE);
                        getExpirationDate.setVisibility(View.VISIBLE);
                        dueDate = null;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        //유통기한 직접입력
        editExpirationDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExpirationDate();
                dueDate = getExpirationDate.getText().toString();
            }
        });

        //내용 저장
        buttonSaveIngredient = findViewById(R.id.buttonSaveIngredient);
        buttonSaveIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity;
                try{
                    quantity = Integer.parseInt(editQuantity.getText().toString());
                }catch(NumberFormatException e){
                    String message = "수량을 잘못 입력했습니다.";
                    showErrorMessage(message);
                    return;
                }
                int check = 0;

                String today = getToday();

                if(editQuantity.getText().toString().equals("")) check = 1;
                else if(quantity <= 0) check = 4;
                else if(showBuyDate.getText().toString().equals("") ) check = 2;
                else if(showBuyDate.getText().toString().compareTo(today) > 0) check = 6;
                else if(p == 0 && getExpirationDate.getText().toString().equals("")) check = 3;
                else if(p == 0 && getExpirationDate.getText().toString().compareTo(showBuyDate.getText().toString()) <= 0) check = 5;
                else if(p == 1 && showExpirationDateRefrigerated.getText().toString().compareTo(showBuyDate.getText().toString()) <= 0) check = 5;
                else if(p == 2 && showExpirationDateFreezed.getText().toString().compareTo(showBuyDate.getText().toString()) <= 0) check = 5;
                else check = 0;

                switch (check) {
                    case 0:
                        if(p == 0) dueDate = getExpirationDate.getText().toString();
                        else if (p == 1) dueDate = showExpirationDateRefrigerated.getText().toString();
                        else if (p == 2) dueDate = showExpirationDateFreezed.getText().toString();

                        UserIngredient u = (UserIngredient) getIntent().getSerializableExtra("userIngredient");
                        u.setAmount(quantity);
                        u.setBuydate(showBuyDate.getText().toString());
                        u.setExpirationdate(dueDate);
                        ingredientController.insertUserIngredient(u);
                        confirm(ingredient.getName(), u.getAmount(), ingredient.getMeasure());


                        break;
                    case 1:
                        String message = "수량을 잘못 입력했습니다.";
                        showErrorMessage(message);
                        break;
                    case 2:
                        message = "구매일을 입력하지 않았습니다.";
                        showErrorMessage(message);
                        break;
                    case 3:
                        message = "유통기한을 입력하지 않았습니다.";
                        showErrorMessage(message);
                        break;
                    case 4:
                        message = "식재료 수량이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                    case 5:
                        message = "유통기한이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                    case 6:
                        message = "구매일이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                }



            }
        });
    }
    // 구매일 달력에서 가져오기
    void showBuyDate() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                y = year;
                m = month + 1;
                d = dayOfMonth;
                String buyDate;
                if(month+1 < 10)  {
                    if(dayOfMonth < 10)
                        buyDate = year + "-0" + (month+1) + "-0" + dayOfMonth;
                    else
                        buyDate = year + "-0" + (month+1) + "-" + dayOfMonth;
                }
                else {
                    if(dayOfMonth < 10)
                        buyDate = year + "-" + (month+1) + "-0" + dayOfMonth;
                    else
                        buyDate = year + "-" + (month+1) + "-" + dayOfMonth;
                }
                showBuyDate.setText(buyDate);
            }
        }, ytoday, mtoday, dtoday);
        datePickerDialog.show();
    }
    // 유통기한 달력에서 가져오기
    void showExpirationDate() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String ExpirationDate;
                if(month+1 < 10)  {
                    if(dayOfMonth < 10)
                        ExpirationDate = year + "-0" + (month+1) + "-0" + dayOfMonth;
                    else
                        ExpirationDate = year + "-0" + (month+1) + "-" + dayOfMonth;
                }
                else {
                    if(dayOfMonth < 10)
                        ExpirationDate = year + "-" + (month+1) + "-0" + dayOfMonth;
                    else
                        ExpirationDate = year + "-" + (month+1) + "-" + dayOfMonth;
                }
                getExpirationDate.setText(ExpirationDate);
            }
        }, ytoday, mtoday, dtoday);
        datePickerDialog.show();
    }

    String changeDate(int year, int month, int dayofMonth, int add) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd");
        // 날짜 더하기
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, dayofMonth);
        cal.add(Calendar.DATE, add);
        if (cal.get(Calendar.MONTH) + 1 < 10) {
            if (cal.get(Calendar.DAY_OF_MONTH) < 10) {
                return cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH) + 1) + "-0" + cal.get(Calendar.DAY_OF_MONTH);
            } else
                return cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
        } else {
            if (cal.get(Calendar.DAY_OF_MONTH) < 10) {
                return cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-0" + cal.get(Calendar.DAY_OF_MONTH);
            } else
                return cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
        }
    }

    void confirm(String name, int quantity, String unit){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String message = name +" "+quantity+""+unit+"이(가) 추가되었습니다.";
        builder.setMessage(message);
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    void showErrorMessage(String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);

        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    String getToday(){
        if (mtoday + 1 < 10) {
            if (dtoday < 10) {
                return ytoday + "-0" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-0" + (mtoday + 1) + "-" + dtoday;
        } else {
            if (dtoday < 10) {
                return ytoday + "-" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-" + (mtoday + 1) + "-" + dtoday;
        }
    }
}
