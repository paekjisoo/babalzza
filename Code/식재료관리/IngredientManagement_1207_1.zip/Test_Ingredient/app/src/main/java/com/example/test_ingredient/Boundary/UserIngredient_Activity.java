package com.example.test_ingredient.Boundary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test_ingredient.Controller.IngredientController;
import com.example.test_ingredient.Entity.Ingredient;
import com.example.test_ingredient.R;
import com.example.test_ingredient.Entity.UserIngredient;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.util.ArrayList;

public class UserIngredient_Activity extends AppCompatActivity {

    private IngredientController ingredientController;
    private ArrayList<UserIngredient> userIngredientList;
    private ArrayList<Ingredient> ingredientList;
    private UserIngredientAdapter adapter;
    private UserIngredient gridItem;

    FloatingActionButton fab;
    GridView userigd_gv;
    AlertDialog.Builder builder;
    AlertDialog dialog;

    TextView tv_name;
    TextView tv_type;
    TextView tv_state;

    TextView tv_amount;
    TextView tv_buydate;
    TextView tv_expdate;
    TextView tv_textamount;
    TextView tv_textbuydate;
    TextView tv_textexpdate;

    EditText edit_amount;
    EditText edit_buydate;
    EditText edit_expdate;

    Button btn_addMemo;
    Button btn_saveupdate;
    Button btn_updateigd;
    Button btn_deleteigd;

    SharedPreferences csvload;

    int ytoday = 2019, mtoday = 11, dtoday = 7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_main);

        csvload = getSharedPreferences("is_csv_loaded", Activity.MODE_PRIVATE);
        ingredientController = new IngredientController(this);

        String result = csvload.getString("is_csv_loaded", "");
        if (result==""){
            ingredientController.csvToDB_Ingredient(this);
            ingredientController.csvToDB_UserIngredient(this);
            SharedPreferences.Editor editor = csvload.edit();
            editor.putString("is_csv_loaded", "done");
            editor.commit();
        }

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        userigd_gv = (GridView)findViewById(R.id.userigd_gv);

        userIngredientList = ingredientController.getAllUserIngredients();
        ingredientList = ingredientController.getAllingredients();

        adapter = new UserIngredientAdapter(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addintent = new Intent(UserIngredient_Activity.this, AddUserIngredient_Activity.class);
                UserIngredient_Activity.this.startActivity(addintent);
            }
        });

        // gridview 아이템 클릭 효과 선언
        userigd_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                gridItem = (UserIngredient)userigd_gv.getItemAtPosition(position);

                final View popup = inflater_dg.inflate(R.layout.userigd_detail, null);

                tv_name= popup.findViewById(R.id.detail_name);
                tv_type= popup.findViewById(R.id.detail_type);
                tv_state= popup.findViewById(R.id.detail_state);

                tv_amount= popup.findViewById(R.id.detail_amount);
                tv_buydate= popup.findViewById(R.id.detail_buydate);
                tv_expdate= popup.findViewById(R.id.detail_expdate);
                tv_textamount= popup.findViewById(R.id.textAmount);
                tv_textbuydate= popup.findViewById(R.id.textBuydate);
                tv_textexpdate= popup.findViewById(R.id.textExpdate);

                edit_amount = popup.findViewById(R.id.editAmount);
                edit_buydate = popup.findViewById(R.id.editBuydate);
                edit_expdate = popup.findViewById(R.id.editExpirationDate);

                Integer index_igd = userIngredientList.get(position).getIgd_id();
                tv_name.setText(ingredientList.get(index_igd).getName());
                switch (Integer.parseInt(ingredientList.get(index_igd).getCode())) {
                    case 11: tv_type.setText("소고기");break;
                    case 12: tv_type.setText("돼지고기");break;
                    case 13: tv_type.setText("닭고기");break;
                    case 14: tv_type.setText("기타 육류");break;
                    case 15: tv_type.setText("가공육");break;
                    case 21: tv_type.setText("생선");break;
                    case 22: tv_type.setText("어패륲");break;
                    case 23: tv_type.setText("갑각류");break;
                    case 24: tv_type.setText("낙지 및 오징어");break;
                    case 25: tv_type.setText("기타 해물류");break;
                    case 26: tv_type.setText("가공해물류");break;
                    case 31: tv_type.setText("채소류");break;
                    case 32: tv_type.setText("뿌리채소류");break;
                    case 33: tv_type.setText("과일류");break;
                    case 34: tv_type.setText("가공과채류");break;
                    case 35: tv_type.setText("버섯류");break;
                    case 41: tv_type.setText("계란류");break;
                    case 42: tv_type.setText("유제품류");break;
                    case 43: tv_type.setText("치즈류");break;
                    case 51: tv_type.setText("곡물류");break;
                    case 52: tv_type.setText("콩 및 견과류");break;
                    case 53: tv_type.setText("가공곡물류");break;
                    case 61: tv_type.setText("시판식재료류");break;
                    case 62: tv_type.setText("기본양념");break;
                    case 63: tv_type.setText("기름류");break;
                    case 64: tv_type.setText("음료류");break;
                    case 65: tv_type.setText("가공식품류");break;

                }

                if (gridItem.getExpirationdate().compareTo(getToday()) < 0){
                    tv_state.setText("버려야 할 식재료");
                    tv_state.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorRed));
                }
                else if(gridItem.getExpirationdate().compareTo(setDate(ytoday, mtoday, dtoday)) <=0){
                    tv_state.setText("빨리 써야 할 식재료");
                    tv_state.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorYellow));
                }
                else {
                    tv_state.setVisibility(View.INVISIBLE);
                }

                Integer amount = userIngredientList.get(position).getAmount();
                tv_amount.setText(amount.toString());
                tv_buydate.setText(userIngredientList.get(position).getBuydate());
                tv_expdate.setText(userIngredientList.get(position).getExpirationdate());

                builder.setView(popup);

                btn_addMemo = popup.findViewById(R.id.addMemo);
                btn_saveupdate = popup.findViewById(R.id.saveUpdate);
                btn_updateigd = popup.findViewById(R.id.updateIngredient);
                btn_deleteigd = popup.findViewById(R.id.deleteIngredient);

                // Update 클릭 효과
                btn_updateigd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tv_name.setVisibility(View.VISIBLE);

                        tv_amount.setVisibility(View.GONE);
                        edit_amount.setVisibility((View.VISIBLE));
                        edit_amount.setText(tv_amount.getText());

                        tv_buydate.setVisibility(View.GONE);
                        edit_buydate.setVisibility((View.VISIBLE));
                        edit_buydate.setText(tv_buydate.getText());

                        tv_expdate.setVisibility(View.GONE);
                        edit_expdate.setVisibility(View.VISIBLE);
                        edit_expdate.setText(tv_expdate.getText());

                        btn_addMemo.setVisibility(View.GONE);
                        btn_updateigd.setVisibility(View.GONE);
                        btn_deleteigd.setVisibility(View.GONE);
                        btn_saveupdate.setVisibility(View.VISIBLE);}
                });

                // Delete 클릭 효과
                btn_deleteigd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name = tv_name.getText().toString();
                        dialog.dismiss();

                        builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                        builder.setMessage(name +" 을(를) 삭제하시겠습니까?");
                        builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ingredientController.deleteUserIngredient(gridItem.getUserigd_id());
                                updatePage();
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.create().show();
                    }
                });

                btn_saveupdate.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        String name = tv_name.getText().toString();
                        Integer amount;
                        String buydate = edit_buydate.getText().toString();
                        String expdate = edit_expdate.getText().toString();
                        String newbuydate, newexpdate;
                        TextView warnMessage = popup.findViewById(R.id.warnMessage);
                        String message;
                        try{
                            amount = Integer.parseInt(edit_amount.getText().toString());
                        }catch(NumberFormatException e){
                            message = "에러: 수량을 잘못 입력했습니다.";
                            warnMessage.setText(message);
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        SimpleDateFormat dateForm = new SimpleDateFormat("yyyy-MM-dd");

                        try {
                            newbuydate = dateForm.format(dateForm.parse(buydate));
                        } catch (Exception e) {
                            message = "에러: 구매일을 잘못 입력했습니다.";
                            warnMessage.setText(message);
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        try {
                            newexpdate = dateForm.format(dateForm.parse(expdate));
                        } catch (Exception e) {
                            warnMessage.setText("에러: 유통기한을 잘못 입력했습니다.");
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        if(amount <= 0) {
                            warnMessage.setText("에러: 수량을 잘못 입력했습니다.");
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }
                        else if(buydate.compareTo(getToday()) > 0){
                            warnMessage.setText("에러: 구매일을 잘못 입력했습니다.");
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }
                        else if(expdate.compareTo(buydate) <= 0){
                            warnMessage.setText("에러: 유통기한을 잘못 입력했습니다.");
                            warnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        UserIngredient edituserigd = userIngredientList.get(position);
                        edituserigd.setAmount(amount);
                        edituserigd.setBuydate(newbuydate);
                        edituserigd.setExpirationdate(newexpdate);

                        ingredientController.updateUserIngredient(edituserigd, gridItem.getUserigd_id());
                        dialog.dismiss();

                        builder = new AlertDialog.Builder(UserIngredient_Activity.this);
                        builder.setMessage(name +" 이(가) 수정되었습니다");
                        builder.setNeutralButton("확인", null);
                        builder.create().show();
                    }
                });

                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        userIngredientList = ingredientController.getAllUserIngredients();
        adapter = new UserIngredientAdapter(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);
    }

    public void updatePage() {
        userIngredientList = ingredientController.getAllUserIngredients();
        adapter = new UserIngredientAdapter(userIngredientList, ingredientList);
        userigd_gv.setAdapter(adapter);
    }

    String getToday(){
        if (mtoday + 1 < 10) {
            if (dtoday < 10) {
                return ytoday + "-0" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-0" + (mtoday + 1) + "-" + dtoday;
        } else {
            if (dtoday < 10) {
                return ytoday + "-" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-" + (mtoday + 1) + "-" + dtoday;
        }
    }

    String setDate(int ytoday, int mtoday, int dtoday){
        if (mtoday + 1 < 10) {
            if (dtoday+3 < 10) {
                return ytoday + "-0" + (mtoday + 1) + "-0" + (dtoday+3);
            } else
                return ytoday + "-0" + (mtoday + 1) + "-" + (dtoday+3);
        } else {
            if (dtoday+3 < 10) {
                return ytoday + "-" + (mtoday + 1) + "-0" + (dtoday+3);
            } else
                return ytoday + "-" + (mtoday + 1) + "-" + (dtoday+3);
        }
    }


    public class UserIngredientAdapter extends BaseAdapter{
        private ArrayList<UserIngredient> userIngredientList;
        private ArrayList<Ingredient> ingredientList;

        public UserIngredientAdapter(ArrayList<UserIngredient> userIngredientList, ArrayList<Ingredient> ingredientList) {
            this.userIngredientList = userIngredientList;
            this.ingredientList = ingredientList;
        }

        @Override
        public int getCount() {
            return userIngredientList.size();
        }

        @Override
        public Object getItem(int i) {
            return userIngredientList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int position = i;
            final Context context = viewGroup.getContext();

            if (view == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.userigd_item, viewGroup, false);
            }

            ImageView userigdImage = (ImageView) view.findViewById(R.id.userigdImage);
            TextView userigdname = (TextView) view.findViewById(R.id.userigdName);
            if(userIngredientList.get(i).getExpirationdate().compareTo(getToday()) < 0)
                userigdname.setTextColor(ContextCompat.getColor(context, R.color.colorRed));
            else if(userIngredientList.get(i).getExpirationdate().compareTo(setDate(ytoday, mtoday, dtoday)) < 0)
                userigdname.setTextColor(ContextCompat.getColor(context, R.color.colorYellow));
            else userigdname.setTextColor(ContextCompat.getColor(context, R.color.colorBlack));


            userigdImage.setImageResource(R.drawable.useritemimage);
            UserIngredient userigditem = userIngredientList.get(position);
            int userigditem_igdid = userigditem.getIgd_id();
            userigdname.setText(ingredientList.get(userigditem_igdid).getName());

            return view;
        }
    }

}
