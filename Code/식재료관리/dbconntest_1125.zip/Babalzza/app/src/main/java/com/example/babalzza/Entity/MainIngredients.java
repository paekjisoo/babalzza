package com.example.babalzza.Entity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class MainIngredients extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "IngredientsSample.db";
    private static final int DATABASE_VERSION = 1;
    public static MainIngredients mainIngredients;

    public static void main(String[] args) {

        try {
            File csv = new File("C:/Programming/AndroidStudioProjects/1123/Babalzza/app/src/main/res/raw/test.csv");
            BufferedReader br = new BufferedReader(new FileReader(csv));
            String line;
            while ((line = br.readLine()) != null) {
                String[] list = line.split(",");

                Integer id = Integer.parseInt(list[0]);
                String name = list[1];
                String classifier = list[2];
                Integer code = Integer.parseInt(list[3]);
                String duedate = list[4];

                mainIngredients.InsertData(id, name, classifier, code, duedate);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public MainIngredients (Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS IngredientsSample ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name text not null , quantity INTEGER not null, duedate text not null)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query;
        query = "DROP TABLE IF EXISTS IngredientsSample";
        db.execSQL(query);
        onCreate(db);
    }

    public String InsertData(Integer id, String name, String classifier, Integer code, String duedate) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "insert into  MainIngredients (id, name, classifier, code, duedate) values ('" + id + "'," + name + ",'" + classifier + "', " + code + ", " + duedate +")";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public ArrayList<MainIngredients.TestIngredients> getAllIngredients() {
        String query = "SELECT * FROM MainIngredients";
        ArrayList<MainIngredients.TestIngredients> ingredients = new ArrayList<TestIngredients>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                Integer id = c.getInt(0);
                String name = c.getString(1);
                String classifier = c.getString(2);
                Integer code = c.getInt(3);
                String duedate = c.getString(4);

                MainIngredients.TestIngredients ing = new MainIngredients.TestIngredients(id, name, classifier, code, duedate);

                ingredients.add(ing);
            }
        }
        return ingredients;
    }

    public class TestIngredients {
        private Integer id;
        private String name;
        private String classifier;
        private Integer code;
        private String duedate;

        public TestIngredients(Integer id, String name, String classifier, Integer code, String duedate) {
            super();
            this.id=id;
            this.name = name;
            this.classifier = classifier;
            this.code = code;
            this.duedate = duedate;
        }

        public Integer getId() {return id;}
        public void setId(Integer id) {this.id = id;}

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }

        public String getClassifier() {
            return classifier;
        }
        public void setClassifier(String classifier) {
            this.classifier = classifier;
        }

        public Integer getCode() {
            return code;
        }
        public void setCode(Integer code) {
            this.code = code;
        }

        public String getDueDate() {
            return duedate;
        }
        public void setDueDate(String duedate) {
            this.duedate = duedate;
        }
    }
}
