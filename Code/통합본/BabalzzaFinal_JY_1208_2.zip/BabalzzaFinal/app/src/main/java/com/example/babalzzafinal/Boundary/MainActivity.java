package com.example.babalzzafinal.Boundary;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.babalzzafinal.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
    }

    public void activity_LogInScreen(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
    }

    public void activity_JoinScreen(View view) {
    //    Intent intent = new Intent(this, Join_1.class);
    //    startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        System.runFinalization();
        System.exit(0);
    }
}

