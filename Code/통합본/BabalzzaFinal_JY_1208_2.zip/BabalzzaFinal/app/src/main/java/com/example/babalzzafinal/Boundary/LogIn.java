package com.example.babalzzafinal.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//import com.example.babalzzafinal.Controller.LoginController;
import com.example.babalzzafinal.Controller.IngredientController;
import com.example.babalzzafinal.Entity.UserInformation;
import com.example.babalzzafinal.Controller.LoginController;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

public class LogIn extends AppCompatActivity {
    private UserInformation userInformation;
    static ArrayList<UserIngredient> userIngredientArrayList;
    IngredientController ingredientController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Intent intent = getIntent();

        userInformation = new UserInformation(getApplicationContext());
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수
    public void activity_LogIn(View view) {
        ingredientController = new IngredientController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();


        EditText et_ID = findViewById(R.id.et_ID);
        EditText et_Password = findViewById(R.id.et_Password);
        String userId = et_ID.getText().toString();
        String password = et_Password.getText().toString();

        try {
            String result = LoginController.login(getApplicationContext(), userInformation, userId, password);

            if (true) {

                Intent login_successful;
                if(userIngredientArrayList.isEmpty())
                    login_successful = new Intent(this, NoIngredient.class);
                else
                    login_successful = new Intent(this, Recommend_Main.class);
                login_successful.putExtra("userid", userId);
                startActivity(login_successful);
                finish();
            }
            else
                Toast.makeText(LogIn.this, result, Toast.LENGTH_LONG).show();
        }
        catch (Exception ex) {
            String message = ex.getMessage().toString();
            Toast.makeText(LogIn.this, message, Toast.LENGTH_LONG).show();
            return;
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, com.example.babalzzafinal.Boundary.MainActivity.class);
        startActivity(intent);
        finish();
    }

}