package com.example.babalzzafinal.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import static com.example.babalzzafinal.Boundary.LogIn.userIngredientArrayList;

public class NoIngredient extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_empty);

        Button addFirst = findViewById(R.id.addFirstButton);
        addFirst.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(NoIngredient.this, UserIngredient_Activity.class);
                startActivity(intent);
            }
        });



        //bottomNavigationView 에서 클릭
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        if(userIngredientArrayList.isEmpty()) {
                            Intent intent = new Intent(NoIngredient.this, NoIngredient.class);
                        }
                        else {
                            Intent intent = new Intent(NoIngredient.this, UserIngredient_Activity.class);
                            startActivity(intent);
                        }
                        return true;
                    case R.id.schedule:
                        Toast.makeText(NoIngredient.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.memo:
                        Toast.makeText(NoIngredient.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                }
                return false;
            }
        });

    }

}
