package com.example.babalzzafinal.Boundary;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.IngredientController;
import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Entity.Ingredient;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Memo_Main extends AppCompatActivity {

    Button btn_memoadd;
    Button btn_memodel;
    Button btnConfirm;
    Button btnCancel;

    EditText et_igdname;
    EditText et_amount;

    ListView listview;

    ArrayList<ShoppingMemo> memoList;
    CustomChoiceListViewAdapter adapter;

    MemoController memoController;

    IngredientController ingredientController;
    ArrayList<UserIngredient> userIngredientArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_main);

        ingredientController = new IngredientController(this);

        //bottomNavigationView 에서 클릭
        userIngredientArrayList = ingredientController.getAllUserIngredients();

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        Intent intent;
                        if(userIngredientArrayList.isEmpty()) {
                            intent = new Intent(Memo_Main.this, NoIngredient.class);
                        }
                        else {
                            Toast.makeText(Memo_Main.this, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(Memo_Main.this, UserIngredient_Activity.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.schedule:
                        Toast.makeText(Memo_Main.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        intent = new Intent(Memo_Main.this, Recommend_Main.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.memo:
                        Toast.makeText(Memo_Main.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                }
                return false;
            }
        });

        btn_memoadd = (Button) findViewById(R.id.memo_add);
        btn_memodel = (Button) findViewById(R.id.memo_del);

        memoController = new MemoController(this);
        memoList=memoController.getAllMemo();

        adapter = new CustomChoiceListViewAdapter(memoList);

        listview = (ListView) findViewById(R.id.memo_listview_main);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addData();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;

                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
                        memoController.deleteMemo(adapter.getItem(i).getMemo_Id());
                    }
                }
                memoList = memoController.getAllMemo();
                adapter = new CustomChoiceListViewAdapter(memoList);
                listview.setAdapter(adapter);
            }
        });
    }

    public void addData(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.memo_add, (ViewGroup)findViewById(R.id.Relative));
        builder.setTitle("장보기 메모 추가");
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.memo_et_igdname);
        et_amount = addpopup.findViewById(R.id.memo_et_amount);
        btnConfirm = addpopup.findViewById(R.id.memo_confirm);
        btnCancel = addpopup.findViewById(R.id.memo_cancel);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());
                Ingredient ing = ingredientController.getIngredient(igdname);
                TextView memoWarnMessage = addpopup.findViewById(R.id.memoWarnMessage);
                if(ing == null){
                    memoWarnMessage.setText("식재료명이 틀렸습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                }
                else{
                    memoWarnMessage.setVisibility(View.INVISIBLE);
                    String unit = ingredientController.getIngredient(igdname).getMeasure();

                    memoController.InsertMemo(igdname, amount, unit);
                    memoList = memoController.getAllMemo();
                    adapter.setItemList(memoList);
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                }

            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(Memo_Main.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> memoList = new ArrayList<ShoppingMemo>();

        public CustomChoiceListViewAdapter(ArrayList<ShoppingMemo> memoList) {
            this.memoList = memoList;
        }

        @Override
        public int getCount() {
            return memoList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return memoList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo> memoList){
            this.memoList = memoList;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.memo_igdname);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.memo_amount);
            TextView ing_measure = convertView.findViewById(R.id.memo_measure);

            ShoppingMemo memo = memoList.get(position);

            ing_name.setText(memo.getIgdname());
            ing_amount.setText(""+memo.getAmount()+"");
            ing_measure.setText(memo.getUnit());

            return convertView;
        }
    }
}
