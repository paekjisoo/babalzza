package com.example.babalzzafinal.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.babalzzafinal.Entity.ShoppingMemo;

import java.util.ArrayList;

public class MemoController extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "babalzzadb10.db";
    private static final String T_MEMO = "Memo";
    private static final int dBVERSION = 1;

    private final String CREATE_MEMO = "CREATE TABLE IF NOT EXISTS ShoppingMemo (memo_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "igdname TEXT not null, amount INTEGER not null, unit Text not null)";

    private static SQLiteDatabase db;

    public MemoController(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, dBVERSION);
        db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_MEMO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_MEMO);
    }

    public boolean InsertMemo(String igdname, Integer amount, String unit) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("igdname", igdname);
        cv.put("amount", amount);
        cv.put("unit", unit);
        return  db.insert("ShoppingMemo", null, cv)!= -1;
    }

    public ArrayList<ShoppingMemo> getAllMemo() {
        ArrayList<ShoppingMemo> memoList = new ArrayList<ShoppingMemo>();
        String query = "SELECT * FROM ShoppingMemo";
        Cursor c = db.rawQuery(query, null);

        if (c != null) {
            while (c.moveToNext()) {
                ShoppingMemo memo = new ShoppingMemo();
                memo.setMemo_Id(c.getInt(0));
                memo.setIgdname(c.getString(1));
                memo.setAmount(c.getInt(2));
                memo.setUnit(c.getString(3));

                memoList.add(memo);
            }
        }
        return memoList;
    }

    public String deleteMemo(Integer memo_id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("ShoppingMemo", "memo_id ="+memo_id, null);
        return "Deleted Successfully";
    }
}