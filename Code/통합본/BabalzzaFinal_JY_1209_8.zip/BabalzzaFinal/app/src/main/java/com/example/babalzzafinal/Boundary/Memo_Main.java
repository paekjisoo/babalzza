package com.example.babalzzafinal.Boundary;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.Ingredient;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Memo_Main extends AppCompatActivity {

    Button btn_memoadd;
    Button btn_memodel;
    Button btnConfirm;
    Button btnCancel;

    EditText et_igdname;
    EditText et_amount;

    ListView listview;

    CustomChoiceListViewAdapter adapter;

    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_main);

        ingredientController = new RecommendController(this);
        memoController = new MemoController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();
        shoppingMemoArrayList = memoController.getAllMemo();

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        userIngredientArrayList = ingredientController.getAllUserIngredients();
                        Intent intent;
                        if(userIngredientArrayList.isEmpty()) {
                            intent = new Intent(Memo_Main.this, NoIngredient.class);
                        }
                        else {
                            Toast.makeText(Memo_Main.this, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(Memo_Main.this, UserIngredient_Activity.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.schedule:
                        Toast.makeText(Memo_Main.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        intent = new Intent(Memo_Main.this, Recommend_Main.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.memo:
                        shoppingMemoArrayList = memoController.getAllMemo();
                        if(shoppingMemoArrayList.isEmpty()){
                            intent = new Intent(Memo_Main.this, NoMemo.class);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Toast.makeText(Memo_Main.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                        }
                        return true;
                }
                return false;
            }
        });

        btn_memoadd = (Button) findViewById(R.id.memo_add);
        btn_memodel = (Button) findViewById(R.id.memo_del);

        adapter = new CustomChoiceListViewAdapter(shoppingMemoArrayList);

        listview = (ListView) findViewById(R.id.memo_listview_main);
        listview.setAdapter(adapter);
        listview.setLongClickable(true);
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Memo_Main.this);
                LayoutInflater inflater_dg = getLayoutInflater();

                final View popup = inflater_dg.inflate(R.layout.memo_update, null);
                builder.setView(popup);

                final AlertDialog dialog = builder.create();

                final TextView memoUpdateName = popup.findViewById(R.id.memoUpdateName);
                final TextView memoUpdateAmount = popup.findViewById(R.id.memoUpdateAmount);
                final TextView memoTextName = popup.findViewById(R.id.memoTextName);
                final EditText memoEditAmount = popup.findViewById(R.id.memoEditAmount);
                final TextView memoTextUnit = popup.findViewById(R.id.memoTextUnit);
                final TextView memoUpdateWarnMessage = popup.findViewById(R.id.memoUpdateWarnMessage);

                final Button buttonUpdate = popup.findViewById(R.id.buttonUpdate);
                final Button buttonCancel = popup.findViewById(R.id.buttonCancel);

                final ShoppingMemo memo = (ShoppingMemo) listview.getItemAtPosition(position);

                memoTextName.setText(memo.getIgdname());
                memoEditAmount.setText(memo.getAmount().toString());
                memoTextUnit.setText(memo.getUnit());

                buttonUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        float amount;
                        if(memoEditAmount.getText().toString().equals("")){
                            memoUpdateWarnMessage.setText("수량을 입력하지 않았습니다.");
                            memoUpdateWarnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        try {
                            amount = Integer.parseInt(memoEditAmount.getText().toString());
                        }catch(NumberFormatException e){
                            memoUpdateWarnMessage.setText("수량이 잘못 설정되었습니다.");
                            memoUpdateWarnMessage.setVisibility(View.VISIBLE);
                            return;
                        }

                        if(amount <= 0){
                            memoUpdateWarnMessage.setText("수량이 잘못 설정되었습니다.");
                            memoUpdateWarnMessage.setVisibility(View.VISIBLE);
                            return;
                        }
                        memoUpdateWarnMessage.setVisibility(View.GONE);
                        memoController.updateMemo(memo.getMemo_Id(), amount);
                        shoppingMemoArrayList = memoController.getAllMemo();
                        adapter = new CustomChoiceListViewAdapter(shoppingMemoArrayList);
                        listview.setAdapter(adapter);
                        dialog.dismiss();
                    }
                });
                buttonCancel.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

                return true;
            }
        });

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addData();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Memo_Delete.class);
                startActivity(intent);
            }
        });
    }

    public void addData(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.memo_add, (ViewGroup)findViewById(R.id.Relative));
        builder.setTitle("장보기 메모 추가");
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.memo_et_igdname);
        et_amount = addpopup.findViewById(R.id.memo_et_amount);
        btnConfirm = addpopup.findViewById(R.id.memo_confirm);
        btnCancel = addpopup.findViewById(R.id.memo_cancel);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                TextView memoWarnMessage = addpopup.findViewById(R.id.memoWarnMessage);
                String igdname = et_igdname.getText().toString();
                Ingredient ing = ingredientController.getIngredientByName(igdname);
                if(igdname.equals("")) {
                    memoWarnMessage.setText("식재료명을 입력하지 않았습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                    return;
                }
                if(ing == null){
                    memoWarnMessage.setText("식재료명이 잘못 설정되었습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                    return;
                }
                if(et_amount.getText().toString().equals("")){
                    memoWarnMessage.setText("수량을 입력하지 않았습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                    return;
                }
                Float amount;
                try {
                    amount = Float.parseFloat(et_amount.getText().toString());
                } catch (NumberFormatException e){
                    memoWarnMessage.setText("수량이 잘못 설정되었습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                    return;
                }
                if(amount <= 0){
                    memoWarnMessage.setText("수량이 잘못 설정되었습니다.");
                    memoWarnMessage.setVisibility(View.VISIBLE);
                    return;
                }

                memoWarnMessage.setVisibility(View.INVISIBLE);
                String unit = ingredientController.getIngredientByName(igdname).getMeasure();

                boolean check = true;
                for(ShoppingMemo m : shoppingMemoArrayList){
                    if(m.getIgdname().equals(igdname)) {
                        check = false;
                        memoController.updateMemo(m.getMemo_Id(), m.getAmount() + amount);
                        break;
                    }
                }
                if(check) {
                    memoController.InsertMemo(igdname, amount, unit);
                }
                dialog.dismiss();shoppingMemoArrayList = memoController.getAllMemo();
                adapter.setItemList(shoppingMemoArrayList);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(Memo_Main.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> memoList = new ArrayList<ShoppingMemo>();

        public CustomChoiceListViewAdapter(ArrayList<ShoppingMemo> memoList) {
            this.memoList = memoList;
        }

        @Override
        public int getCount() {
            return memoList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return memoList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo> memoList){
            this.memoList = memoList;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.memo_igdname);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.memo_amount);

            ShoppingMemo memo = memoList.get(position);

            ing_name.setText(memo.getIgdname());
            ing_amount.setText(""+memo.getAmount()+""+memo.getUnit());

            return convertView;
        }
    }
}
