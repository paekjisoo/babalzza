package com.example.babalzzafinal.Boundary;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import com.example.babalzzafinal.Controller.RecommendController;
//import com.example.babalzzafinal.Entity.MealSchedule;
//import com.example.babalzzafinal.Entity.Menu;
//import com.example.babalzzafinal.Entity.MenuIngredient;
//import com.example.babalzzafinal.Entity.MenuScore;
//import com.example.babalzzafinal.Entity.ScheduleHistory;
//import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//import static com.example.babalzzafinal.Controller.RecommendController.getScoreTotal;
//import static com.example.babalzzafinal.Controller.RecommendController.setTotal;

public class Recommend_Main extends AppCompatActivity {

    Button btn_before;
    Button btn_after;
    Button btn_change;

    TextView txt_date;

    Date today;
    Date tomorrow;
    Date yesterday;
    Calendar cal;
    SimpleDateFormat format;
    String todaydate;
    String tomorrowdate;
    String yesterdaydate;

    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_main);

        ingredientController = new RecommendController(this);
        memoController = new MemoController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();
        shoppingMemoArrayList = memoController.getAllMemo();

        //bottomNavigationView 에서 클릭
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        Intent intent;
                        if(userIngredientArrayList.isEmpty()) {
                            intent = new Intent(Recommend_Main.this, NoIngredient.class);
                        }
                        else {
                            Toast.makeText(Recommend_Main.this, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(Recommend_Main.this, UserIngredient_Activity.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.schedule:
                        Toast.makeText(Recommend_Main.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.memo:
                        if(shoppingMemoArrayList.isEmpty()){
                            intent = new Intent(Recommend_Main.this, NoMemo.class);
                        }
                        else {
                            Toast.makeText(Recommend_Main.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(Recommend_Main.this, Memo_Main.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                }
                return false;
            }
        });

        format = new SimpleDateFormat("yyyy-MM-dd");
        today = new Date();
        cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, 1);
        tomorrow = cal.getTime();
        cal.setTime(today);
        cal.add(Calendar.DATE, -1);
        yesterday = cal.getTime();

        todaydate = format.format(today);
        tomorrowdate = format.format(tomorrow);
        yesterdaydate = format.format(yesterday);

        btn_before=findViewById(R.id.btn_before);
        btn_before.setEnabled(false);
        btn_after=findViewById(R.id.btn_after);
        btn_after.setEnabled(false);
        btn_change=findViewById(R.id.btn_change);

        txt_date = findViewById(R.id.txt_date);
        txt_date.setText(todaydate);

/*        btn_before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent beforeintent = new Intent(Recommend_Main.this, Recommend_Before.class);
                Recommend_Main.this.startActivity(beforeintent);
            }
        });

        btn_after.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent afterintent = new Intent(Recommend_Main.this, Recommend_After.class);
                Recommend_Main.this.startActivity(afterintent);
            }
        });

        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent changeintent = new Intent(Recommend_Main.this, Recommend_Edit.class);
                Recommend_Main.this.startActivity(changeintent);
            }
        });

        DatabaseInitializer databaseInitializer = new DatabaseInitializer(this, this, btn_before, btn_after, btn_change, yesterdaydate, tomorrowdate, todaydate);
        databaseInitializer.execute();
    }
*//*
    private static class ScheduleGenerator extends AsyncTask {

        ProgressDialog progressDialog;
        private Context context;
        private ArrayList<MenuScore> sortedCandidateMenuScoreList;
        private Integer user_id;
        private RecommendController recommendController;
        private TextView txt_breakfast;
        private TextView txt_lunch;
        private TextView txt_dinner;
        private String todaydate;

        public ScheduleGenerator(Context context, RecommendController recommendController, ArrayList<MenuScore> sortedCandidateMenuScoreList, Integer user_id, TextView txt_breakfast, TextView txt_lunch, TextView txt_dinner, String todaydate) {
            super();
            this.context = context;
            this.sortedCandidateMenuScoreList = sortedCandidateMenuScoreList;
            this.user_id = user_id;
            this.recommendController = recommendController;
            this.progressDialog = new ProgressDialog(context);
            this.progressDialog.setMessage("ProgressDialog running...");
            this.progressDialog.setCancelable(false);
            this.progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Horizontal);
            this.txt_breakfast = txt_breakfast;
            this.txt_lunch = txt_lunch;
            this.txt_dinner = txt_dinner;
            this.todaydate = todaydate;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            recommendController.makeSchedule(sortedCandidateMenuScoreList, user_id);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            ArrayList <Menu> menuList = recommendController.getAllMenu();
            ArrayList <MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
            final ArrayList<MealSchedule> todaymealList = new ArrayList<MealSchedule>();
            for(MealSchedule m : mealScheduleArrayList){
                if (m.getDate().equals(todaydate)){
                    if (m.getMeal().equals("아침")){
                        todaymealList.add(0, m);
                        txt_breakfast.setText(menuList.get(m.getMenu_id()-1).getName());
                    }
                    else if (m.getMeal().equals("점심")){
                        todaymealList.add(1, m);
                        txt_lunch.setText(menuList.get(m.getMenu_id()-1).getName());
                    }
                    else if (m.getMeal().equals("저녁")){
                        todaymealList.add(2, m);
                        txt_dinner.setText(menuList.get(m.getMenu_id()-1).getName());
                    }
                }
            }

            txt_breakfast.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent breakfastintent = new Intent(context, Recommend_Detail.class);
                    breakfastintent.putExtra("menu_id", todaymealList.get(0).getMenu_id());
                    context.startActivity(breakfastintent);
                }
            });

            txt_lunch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent lunchintent = new Intent(context, Recommend_Detail.class);
                    lunchintent.putExtra("menu_id", todaymealList.get(1).getMenu_id());
                    context.startActivity(lunchintent);
                }
            });

            txt_dinner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent dinnerintent = new Intent(context, Recommend_Detail.class);
                    dinnerintent.putExtra("menu_id", todaymealList.get(2).getMenu_id());
                    context.startActivity(dinnerintent);
                }
            });
            progressDialog.dismiss();
        }
    }

    private static class DatabaseInitializer extends AsyncTask {

        ProgressDialog progressDialog;
        Context context;
        Activity activity;

        SharedPreferences csvload;
        RecommendController recommendController;

        TextView txt_breakfast;
        TextView txt_lunch;
        TextView txt_dinner;

        ArrayList<Float> ScoreRecentAssign;
        ArrayList<Float> ScoreExpirationDate;
        ArrayList<Float> ScoreAmount;
        ArrayList<Float> TotalAdjustedScore;

        public Integer user_id;
        ArrayList<Menu> menuList;

        ArrayList<MealSchedule> mealScheduleArrayList;
        ArrayList<MenuScore> candidateMenuScoreList;

        Button btn_before;
        Button btn_after;
        Button btn_change;

        String yesterdaydate;
        String tomorrowdate;
        String todaydate;

        public DatabaseInitializer(Context context, Activity activity, Button btn_before, Button btn_after, Button btn_change, String yesterdaydate, String tomorrowdate, String todaydate) {
            super();

            this.context = context;
            this.activity = activity;
            this.btn_before = btn_before;
            this.btn_after = btn_after;
            this.btn_change = btn_change;
            this.yesterdaydate = yesterdaydate;
            this.tomorrowdate = tomorrowdate;
            this.todaydate = todaydate;

            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Initializing...");
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Horizontal);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            txt_breakfast=activity.findViewById(R.id.txt_breakfast);
            txt_lunch=activity.findViewById(R.id.txt_lunch);
            txt_dinner=activity.findViewById(R.id.txt_dinner);
            progressDialog.show();
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            user_id = RecommendController.getUserID();
            mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
            menuList = recommendController.getAllMenu();

            boolean chk = false;
            for (MealSchedule s: mealScheduleArrayList){
                if (s.getDate().equals(yesterdaydate)){
                    chk = true;
                    break;
                }
            }
            if (chk){
                btn_before.setEnabled(true);
            }

            if (mealScheduleArrayList.size() != 0){
                if (mealScheduleArrayList.get(mealScheduleArrayList.size()-1).getDate().equals(tomorrowdate)) {
                    btn_after.setEnabled(true);
                }
            }

            final ArrayList<MealSchedule> todaymealList = new ArrayList<MealSchedule>();
            for(MealSchedule m : mealScheduleArrayList){
                if (m.getDate().equals(todaydate)){
                    if (m.getMeal().equals("아침")){
                        todaymealList.add(0, m);
                        txt_breakfast.setText(menuList.get(m.getMenu_id()).getName());
                    }
                    else if (m.getMeal().equals("점심")){
                        todaymealList.add(1, m);
                        txt_lunch.setText(menuList.get(m.getMenu_id()).getName());
                    }
                    else if (m.getMeal().equals("저녁")){
                        todaymealList.add(2, m);
                        txt_dinner.setText(menuList.get(m.getMenu_id()).getName());
                    }
                }
            }

            txt_breakfast.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent breakfastintent = new Intent(context, Recommend_Detail.class);
                    breakfastintent.putExtra("menu_id", todaymealList.get(0).getMenu_id());
                    context.startActivity(breakfastintent);
                }
            });

            txt_lunch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent lunchintent = new Intent(context, Recommend_Detail.class);
                    lunchintent.putExtra("menu_id", todaymealList.get(1).getMenu_id());
                    context.startActivity(lunchintent);
                }
            });

            txt_dinner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent dinnerintent = new Intent(context, Recommend_Detail.class);
                    dinnerintent.putExtra("menu_id", todaymealList.get(2).getMenu_id());
                    context.startActivity(dinnerintent);
                }
            });

            // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
            candidateMenuScoreList = recommendController.MenuScoreByUserID(user_id);
            // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
            ScoreRecentAssign = recommendController.getScoreRecentAssign(user_id);
            // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
            ScoreExpirationDate = recommendController.getScoreExpirationDate(user_id);
            // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
            ScoreAmount = recommendController.getScoreAmount(user_id);
            // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
            TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
            candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);
            // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
            ArrayList<MenuScore> sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);
            progressDialog.dismiss();
            // 13. 스케줄 만든다
            ScheduleGenerator scheduleGenerator = new ScheduleGenerator(context, recommendController, sortedCandidateMenuScoreList, user_id, txt_breakfast, txt_lunch, txt_dinner, todaydate);
            scheduleGenerator.execute();
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            recommendController = new RecommendController(context);

            csvload = context.getSharedPreferences("is_csv_loaded1350", Activity.MODE_PRIVATE);
            String result = csvload.getString("is_csv_loaded", "");
            if (result.equals("")){
                recommendController.csvToDB_User(context);
                recommendController.csvToDB_Ingredient(context);
                recommendController.csvToDB_UserIngredient(context);
                recommendController.csvToDB_Menu(context);
                recommendController.csvToDB_MenuIngredient(context);
                recommendController.csvToDB_MenuScore(context);
                recommendController.csvToDB_ScheduleHistory(context);
                SharedPreferences.Editor editor = csvload.edit();
                editor.putString("is_csv_loaded", "done");
                editor.commit();
            }
            // user_id 기반으로 해서
            recommendController = new RecommendController(context);
            return null;
        }*/
    }
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(Recommend_Main.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}
