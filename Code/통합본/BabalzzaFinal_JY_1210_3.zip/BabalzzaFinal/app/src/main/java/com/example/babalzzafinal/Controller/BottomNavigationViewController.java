package com.example.babalzzafinal.Controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.babalzzafinal.Boundary.Memo_Main;
import com.example.babalzzafinal.Boundary.NoIngredient;
import com.example.babalzzafinal.Boundary.NoMemo;
import com.example.babalzzafinal.Boundary.NoSchedule;
import com.example.babalzzafinal.Boundary.Recommend_Main;
import com.example.babalzzafinal.Boundary.UserIngredient_Activity;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

public class BottomNavigationViewController {
    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;

    public void startNextActivity(Integer itemId, Context context, Activity activity){

        ingredientController = new RecommendController(context);
        memoController = new MemoController(context);

        userIngredientArrayList = ingredientController.getAllUserIngredientByUserID(RecommendController.getUserID());

        switch(itemId) {
            case R.id.fridge:
                Intent intent;
                if (userIngredientArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoIngredient.class)) return;
                    intent = new Intent(context, NoIngredient.class);
                } else {
                    if(activity.getClass().equals(UserIngredient_Activity.class)) return;
                    Toast.makeText(context, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, UserIngredient_Activity.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
            case R.id.schedule:
                if (userIngredientArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoSchedule.class)) return;
                    intent = new Intent(context, NoSchedule.class);
                } else {
                    if(activity.getClass().equals(Recommend_Main.class)) return;
                    Toast.makeText(context, "추천으로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, Recommend_Main.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
            case R.id.memo:
                shoppingMemoArrayList = memoController.getAllMemo();
                if (shoppingMemoArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoMemo.class)) return;
                    intent = new Intent(context, NoMemo.class);
                } else {
                    if(activity.getClass().equals(Memo_Main.class)) return;
                    Toast.makeText(context, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, Memo_Main.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
        }
    }
}
