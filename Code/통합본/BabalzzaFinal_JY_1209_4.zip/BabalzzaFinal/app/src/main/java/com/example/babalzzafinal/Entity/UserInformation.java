package com.example.babalzzafinal.Entity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class UserInformation extends SQLiteOpenHelper {
    private int id;
    private String userid;
    private String nickname;
    private String password;

    public int getId() {
        return id;
    }
    public String getUserId() {
        return userid;
    }
    public void setUserId(String userid) { this.userid = userid; }
    public String getNickname() { return nickname; }
    public void setNickname(String ninckname) { this.nickname = ninckname; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public UserInformation(Context context) { super(context, "user", null, 1); }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query = "CREATE TABLE IF NOT EXISTS user (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERID TEXT NOT NULL, NICKNAME TEXT NOT NULL, PASSWORD TEXT NOT NULL)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
        String query = "DROP TABLE IF EXISTS user";
        database.execSQL(query);
        onCreate(database);
    }

    public String insert(String userid, String nickname, String password) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "INSERT INTO user (USERID, NICKNAME, PASSWORD) VALUES ('" + userid + "', '" + nickname + "' , '" + password + "')";
            database.execSQL(query);
            return "ok";
        }
        catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public String delete(String userid) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "DELETE FROM user WHERE USERID = '" + userid + "';";
            database.execSQL(query);
            return"ok";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public ArrayList<UserInformation> getAllUsers(Context context) {
        try{
            ArrayList<UserInformation> userInfos = new ArrayList<>();
            SQLiteDatabase database = this.getReadableDatabase();
            Cursor cursor = database.rawQuery("SELECT * FROM user", null);

            if(cursor != null) {
                while (cursor.moveToNext()) {
                    UserInformation item = new UserInformation(context);
                    int id = cursor.getInt(cursor.getColumnIndex("ID"));
                    String userId = cursor.getString(cursor.getColumnIndex("USERID"));
                    String nickname = cursor.getString(cursor.getColumnIndex("NICKNAME"));
                    String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                    item.id = id;
                    item.userid = userId;
                    item.nickname = nickname;
                    item.password = password;
                    userInfos.add(item);
                }
            }

            return userInfos;
        }
        catch (Exception ex) {
            return null;
        }
    }

    /*public UserInformation getUserInfo(String input, String searchby) {
        UserInformation userInfo = new UserInformation();
        Cursor cursor = this.getAllData();

        while(cursor.moveToNext()) {
            if (searchby.equals("USERID"))
                if (cursor.getString(1).equals(input)) {
                    userInfo.setId(cursor.getString(1));
                    userInfo.setNickname(cursor.getString(2));
                    userInfo.setPassword(cursor.getString(3));
                    break;
                }
            if (searchby.equals("NICKNAME"))
                if (cursor.getString(2).equals(input)) {
                    userInfo.setId(cursor.getString(1));
                    userInfo.setNickname(cursor.getString(2));
                    userInfo.setPassword(cursor.getString(3));
                    break;
                }
        }

        return userInfo;
    }

    public Cursor getAllData() {
        try {
            SQLiteDatabase database = this.getReadableDatabase();
            String query = "SELECT * FROM user";
            Cursor cursor = database.rawQuery(query, null);
            return cursor;
        }
        catch (Exception ex) {
            return null;
        }
    }*/

    public void updatePassword(String userid, String password) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("UPDATE user SET PASSWORD = '" + password + "' WHERE USERID = '"+ userid +"';");
    }

    public void updateNickname(String userid, String nickname) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("UPDATE user SET NICKNAME = '" + nickname + "' WHERE USERID = '"+ userid +"';");
    }

}