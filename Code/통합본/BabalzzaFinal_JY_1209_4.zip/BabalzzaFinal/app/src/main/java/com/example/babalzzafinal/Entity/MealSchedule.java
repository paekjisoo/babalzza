package com.example.babalzzafinal.Entity;

public class MealSchedule {
    Integer scd_id;
    Integer menu_id;
    Integer user_id;
    String date;
    String meal;
    String done;

    public MealSchedule() {
    }

    public MealSchedule(Integer scd_id, Integer menu_id, Integer user_id, String date, String meal, String done) {
        this.scd_id = scd_id;
        this.menu_id = menu_id;
        this.user_id = user_id;
        this.date = date;
        this.meal = meal;
        this.done = done;
    }

    public Integer getScd_id() {
        return scd_id;
    }

    public void setScd_id(Integer scd_id) {
        this.scd_id = scd_id;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMeal() {
        return meal;
    }

    public void setMeal(String meal) {
        this.meal = meal;
    }

    public String getDone() {
        return done;
    }

    public void setDone(String done) {
        this.done = done;
    }
}
