package com.example.babalzzafinal.Boundary;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.MenuScore;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

import static com.example.babalzzafinal.Controller.RecommendController.getScoreTotal;
import static com.example.babalzzafinal.Controller.RecommendController.setTotal;

public class Recommend_Reset extends AppCompatActivity {

    Button btn_newschedule;
    RecommendController recommendController;
    Integer user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_reset);

        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();

        btn_newschedule = (Button) findViewById(R.id.btn_newschedule);

        btn_newschedule.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view) {

                // reservedamount 전부 0으로 셋팅하는 함수
                recommendController.MealScheduleReset(user_id);

                // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
                ArrayList<MenuScore> candidateMenuScoreList = recommendController.MenuScoreByUserID(user_id);
                // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
                ArrayList<Float> ScoreRecentAssign = recommendController.getScoreRecentAssign(user_id);
                // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
                ArrayList<Float> ScoreExpirationDate = recommendController.getScoreExpirationDate(user_id);
                // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
                ArrayList<Float> ScoreAmount = recommendController.getScoreAmount(user_id);
                // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
                ArrayList<Float> TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
                candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);
                // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
                ArrayList<MenuScore> sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);

                ArrayList<Integer> avoidList = recommendController.makeTodaySchedule(sortedCandidateMenuScoreList, user_id);
                recommendController.makeSchedule(sortedCandidateMenuScoreList, user_id, avoidList);

                Intent gotomealmain = new Intent(Recommend_Reset.this, Recommend_Main.class);
                Recommend_Reset.this.startActivity(gotomealmain);

            }
        });
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(Recommend_Reset.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}
