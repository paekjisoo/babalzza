package com.example.babalzzafinal.Boundary;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompatSideChannelService;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.babalzzafinal.Controller.BottomNavigationViewController;
import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.MealSchedule;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class NoSchedule extends AppCompatActivity {

    Button btn;
    RecommendController recommendController;
    Integer user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_empty);

        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                BottomNavigationViewController control = new BottomNavigationViewController();
                control.startNextActivity(menuItem.getItemId(), NoSchedule.this, NoSchedule.this);
                return false;
            }
        });

        boolean iserror = false;
        if (recommendController.getAllUserIngredientByUserID(user_id).size() != 0) {
            ArrayList<MealSchedule> oldMealScheduleList = recommendController.getOldMealScheduleList(user_id);
//
//            Date date = new Date();
//            SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            String today = transFormat.format(date);
//            System.out.println("오늘날짜는: "+today);

            System.out.println(oldMealScheduleList.size() + "개 입니다!!!!!!!!!!!!!!!1");

            for (int i = 0; i < oldMealScheduleList.size(); i++) {
                if (oldMealScheduleList.get(i).getDone().equals("FALSE")) {
                    iserror = true;
                }
            }

            if (iserror == true) {
                Intent gotoerror = new Intent(NoSchedule.this, Recommend_Reset.class);
                NoSchedule.this.startActivity(gotoerror);
                finish();
            } else {
                Intent gotomain = new Intent(NoSchedule.this, Recommend_Main.class);
                NoSchedule.this.startActivity(gotomain);
                finish();
            }
        } else {
            btn = (Button) findViewById(R.id.btn_toaddigd);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent gotoaddigd = new Intent(NoSchedule.this, AddUserIngredient_Activity.class);
                    NoSchedule.this.startActivity(gotoaddigd);
                    finish();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(NoSchedule.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}