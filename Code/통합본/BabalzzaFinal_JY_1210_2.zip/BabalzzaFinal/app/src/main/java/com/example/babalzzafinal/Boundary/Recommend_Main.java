package com.example.babalzzafinal.Boundary;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.MealSchedule;
import com.example.babalzzafinal.Entity.Menu;
import com.example.babalzzafinal.Entity.MenuIngredient;
import com.example.babalzzafinal.Entity.MenuScore;
import com.example.babalzzafinal.Entity.ScheduleHistory;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.Controller.BottomNavigationViewController;
import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.example.babalzzafinal.Controller.RecommendController.getScoreTotal;
import static com.example.babalzzafinal.Controller.RecommendController.setTotal;

public class Recommend_Main extends AppCompatActivity {

    Button btn_before;
    Button btn_after;
    Button btn_change;

    TextView txt_date;
    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    public Integer user_id;

    Date today;
    Date tomorrow;
    Date yesterday;
    Calendar cal;
    SimpleDateFormat format;
    String todaydate;
    String tomorrowdate;
    String yesterdaydate;

    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;

    RecommendController recommendController;
    ArrayList<Menu> menuList;
    ArrayList<MealSchedule> mealScheduleArrayList;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_main);

        ingredientController = new RecommendController(this);
        memoController = new MemoController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredientByUserID(RecommendController.getUserID());
        shoppingMemoArrayList = memoController.getAllMemo();

        //bottomNavigationView 에서 클릭
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                BottomNavigationViewController control = new BottomNavigationViewController();
                control.startNextActivity(menuItem.getItemId(), Recommend_Main.this, Recommend_Main.this);
                return false;
            }
        });

        format = new SimpleDateFormat("yyyy-MM-dd");
        today = new Date();
        cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, 1);
        tomorrow = cal.getTime();
        cal.setTime(today);
        cal.add(Calendar.DATE, -1);
        yesterday = cal.getTime();

        todaydate = format.format(today);
        tomorrowdate = format.format(tomorrow);
        yesterdaydate = format.format(yesterday);

        btn_before=findViewById(R.id.btn_before);
        btn_before.setEnabled(false);
        btn_after=findViewById(R.id.btn_after);
        btn_after.setEnabled(false);
        btn_change=findViewById(R.id.btn_change);

        txt_date = findViewById(R.id.txt_date);
        txt_date.setText(todaydate);
        txt_breakfast = findViewById(R.id.txt_breakfast);
        txt_lunch = findViewById(R.id.txt_lunch);
        txt_dinner = findViewById(R.id.txt_dinner);

        recommendController = new RecommendController(Recommend_Main.this);
        user_id = recommendController.getUserID();
        mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        menuList = recommendController.getAllMenu();

        boolean chk = false;
        for (MealSchedule s : mealScheduleArrayList) {
            if (s.getDate().equals(yesterdaydate)) {
                chk = true;
                break;
            }
        }
        if (chk) {
            btn_before.setEnabled(true);
        }

        if (mealScheduleArrayList.size() != 0) {
            if (mealScheduleArrayList.get(mealScheduleArrayList.size() - 1).getDate().equals(tomorrowdate)) {
                btn_after.setEnabled(true);
            }
        }

        final ArrayList<MealSchedule> todaymealList = new ArrayList<MealSchedule>();
        for (MealSchedule m : mealScheduleArrayList) {
            System.out.println(mealScheduleArrayList.size());
            if (m.getDate().equals(todaydate)) {
                if (m.getMeal().equals("아침")) {
                    todaymealList.add(0, m);
                    txt_breakfast.setText(menuList.get(m.getMenu_id()-1).getName());
                } else if (m.getMeal().equals("점심")) {
                    todaymealList.add(1, m);
                    txt_lunch.setText(menuList.get(m.getMenu_id()).getName());
                } else if (m.getMeal().equals("저녁")) {
                    todaymealList.add(2, m);
                    txt_dinner.setText(menuList.get(m.getMenu_id()).getName());
                }
            }
        }

        txt_breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent breakfastintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                breakfastintent.putExtra("menu_id", todaymealList.get(0).getMenu_id());
                Recommend_Main.this.startActivity(breakfastintent);
            }
        });

        txt_lunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lunchintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                lunchintent.putExtra("menu_id", todaymealList.get(1).getMenu_id());
                Recommend_Main.this.startActivity(lunchintent);
            }
        });

        txt_dinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dinnerintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                dinnerintent.putExtra("menu_id", todaymealList.get(2).getMenu_id());
                Recommend_Main.this.startActivity(dinnerintent);
            }
        });

        btn_before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent beforeintent = new Intent(Recommend_Main.this, Recommend_Before.class);
                Recommend_Main.this.startActivity(beforeintent);
            }
        });

        btn_after.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent afterintent = new Intent(Recommend_Main.this, Recommend_After.class);
                Recommend_Main.this.startActivity(afterintent);
            }
        });

        /*btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent changeintent = new Intent(Recommend_Main.this, Recommend_Edit.class);
                Recommend_Main.this.startActivity(changeintent);
            }
        });*/
    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(Recommend_Main.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}
