package com.example.babalzzafinal.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.MenuScore;
import com.example.babalzzafinal.Entity.User;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

import static com.example.babalzzafinal.Controller.RecommendController.getScoreTotal;
import static com.example.babalzzafinal.Controller.RecommendController.setTotal;

public class LogIn extends AppCompatActivity {
    private RecommendController controller;
    private User user;
    private Integer user_id;

    static ArrayList<UserIngredient> userIngredientArrayList;
    RecommendController recommendController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Intent intent = getIntent();

        controller = new RecommendController(getApplicationContext());
        user = new User();
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수
    public void activity_LogIn(View view) {
        recommendController = new RecommendController(this);

        EditText et_ID = findViewById(R.id.et_ID);
        EditText et_Password = findViewById(R.id.et_Password);
        String userId = et_ID.getText().toString();
        String password = et_Password.getText().toString();

        //try {
            String result = login(userId, password);

            if (result.equals("ok")) {
                Intent login_successful;

                user_id = RecommendController.getUserID();

                userIngredientArrayList = recommendController.getAllUserIngredientByUserID(user_id);
                if(userIngredientArrayList.isEmpty())
                    login_successful = new Intent(this, NoSchedule.class);
                else {
                    login_successful = new Intent(this, Recommend_Main.class);
                    // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
                    ArrayList<MenuScore> candidateMenuScoreList = recommendController.MenuScoreByUserID(user_id);
                    // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreRecentAssign = recommendController.getScoreRecentAssign(user_id);
                    // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreExpirationDate = recommendController.getScoreExpirationDate(user_id);
                    // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreAmount = recommendController.getScoreAmount(user_id);
                    // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
                    ArrayList<Float> TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
                    candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);
                    // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
                    ArrayList<MenuScore> sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);

                    ArrayList<Integer> avoidList = recommendController.makeTodaySchedule(sortedCandidateMenuScoreList, user_id);
                    recommendController.makeSchedule(sortedCandidateMenuScoreList, user_id, avoidList);
                }
                login_successful.putExtra("userid", userId);
                startActivity(login_successful);
                finish();
            }
            else
                Toast.makeText(LogIn.this, result, Toast.LENGTH_LONG).show();
        //}
        //catch (Exception ex) {
        //    String message = ex.getMessage().toString();
        //    Toast.makeText(LogIn.this, message, Toast.LENGTH_LONG).show();
        //    return;
        //}
    }

    public String login (String userId, String password) {
        try {
            user = controller.UserByUserEmail(userId);
            if (user == null)
                return "로그인 실패";

            if (password.equals(user.getPassword())) {
                RecommendController.setUserID(user.getUser_id());
                return "ok";
            }
            else
                return "사용자 정보를 확인해주십시오.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, com.example.babalzzafinal.Boundary.MainActivity.class);
        startActivity(intent);
        finish();
    }
}