package com.example.babalzzafinal.Boundary;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.Ingredient;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

public class AddUserIngredient_Activity extends AppCompatActivity {

    private RecommendController ingredientController;
    private ArrayList<UserIngredient> userIngredientList;
    private ArrayList<Ingredient> ingredientList;
    private IngredientAdaper adapter;

    GridView igd_gv;
    TextView nText;
    EditText qText, dText;

    SearchView igd_sv;
    Ingredient itemAtPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_add);

        ingredientController = new RecommendController(this);
        igd_gv = (GridView)findViewById(R.id.igd_gv);
        igd_sv = (SearchView) findViewById(R.id.igd_sv);

        ingredientList = ingredientController.getAllingredients();
        userIngredientList = ingredientController.getAllUserIngredientByUserID(RecommendController.getUserID());

        adapter = new IngredientAdaper(ingredientList);
        igd_gv.setAdapter(adapter);

        igd_sv.setOnQueryTextListener(new SearchView.OnQueryTextListener(){
            @Override
            public boolean onQueryTextSubmit(String query){
                return false;
            }
            public boolean onQueryTextChange(String newText){
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        igd_gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                itemAtPosition = (Ingredient)igd_gv.getItemAtPosition(position);
                UserIngredient selectedIgd = new UserIngredient();
                selectedIgd.setUserigd_id(userIngredientList.size()+1);
                selectedIgd.setUser_id(RecommendController.getUserID());
                selectedIgd.setIgd_id(itemAtPosition.getIgd_id()-1);
                selectedIgd.setAmount((float)0);
                selectedIgd.setReservedamount(0);
                selectedIgd.setBuydate("");
                selectedIgd.setExpirationdate("");

                Intent intent = new Intent(AddUserIngredient_Activity.this, AddUserIngredientPopup_Activity.class);
                intent.putExtra("ingredient", itemAtPosition);
                intent.putExtra("userIngredient", selectedIgd);
                startActivity(intent);
            }
        });
    }

    /*void add(final UserIngredient selecteduserIgd, String name){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View view = inflater_dg.inflate(R.layout.userigd_addpopup, null);
        builder.setView(view);

        nText = (TextView)view.findViewById(R.id.showName);
        nText.setText(name);
        qText = (EditText)view.findViewById(R.id.editQuantity);
        dText = (EditText)view.findViewById(R.id.editDuedate);

        builder.setPositiveButton("추가", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                int amount = Integer.parseInt(qText.getText().toString());
                String buydate = dText.getText().toString();
                UserIngredient useringredient = selecteduserIgd;
                useringredient.setAmount(amount);
                useringredient.setBuydate(buydate);

                ingredientController.insertUserIngredient(selecteduserIgd);

            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }*/

    public class IngredientAdaper extends BaseAdapter implements Filterable  {
        private ArrayList<Ingredient> ingredientList;
        private ArrayList<Ingredient> filterList;
        CustomFilter filter;
        ArrayList<Ingredient> tempList;

        public IngredientAdaper(ArrayList<Ingredient> ingredientList) {
            this.ingredientList = ingredientList;
            this.filterList = ingredientList;
        }

        @Override
        public int getCount() {
            return ingredientList.size();
        }

        @Override
        public Object getItem(int i) {
            return ingredientList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int position = i;
            final Context context = viewGroup.getContext();

            if (view == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.userigd_item, viewGroup, false);
            }

            ImageView userigdImage = (ImageView) view.findViewById(R.id.userigdImage);
            TextView userigdname = (TextView) view.findViewById(R.id.userigdName);

            switch (Integer.parseInt(ingredientList.get(i).getCode())) {
                case 11:
                    userigdImage.setImageResource(R.drawable.igd11);
                    break;
                case 12:
                    userigdImage.setImageResource(R.drawable.igd12);
                    break;
                case 13:
                    userigdImage.setImageResource(R.drawable.igd13);
                    break;
                case 14:
                    userigdImage.setImageResource(R.drawable.igd14);
                    break;
                case 15:
                    userigdImage.setImageResource(R.drawable.igd15);
                    break;
                case 21:
                    userigdImage.setImageResource(R.drawable.igd21);
                    break;
                case 22:
                    userigdImage.setImageResource(R.drawable.igd22);
                    break;
                case 23:
                    userigdImage.setImageResource(R.drawable.igd23);
                    break;
                case 24:
                    userigdImage.setImageResource(R.drawable.igd24);
                    break;
                case 25:
                    userigdImage.setImageResource(R.drawable.igd25);
                    break;
                case 26:
                    userigdImage.setImageResource(R.drawable.igd26);
                    break;
                case 31:
                    userigdImage.setImageResource(R.drawable.igd31);
                    break;
                case 32:
                    userigdImage.setImageResource(R.drawable.igd32);
                    break;
                case 33:
                    userigdImage.setImageResource(R.drawable.igd33);
                    break;
                case 34:
                    userigdImage.setImageResource(R.drawable.igd34);
                    break;
                case 35:
                    userigdImage.setImageResource(R.drawable.igd35);
                    break;
                case 41:
                    userigdImage.setImageResource(R.drawable.igd41);
                    break;
                case 42:
                    userigdImage.setImageResource(R.drawable.igd42);
                    break;
                case 43:
                    userigdImage.setImageResource(R.drawable.igd43);
                    break;
                case 51:
                    userigdImage.setImageResource(R.drawable.igd51);
                    break;
                case 52:
                    userigdImage.setImageResource(R.drawable.igd52);
                    break;
                case 53:
                    userigdImage.setImageResource(R.drawable.igd53);
                    break;
                case 61:
                    userigdImage.setImageResource(R.drawable.igd61);
                    break;
                case 62:
                    userigdImage.setImageResource(R.drawable.igd65);
                    break;
                case 63:
                    userigdImage.setImageResource(R.drawable.igd65);
                    break;
                case 64:
                    userigdImage.setImageResource(R.drawable.igd65);
                    break;
                case 65:
                    userigdImage.setImageResource(R.drawable.igd65);
                    break;
            }userigdname.setText(ingredientList.get(i).getName());

            return view;
        }
        @Override
        public Filter getFilter() {
            if(filter == null){
                filter = new CustomFilter();
            }
            return filter;
        }

        class CustomFilter extends Filter{
            @Override
            protected FilterResults performFiltering(CharSequence constraint){
                FilterResults results= new FilterResults();

                if(constraint != null && constraint.length() > 0){
                    constraint = constraint.toString().toUpperCase();

                    ArrayList<Ingredient> filters = new ArrayList<Ingredient>();

                    for(int i=0; i<filterList.size();i++){
                        if(filterList.get(i).getName().toUpperCase().contains(constraint)){
                            Ingredient ing = new Ingredient(filterList.get(i).getIgd_id(), filterList.get(i).getName(), filterList.get(i).getImage(), filterList.get(i).getCode(), filterList.get(i).getMeasure(), filterList.get(i).getRefrigeratedterm(), filterList.get(i).getFreezedterm());
                            filters.add(ing);
                        }
                    }

                    tempList = filters;
                    results.count=filters.size();
                    results.values=filters;
                }
                else {
                    results.count = filterList.size();
                    results.values = filterList;
                }

                return results;
            }

            protected void publishResults(CharSequence constraint, FilterResults results){
                ingredientList = (ArrayList<Ingredient>) results.values;
                notifyDataSetChanged();
            }
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, AddUserIngredient_Activity.class);
        startActivity(intent);
        finish();
    }

}
