package com.example.babalzzafinal.Boundary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Memo_Delete extends AppCompatActivity {

    Button btn_memodelete;
    Button btn_memocancel;

    ListView listview;

    CustomChoiceListViewAdapter adapter;

    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_delete);

        ingredientController = new RecommendController(this);
        memoController = new MemoController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();
        shoppingMemoArrayList = memoController.getAllMemo();

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        userIngredientArrayList = ingredientController.getAllUserIngredients();
                        Intent intent;
                        if(userIngredientArrayList.isEmpty()) {
                            intent = new Intent(Memo_Delete.this, NoIngredient.class);
                        }
                        else {
                            Toast.makeText(Memo_Delete.this, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(Memo_Delete.this, UserIngredient_Activity.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.schedule:
                        Toast.makeText(Memo_Delete.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        intent = new Intent(Memo_Delete.this, Recommend_Main.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.memo:
                        shoppingMemoArrayList = memoController.getAllMemo();
                        if(shoppingMemoArrayList.isEmpty()){
                            intent = new Intent(Memo_Delete.this, NoMemo.class);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Toast.makeText(Memo_Delete.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                        }
                        return true;
                }
                return false;
            }
        });

        btn_memodelete = (Button) findViewById(R.id.memo_deldelete);
        btn_memocancel = (Button) findViewById(R.id.memo_delcancel);

        adapter = new CustomChoiceListViewAdapter(shoppingMemoArrayList, 1);

        listview = (ListView) findViewById(R.id.memo_listview_main);
        listview.setAdapter(adapter);

        btn_memodelete.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;
                int n=0;
                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
                        n=1;
                    }
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(Memo_Delete.this);

                if(n==0){
                    builder.setMessage("선택된 장보기 메모가 없습니다.");
                    builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.create().show();
                }
                else{
                    builder.setMessage("선택한 메모들을 삭제하시겠습니까?");
                    builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                            int count = adapter.getCount() ;

                            for (int i = count-1; i >= 0; i--) {
                                if (checkedItems.get(i)) {
                                    memoController.deleteMemo(adapter.getItem(i).getMemo_Id());
                                }
                            }
                            Intent intent = new Intent(getApplicationContext(), Memo_Main.class);
                            startActivity(intent);
                        }
                    });
                    builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.create().show();
                }
            }
        });

        btn_memocancel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                finish();
            }
        });
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> memoList = new ArrayList<ShoppingMemo>();

        private Integer N;

        public CustomChoiceListViewAdapter(ArrayList<ShoppingMemo> memoList, Integer n) {
            this.memoList = memoList;
            this.N=n;
        }

        @Override
        public int getCount() {
            return memoList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return memoList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo> memoList){
            this.memoList = memoList;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.memo_igdname);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.memo_amount);

            CheckBox cb = (CheckBox) convertView.findViewById(R.id.memo_checkBox);

            if(this.N==1)
                cb.setVisibility(View.VISIBLE);
            else
                cb.setVisibility(View.INVISIBLE);

            ShoppingMemo memo = memoList.get(position);

            ing_name.setText(memo.getIgdname());
            ing_amount.setText(""+memo.getAmount()+""+memo.getUnit());

            return convertView;
        }
    }
}