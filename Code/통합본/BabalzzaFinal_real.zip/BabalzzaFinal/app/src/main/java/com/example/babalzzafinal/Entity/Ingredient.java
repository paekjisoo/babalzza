package com.example.babalzzafinal.Entity;

import java.io.Serializable;

public class Ingredient implements Serializable {
    private Integer igd_id;
    private String name;
    private String image;
    private String code;
    private String measure;
    private String refrigeratedterm;
    private String freezedterm;

    public Ingredient(){}

    public Ingredient(String name, String measure){
        this.name = name;
        this.measure = measure;
    }

    public Ingredient(Integer igd_id, String name, String image, String code, String measure, String refrigeratedterm, String freezedterm) {
        this.igd_id = igd_id;
        this.name = name;
        this.image = image;
        this.code = code;
        this.measure = measure;
        this.refrigeratedterm = refrigeratedterm;
        this.freezedterm = freezedterm;
    }

    public Integer getIgd_id() {
        return igd_id;
    }

    public void setIgd_id(Integer igd_id) {
        this.igd_id = igd_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMeasure() {
        return measure;
    }

    public void setMeasure(String measure) {
        this.measure = measure;
    }

    public String getRefrigeratedterm() {
        return refrigeratedterm;
    }

    public void setRefrigeratedterm(String refrigeratedterm) {
        this.refrigeratedterm = refrigeratedterm;
    }

    public String getFreezedterm() {
        return freezedterm;
    }

    public void setFreezedterm(String freezedterm) {
        this.freezedterm = freezedterm;
    }
}

