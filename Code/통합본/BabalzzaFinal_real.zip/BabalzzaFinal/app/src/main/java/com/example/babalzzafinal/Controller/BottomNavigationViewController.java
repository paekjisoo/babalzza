package com.example.babalzzafinal.Controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.babalzzafinal.Boundary.Memo_Main;
import com.example.babalzzafinal.Boundary.NoIngredient;
import com.example.babalzzafinal.Boundary.NoMemo;
import com.example.babalzzafinal.Boundary.NoSchedule;
import com.example.babalzzafinal.Boundary.Recommend_Main;
import com.example.babalzzafinal.Boundary.UserIngredient_Activity;
import com.example.babalzzafinal.Entity.MenuScore;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

import static com.example.babalzzafinal.Controller.RecommendController.getScoreTotal;
import static com.example.babalzzafinal.Controller.RecommendController.setTotal;

public class BottomNavigationViewController {
    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    RecommendController ingredientController;
    MemoController memoController;

    public void startNextActivity(Integer itemId, Context context, Activity activity){

        ingredientController = new RecommendController(context);
        memoController = new MemoController(context);

        userIngredientArrayList = ingredientController.getAllUserIngredientByUserID(RecommendController.getUserID());

        switch(itemId) {
            case R.id.fridge:
                Intent intent;
                if (userIngredientArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoIngredient.class)) return;
                    intent = new Intent(context, NoIngredient.class);
                } else {
                    if(activity.getClass().equals(UserIngredient_Activity.class)) return;
                    Toast.makeText(context, "식재료 관리로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, UserIngredient_Activity.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
            case R.id.schedule:
                if (userIngredientArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoSchedule.class)) return;
                    intent = new Intent(context, NoSchedule.class);
                } else {
                    if(ingredientController.MealScheduleByUserID(RecommendController.getUserID()).isEmpty()){
                        // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
                        ArrayList<MenuScore> candidateMenuScoreList = ingredientController.MenuScoreByUserID(RecommendController.getUserID());
                        // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
                        ArrayList<Float> ScoreRecentAssign = ingredientController.getScoreRecentAssign(RecommendController.getUserID());
                        // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
                        ArrayList<Float> ScoreExpirationDate = ingredientController.getScoreExpirationDate(RecommendController.getUserID());
                        // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
                        ArrayList<Float> ScoreAmount = ingredientController.getScoreAmount(RecommendController.getUserID());
                        // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
                        ArrayList<Float> TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
                        candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);
                        // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
                        ArrayList<MenuScore> sortedCandidateMenuScoreList = ingredientController.sortCandidate(candidateMenuScoreList);

                        ArrayList<Integer> avoidList = ingredientController.makeTodaySchedule(sortedCandidateMenuScoreList, RecommendController.getUserID());
                        ingredientController.makeSchedule(sortedCandidateMenuScoreList, RecommendController.getUserID(), avoidList);
                    }
                    if(activity.getClass().equals(Recommend_Main.class)) return;
                    Toast.makeText(context, "추천으로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, Recommend_Main.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
            case R.id.memo:
                shoppingMemoArrayList = memoController.getAllMemo();
                if (shoppingMemoArrayList.isEmpty()) {
                    if(activity.getClass().equals(NoMemo.class)) return;
                    intent = new Intent(context, NoMemo.class);
                } else {
                    if(activity.getClass().equals(Memo_Main.class)) return;
                    Toast.makeText(context, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                    intent = new Intent(context, Memo_Main.class);
                }
                context.startActivity(intent);
                activity.finish();
                return;
        }
    }
}
