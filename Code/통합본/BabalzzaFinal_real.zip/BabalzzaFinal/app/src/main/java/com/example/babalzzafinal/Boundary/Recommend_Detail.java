package com.example.babalzzafinal.Boundary;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.Menu;
import com.example.babalzzafinal.Entity.MenuIngredient;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

public class Recommend_Detail extends AppCompatActivity {
    Button btn_recipe;
    ImageView img_menu;
    TextView txt_menuname;
    TextView txt_info;
    TextView txt_ingredients;
    TextView txt_lackigdlist;

    ArrayList<MenuIngredient> menuIngredientList;
    Menu detailedMenu;
    RecommendController controller;
    Integer menu_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_detail);

        Intent intent = getIntent(); /*데이터 수신*/
        menu_id = intent.getExtras().getInt("menu_id");

        controller = new RecommendController(this);

        detailedMenu = controller.getAllMenu().get(menu_id-1);
        menuIngredientList = controller.getAllMenuIngredientByMenuId(menu_id);

        final Uri recipeUri = Uri.parse(detailedMenu.getRecipelink());
        img_menu = (ImageView) findViewById(R.id.img_menu);

        txt_menuname = (TextView) findViewById(R.id.txt_menuname);
        txt_menuname.setText(detailedMenu.getName());

        txt_info = (TextView) findViewById(R.id.txt_info);
        String menuinfo = detailedMenu.getCountry()+" / "+detailedMenu.getTime()+ " / "+detailedMenu.getLevel();
        txt_info.setText(menuinfo);

        txt_ingredients = (TextView) findViewById(R.id.txt_ingredients);
        String menuigdtostring = "";
        for (MenuIngredient m : menuIngredientList){
            menuigdtostring += controller.getIngredientNameByIgdId(m.getIgd_menu())+" "+m.getIgdamount()+controller.getIngredientMeasureByIgdId(m.getIgd_menu())+",";
        }
        menuigdtostring = menuigdtostring.substring(0, menuigdtostring.length()-1);
        txt_ingredients.setText(menuigdtostring);

        txt_lackigdlist = (TextView) findViewById(R.id.txt_lackigdlist);
        String lackmenuigdtostring = "충분하지 않은 식재료: ";
        ArrayList <UserIngredient> userIngredients = controller.getAllUserIngredientByUserID(RecommendController.getUserID());
        ArrayList <MenuIngredient> lackIngredients = new ArrayList<>();

//        Log.d("JISUUUUUUUUUUU 000", menuIngredientList.size()+"입니다."
//      Log.d("JISUUUUUUUUUUU 000", userIngredients.size()+"입니다.");

        menuIngredientList = controller.getAllMenuIngredientByMenuId(menu_id);
        userIngredients = controller.getAllUserIngredientByUserID(RecommendController.getUserID());

        for (int i=0; i<menuIngredientList.size(); i++){
            boolean chk = false;
            for (int j=0; j<userIngredients.size(); j++){
                if (menuIngredientList.get(i).getIgd_menu().equals(userIngredients.get(j).getIgd_id())) {
                    System.out.println("식재료량 비교결과는? "+menuIngredientList.get(i).getIgdamount().compareTo(userIngredients.get(j).getAmount())+"입니다.");
                    if (menuIngredientList.get(i).getIgdamount().compareTo(userIngredients.get(j).getAmount())==-1) {
                        chk = true; // 있는 애들중에 충분한것
                    }
                }
            } // 없으면 계속 false
            System.out.println(controller.getIngredientNameByIgdId(menuIngredientList.get(i).getIgd_menu())+"의 결과는 "+chk);
            if (!chk){
                System.out.println("문자열에 추가하기");
                lackIngredients.add(menuIngredientList.get(i));
                lackmenuigdtostring += controller.getIngredientNameByIgdId(menuIngredientList.get(i).getIgd_menu()) + ",";
            }
        }
//
        if (lackIngredients.size()==0){
            lackmenuigdtostring += "(없음))";
        }

        txt_lackigdlist.setText(lackmenuigdtostring.substring(0, lackmenuigdtostring.length()-1));
        txt_lackigdlist.setTextColor(Color.RED);

        btn_recipe=findViewById(R.id.btn_recipe);
        btn_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, recipeUri);
                startActivity(intent);
            }
        });

    }

    public void onBackPressed() {
        Intent intent = new Intent(this, Recommend_Main.class);
        startActivity(intent);
        finish();
    }

}
