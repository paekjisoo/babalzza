package com.example.babalzzafinal.Boundary;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Controller.RecommendEditController;
import com.example.babalzzafinal.Entity.MealSchedule;
import com.example.babalzzafinal.Entity.Menu;
import com.example.babalzzafinal.Entity.MenuScore;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class Recommend_Change extends AppCompatActivity {

    RecommendEditController recommendEditController;
    RecommendController recommendController;
    Integer user_id;
    ArrayList<MenuScore> sortedCandidateMenuScoreList;
    ArrayList<Menu> othercandidateMenuList;

    ConstraintLayout layout_meal1;
    ConstraintLayout layout_meal2;
    ConstraintLayout layout_meal3;
    ConstraintLayout layout_meal4;
    ConstraintLayout layout_meal5;
    ConstraintLayout layout_meal6;

    TextView txt_menu1;
    TextView txt_menu2;
    TextView txt_menu3;
    TextView txt_menu4;
    TextView txt_menu5;
    TextView txt_menu6;

    Button btn_recipe;
    Button btn_choide;
    TextView txt_menu;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_change);

        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);

        Intent intent = getIntent(); /*데이터 수신*/
        Integer scd_id = intent.getIntExtra("editingscdid",1 );
        final MealSchedule editingmealscd = recommendController.getMealScheduleByScdId(scd_id);
//        System.out.println("scd_id는?? "+scd_id);
//        System.out.println("editingmealscd는?? "+editingmealscd.getScd_id());

        recommendEditController = new RecommendEditController(this);
        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();
//        othercandidateMenuList = new ArrayList<>();

        // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
        ArrayList<MenuScore> candidateMenuScoreList = recommendController.MenuScoreByUserID(user_id);
//        System.out.println("size는 ???????"+candidateMenuScoreList.size());
        // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
        ArrayList<Float> ScoreRecentAssign = recommendController.getScoreRecentAssign(user_id);
        // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
        ArrayList<Float> ScoreExpirationDate = recommendController.getScoreExpirationDate(user_id);
        // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
        ArrayList<Float> ScoreAmount = recommendController.getScoreAmount(user_id);
        // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
        ArrayList<Float> TotalAdjustedScore = recommendController.getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
        candidateMenuScoreList = recommendController.setTotal(candidateMenuScoreList, TotalAdjustedScore);
        // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
        sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);
//
//        ArrayList<Integer> avoidList = recommendController.makeTodaySchedule(sortedCandidateMenuScoreList, user_id);
//        recommendController.makeSchedule(sortedCandidateMenuScoreList, user_id, avoidList);
        othercandidateMenuList = recommendEditController.getOtherCandidates(editingmealscd, sortedCandidateMenuScoreList);


        layout_meal1=findViewById(R.id.layout_meal1);
        layout_meal2=findViewById(R.id.layout_meal2);
        layout_meal3=findViewById(R.id.layout_meal3);
        layout_meal4=findViewById(R.id.layout_meal4);
        layout_meal5=findViewById(R.id.layout_meal5);
        layout_meal6=findViewById(R.id.layout_meal6);


        txt_menu1 = findViewById(R.id.txt_menu1);
        txt_menu1.setText(othercandidateMenuList.get(0).getName());
        txt_menu2 = findViewById(R.id.txt_menu2);
        txt_menu2.setText(othercandidateMenuList.get(1).getName());
        txt_menu3 = findViewById(R.id.txt_menu3);
        txt_menu3.setText(othercandidateMenuList.get(2).getName());
        txt_menu4 = findViewById(R.id.txt_menu4);
        txt_menu4.setText(othercandidateMenuList.get(3).getName());
        txt_menu5 = findViewById(R.id.txt_menu5);
        txt_menu5.setText(othercandidateMenuList.get(4).getName());
        txt_menu6 = findViewById(R.id.txt_menu6);
        txt_menu6.setText(othercandidateMenuList.get(5).getName());

        layout_meal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                System.out.println(txt_menu1.getText()+"입니다!!!!!!!!!!!!!11");
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu1.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(0).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu1.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(0));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(0));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();
            }
        });

        layout_meal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu2.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(1).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu2.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(1));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(1));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();

            }
        });

        layout_meal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu3.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(2).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu3.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(2));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(2));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();

            }
        });

        layout_meal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu4.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(3).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu4.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(3));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(3));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();

            }
        });

        layout_meal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu5.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(4).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu5.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(4));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(4));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();

            }
        });
        layout_meal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popupdetail, null);
                builder.setView(popup);
                txt_menu = popup.findViewById(R.id.txt_menu);
                txt_menu.setText(txt_menu6.getText());
                btn_recipe = popup.findViewById(R.id.btn_recipe);
                btn_choide = popup.findViewById(R.id.btn_choice);
                btn_recipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(othercandidateMenuList.get(5).getRecipelink()));
                        startActivity(intent);
                    }
                });
                btn_choide.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                        String msg = txt_menu6.getText()+"(으/로) 식단을 대체하시겠습니까?";
                        builder.setMessage(msg);
                        builder.setPositiveButton("예",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        recommendEditController.plusMenuScore(user_id, othercandidateMenuList.get(5));
                                        recommendEditController.selectMenu(editingmealscd, othercandidateMenuList.get(5));
                                        dialog.dismiss();
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Change.this);
                                        builder.setMessage("반영되었습니다.");
                                        builder.setPositiveButton("확인",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        dialog.dismiss();
                                                        Intent intent = new Intent(Recommend_Change.this, Recommend_Main.class);
                                                        Recommend_Change.this.startActivity(intent);
                                                    }
                                                });
                                        builder.show();
                                    }
                                });
                        builder.setNegativeButton("아니오",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int i) {
                                        dialog.dismiss();
                                    }
                                });
                        builder.show();
                    }
                });
                builder.create().show();

            }
        });
    }
}
