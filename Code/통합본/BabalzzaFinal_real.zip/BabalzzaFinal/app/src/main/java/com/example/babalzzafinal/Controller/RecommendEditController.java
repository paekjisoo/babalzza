package com.example.babalzzafinal.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.babalzzafinal.Entity.MealSchedule;
import com.example.babalzzafinal.Entity.Menu;
import com.example.babalzzafinal.Entity.MenuScore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class RecommendEditController extends SQLiteOpenHelper {

    private static final String dbName = "dbsetting1646.db";
    private static final String T_USER = "User";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    private static SQLiteDatabase db;

    RecommendController recommendController;
    private Integer user_id = RecommendController.getUserID();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    public RecommendEditController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
        recommendController = new RecommendController(context);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_USER);
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // Meal Schedule 중에서 알고자 하는 Target Date에 배정된 Meal Schedule만 Arraylist로 받아옴
    public ArrayList<MealSchedule> getMealScheduleByDate(Date date, Integer user_id) {
        String dateString = format.format(date);

        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> oneDayMealSchedule = new ArrayList<>(3);    // 하루 세끼만 저장

        for (int i=0; i<mealScheduleArrayList.size(); i++) {
            if (mealScheduleArrayList.get(i).getDate().equals(dateString)) {
                // meal schedule에 배정된 date와 찾고자 하는 target date와 같다면
                oneDayMealSchedule.add(mealScheduleArrayList.get(i));
            }
        }
        return oneDayMealSchedule;
    }

    public ArrayList<MealSchedule> getOptionList(Date date, Integer user_id) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1);
        String today = format.format(date);
        String tomorrow = format.format(cal.getTime());
        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> optionList = new ArrayList<>();

        for (int i=0; i<mealScheduleArrayList.size(); i++) {    // meal schedule 중 오늘이나 내일 배정된 것들이 있다면 추가
            if (mealScheduleArrayList.get(i).getDate().equals(today) ||
                    mealScheduleArrayList.get(i).getDate().equals(tomorrow))
                optionList.add(mealScheduleArrayList.get(i));
        }
        return optionList;
    }

    // 해당 끼니에 더 배정 안되도록 schedulehistory 조정
    public void setMealBanned(MealSchedule mealSchedule) {
//        String query = "UPDATE ScheduleHistory SET result = false WHERE user_id = " + mealSchedule.getUser_id() +
//                " AND menu_id = " + mealSchedule.getMenu_id() + " AND meal = " + mealSchedule.getMeal();
        ContentValues cv = new ContentValues();
        cv.put("result", "FALSE");
        String[] params = new String[]{mealSchedule.getUser_id().toString(), mealSchedule.getMenu_id().toString(), mealSchedule.getMeal()};
        db.update(T_SCHEDULEHISTORY, cv, "user_id=? AND menu_id=? AND meal=?", params);
    }

    // 바꾸고자 하는 식단 확정된 경우, 없애려는 자리에 해당 메뉴 업데이트 (수정, 삭제 공통) -> 옵션자리에 change 정보 넣음
    public void change(MealSchedule change, MealSchedule option) {
        SQLiteDatabase db = recommendController.getWritableDatabase();
        Integer scd_id = option.getScd_id();
        ContentValues cv = new ContentValues();
        cv.put("menu_id", change.getMenu_id());
        cv.put("user_id", change.getUser_id());
        cv.put("date", change.getDate());
        cv.put("meal", change.getMeal());
        cv.put("done", change.getDone());
        db.update(T_MEALSCHEDULE, cv, "scd_id=?", new String[]{scd_id.toString()});
//        String query = "UPDATE MealSchedule SET scd_id = " + change.getScd_id() + ", menu_id = " + change.getMenu_id() + ", user_id = "
//                + change.getUser_id() + ", date = " + change.getDate() + ", meal = " + change.getMeal() + ", done = " + change.getDone() + "" +
//                ", WHERE scd_id = " + scd_id;
//
//        // 실시간으로 바뀌어야 한다면
////        option.setScd_id(change.getScd_id());
////        option.setUser_id(change.getUser_id());
////        option.setMenu_id(change.getMenu_id());
////        option.setDate(change.getDate());
////        option.setMeal(change.getMeal());
////        option.setDone(change.getDone());
//        db.execSQL(query);
    }

    // 다른 가능한 메뉴 후보군들 받아오는 함수
    public ArrayList<Menu> getOtherCandidates(MealSchedule change, ArrayList<MenuScore> sortedCandidateList) {
        ArrayList<Integer> avoidList = new ArrayList<>();
        ArrayList<Menu> menuOptionList = new ArrayList<>(6);
        Menu menu;
        Integer menu_id;

        avoidList.add(change.getMenu_id()); // 처음 avoidList에는 바꾸고자 하는 메뉴의 아이디를 저장함

        for (int i=0; i<sortedCandidateList.size(); i++) {  // recommendcontroller getcandidate 참조
            MenuScore sortedCandidate = sortedCandidateList.get(i);
            Integer meal = 0;
            switch (change.getMeal()) {
                case "아침" : meal = 0; break;
                case "점심" : meal = 1; break;
                case "저녁" : meal = 2; break;
            }
            if (recommendController.isSuitable(sortedCandidate, meal, user_id) &&
                    recommendController.isDissimilar(sortedCandidate, user_id)){
                menu_id = sortedCandidate.getMenu_id();

                if (menuOptionList.size() >= 6) break;  // 6개 다 들어갔으면 break

                if (recommendController.posinIntegerList(menu_id, avoidList) == -1) {
                    // avoid list에도 없으면
                    menu = recommendController.MenuByMenu_id(menu_id);
                    avoidList.add(menu_id);
                    menuOptionList.add(menu);
                }
            }
        }
        return menuOptionList;
    }

    public void selectMenu(MealSchedule change, Menu selectedmenu) {    // changemeal과 거의 동일
        // 바꾸려는 mealschedule 위치에 menu 정보 넣음
        // 필요시 인덱스 인풋 추가 및 메뉴->어레이 리스트로 변경 가능
        SQLiteDatabase db = recommendController.getWritableDatabase();
        String query = "UPDATE MealSchedule SET menu_id = " + selectedmenu.getMenu_id() + " WHERE scd_id = " + change.getScd_id();
        db.execSQL(query);
    }

    public void minusMenuScore(Integer user_id, MealSchedule mealSchedule) {    // input mealschedule은 치워지는 애
        ArrayList<MenuScore> menuScoreArrayList = recommendController.MenuScoreByUserID(user_id);
        Menu minusMenu = recommendController.MenuByMenu_id(mealSchedule.getMenu_id());
        SQLiteDatabase db = recommendController.getWritableDatabase();

        // 개별 메뉴에 대한 감점
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            // 우선 감점해야되는 mealschedule의 menuid가 menuscore의 어디에 있는지 파악 -> 감점
            if (menuScoreArrayList.get(i).getMenu_id() == mealSchedule.getMenu_id()) {
                MenuScore minusMenuScore = menuScoreArrayList.get(i);
                // db update
                db.execSQL("UPDATE MenuScore SET score = score - 0.02 WHERE menu_id = "+ minusMenuScore.getMenu_id() );
                break;
            }
        }

        // 유사 메뉴들에 대한 감점
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            Menu compareMenu = recommendController.MenuByMenu_id(menuScoreArrayList.get(i).getMenu_id());
            if (isSimilar(minusMenu.getCode(), compareMenu.getCode())) {
                db.execSQL("UPDATE MenuScore SET score = score - 0.01 WHERE menu_id = "+ compareMenu.getMenu_id() );
            }
        }
    }

// 메뉴 수정 후 해당 메뉴 및 유사한 메뉴에 대한 점수를 가감처리합니다. 처리 자체는 change 또는 selectMenu 직전에 진행되어야 합니다. (모두 데이터베이스에 쿼리를 날리는 함수)
// 진행 sequence는 해당 개별 메뉴에 대해 0.02점 감점 후, 유사한 메뉴들에 대해 0.01점씩 감점합니다. 유사성을 따지는 알고리즘은 recommendcontroller의 isdissimilar를 따왔으며 해당 부분 참고하시고 알고리즘 내 수정 부분이 있었다면 호환시켜주시면 될 것 같습니다.

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void plusMenuScore(Integer user_id, Menu selectedMenu) {
        // minusMenuScore와 다른 이유는 getCandidate 및 selectMenu의 return type이 Menu이기 때문
        ArrayList<MenuScore> menuScoreArrayList = recommendController.MenuScoreByUserID(user_id);
        Menu plusMenu = selectedMenu;
        SQLiteDatabase db = recommendController.getWritableDatabase();

        // 개별 메뉴에 대한 가점
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            // 우선 가점해야되는 menuid가 menuscore의 어디에 있는지 파악 -> 가점
            if (menuScoreArrayList.get(i).getMenu_id() == selectedMenu.getMenu_id()) {
                MenuScore plusMenuScore = menuScoreArrayList.get(i);
                // db update
                db.execSQL("UPDATE MenuScore SET score = score + 0.02 WHERE menu_id = "+ plusMenu.getMenu_id() );
                break;
            }
        }

        // 유사 메뉴들에 대한 가점
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            Menu compareMenu = recommendController.MenuByMenu_id(menuScoreArrayList.get(i).getMenu_id());
            if (isSimilar(plusMenu.getCode(), compareMenu.getCode())) {
                db.execSQL("UPDATE MenuScore SET score = score + 0.01 WHERE menu_id = "+ compareMenu.getMenu_id() );
            }
        }
    }

// 진행 순서 및 알고리즘은 모두 minusMenuScore와 동일합니다.

////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public boolean isSimilar(String menu1Code, String menu2Code) {
        // 두 메뉴

        System.out.println(menu1Code+" vs "+menu2Code);
        int count = 0;
        String menu1Country = menu1Code.substring(0, 1);
        String menu1Type = menu1Code.substring(1, 2);
        String menu1Igd1 = menu1Code.substring(2, 4);
        String menu1Igd2 = menu1Code.substring(menu1Code.length() - 2, menu1Code.length());
        String menu2Country = menu2Code.substring(0, 1);
        String menu2Type = menu2Code.substring(1, 2);
        String menu2Igd1 = menu2Code.substring(2, 4);
        String menu2Igd2 = menu2Code.substring(menu2Code.length() - 2, menu2Code.length());

        if (menu1Country.equals(menu2Country)) count += 1;
        if (menu1Type.equals(menu2Type)) count += 1;
        if (menu1Igd1.equals(menu2Igd1) || menu1Igd1.equals(menu2Igd2)) count += 1;
        if (menu1Igd2.equals(menu2Igd1) || menu1Igd2.equals(menu2Igd2)) count += 1;

        if (count >= 3) return true;
        else return false;
    }

// 두 메뉴 코드를 비교하여 유사성을 판단합니다. input param만 바뀌고 내부 알고리즘은 recommend controller의 isdissimilar와 동일합니다.


}
