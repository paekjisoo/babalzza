package com.example.babalzzafinal.Boundary;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.Ingredient;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.text.SimpleDateFormat;

public class AddUserIngredientPopup_Activity extends AppCompatActivity {

    Ingredient ingredient;

    int y = 0, m = 0, d = 0;
    int ytoday = 2019, mtoday = 11, dtoday = 10;
    int expirationDue;
    int p;

    TextView showBuyDate;
    Button editBuyDate;
    Spinner reserveType;
    Button editExpirationDate;
    TextView getExpirationDate;
    Button buttonSaveIngredient;
    String dueDate;
    RecommendController ingredientController;
    TextView showName;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userigd_addpopup);

        ingredient = (Ingredient) getIntent().getSerializableExtra("ingredient");
        ingredientController = new RecommendController(this);

        ImageView showImage = findViewById(R.id.showImage);
        final EditText editQuantity = findViewById(R.id.editQuantity);
        editExpirationDate = findViewById(R.id.buttonEditExpirationDate);
        getExpirationDate = findViewById(R.id.editExpirationDate);

        // 식재료명, 단위
        showName = findViewById(R.id.showName);
        TextView unit = findViewById(R.id.unit);


        showName.setText(ingredient.getName());
        unit.setText(ingredient.getMeasure());

        // 이미지 설정
        switch (Integer.parseInt(ingredient.getCode())) {
            case 11:
                showImage.setImageResource(R.drawable.igd11);
                break;
            case 12:
                showImage.setImageResource(R.drawable.igd12);
                break;
            case 13:
                showImage.setImageResource(R.drawable.igd13);
                break;
            case 14:
                showImage.setImageResource(R.drawable.igd14);
                break;
            case 15:
                showImage.setImageResource(R.drawable.igd15);
                break;
            case 21:
                showImage.setImageResource(R.drawable.igd21);
                break;
            case 22:
                showImage.setImageResource(R.drawable.igd22);
                break;
            case 23:
                showImage.setImageResource(R.drawable.igd23);
                break;
            case 24:
                showImage.setImageResource(R.drawable.igd24);
                break;
            case 25:
                showImage.setImageResource(R.drawable.igd25);
                break;
            case 26:
                showImage.setImageResource(R.drawable.igd26);
                break;
            case 31:
                showImage.setImageResource(R.drawable.igd31);
                break;
            case 32:
                showImage.setImageResource(R.drawable.igd32);
                break;
            case 33:
                showImage.setImageResource(R.drawable.igd33);
                break;
            case 34:
                showImage.setImageResource(R.drawable.igd34);
                break;
            case 35:
                showImage.setImageResource(R.drawable.igd35);
                break;
            case 41:
                showImage.setImageResource(R.drawable.igd41);
                break;
            case 42:
                showImage.setImageResource(R.drawable.igd42);
                break;
            case 43:
                showImage.setImageResource(R.drawable.igd43);
                break;
            case 51:
                showImage.setImageResource(R.drawable.igd51);
                break;
            case 52:
                showImage.setImageResource(R.drawable.igd52);
                break;
            case 53:
                showImage.setImageResource(R.drawable.igd53);
                break;
            case 61:
                showImage.setImageResource(R.drawable.igd61);
                break;
            case 62:
                showImage.setImageResource(R.drawable.igd65);
                break;
            case 63:
                showImage.setImageResource(R.drawable.igd65);
                break;
            case 64:
                showImage.setImageResource(R.drawable.igd65);
                break;
            case 65:
                showImage.setImageResource(R.drawable.igd65);
                break;
        }

        // 구매일 설정
        showBuyDate = findViewById(R.id.showBuyDate);
        editBuyDate = findViewById(R.id.buttonEditBuyDate);

        editBuyDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBuyDate();
            }
        });

        //보관방법 설정
        reserveType = findViewById(R.id.reserveType);
        ArrayAdapter adapter;
        try{
            Integer.parseInt(ingredient.getFreezedterm());
            adapter = ArrayAdapter.createFromResource(this, R.array.reserveType1, android.R.layout.simple_spinner_item);
        }catch(NumberFormatException e){
            adapter = ArrayAdapter.createFromResource(this, R.array.reserveType2, android.R.layout.simple_spinner_item);
        }

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reserveType.setAdapter(adapter);
        //보관방법에 따른 유통기한 설정
        reserveType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (y == 0) {
                    getExpirationDate.setText("유통기한을 선택하세요");
                    return;
                }
                p = position;
                switch (position) {
                    case 1:
                        expirationDue = Integer.parseInt(ingredient.getRefrigeratedterm());
                        String expirationDate = changeDate(y, m, d, expirationDue);
                        editExpirationDate.setVisibility(View.GONE);
                        getExpirationDate.setText(expirationDate);
                        dueDate = expirationDate;
                        break;
                    case 2:
                        expirationDue = Integer.parseInt(ingredient.getFreezedterm());
                        expirationDate = changeDate(y, m, d, expirationDue);
                        dueDate = expirationDate;
                        editExpirationDate.setVisibility(View.GONE);
                        getExpirationDate.setText(expirationDate);
                        break;
                    case 0:
                        editExpirationDate.setVisibility(View.VISIBLE);
                        getExpirationDate.setText("유통기한을 선택하세요.");
                        getExpirationDate.setVisibility(View.VISIBLE);
                        dueDate = null;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        //유통기한 직접입력
        editExpirationDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExpirationDate();
                dueDate = getExpirationDate.getText().toString();
            }
        });

        //내용 저장
        buttonSaveIngredient = findViewById(R.id.buttonSaveIngredient);
        buttonSaveIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float quantity;
                if(editQuantity.getText().toString().equals("")){
                    String message = "수량을 입력하지 않았습니다";
                    showErrorMessage(message);
                    return;
                }
                try{
                    quantity = Integer.parseInt(editQuantity.getText().toString());
                }catch(NumberFormatException e){
                    String message = "수량을 잘못 입력했습니다.";
                    showErrorMessage(message);
                    return;
                }
                int check = 0;

                String today = getToday();

                if(quantity <= 0) check = 4;
                else if(showBuyDate.getText().toString().equals("") ) check = 2;
                else if(showBuyDate.getText().toString().compareTo(today) > 0) check = 6;
                else if(p == 0 && getExpirationDate.getText().toString().equals("")) check = 3;
                else if(getExpirationDate.getText().toString().compareTo(showBuyDate.getText().toString()) <= 0) check = 5;
                else check = 0;

                switch (check) {
                    case 0:
                        dueDate = getExpirationDate.getText().toString();

                        UserIngredient u = (UserIngredient) getIntent().getSerializableExtra("userIngredient");
                        u.setIgd_id(ingredient.getIgd_id());
                        u.setAmount(quantity);
                        u.setBuydate(showBuyDate.getText().toString());
                        u.setExpirationdate(dueDate);
                        ingredientController.insertUserIngredient(u);
                        confirm(ingredient.getName(), u.getAmount(), ingredient.getMeasure());


                        break;
                    case 2:
                        String message = "구매일을 입력하지 않았습니다.";
                        showErrorMessage(message);
                        break;
                    case 3:
                        message = "유통기한을 입력하지 않았습니다.";
                        showErrorMessage(message);
                        break;
                    case 4:
                        message = "수량이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                    case 5:
                        message = "유통기한이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                    case 6:
                        message = "구매일이 잘못 설정되었습니다.";
                        showErrorMessage(message);
                        break;
                }



            }
        });
    }
    // 구매일 달력에서 가져오기
    void showBuyDate() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                y = year;
                m = month + 1;
                d = dayOfMonth;
                String buyDate;
                if(month+1 < 10)  {
                    if(dayOfMonth < 10)
                        buyDate = year + "-0" + (month+1) + "-0" + dayOfMonth;
                    else
                        buyDate = year + "-0" + (month+1) + "-" + dayOfMonth;
                }
                else {
                    if(dayOfMonth < 10)
                        buyDate = year + "-" + (month+1) + "-0" + dayOfMonth;
                    else
                        buyDate = year + "-" + (month+1) + "-" + dayOfMonth;
                }
                showBuyDate.setText(buyDate);
            }
        }, ytoday, mtoday, dtoday);
        datePickerDialog.show();
    }
    // 유통기한 달력에서 가져오기
    void showExpirationDate() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String ExpirationDate;
                if(month+1 < 10)  {
                    if(dayOfMonth < 10)
                        ExpirationDate = year + "-0" + (month+1) + "-0" + dayOfMonth;
                    else
                        ExpirationDate = year + "-0" + (month+1) + "-" + dayOfMonth;
                }
                else {
                    if(dayOfMonth < 10)
                        ExpirationDate = year + "-" + (month+1) + "-0" + dayOfMonth;
                    else
                        ExpirationDate = year + "-" + (month+1) + "-" + dayOfMonth;
                }
                getExpirationDate.setText(ExpirationDate);
            }
        }, ytoday, mtoday, dtoday);
        datePickerDialog.show();
    }

    String changeDate(int year, int month, int dayofMonth, int add) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd");
        // 날짜 더하기
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, dayofMonth);
        cal.add(Calendar.DATE, add);
        if (cal.get(Calendar.MONTH) + 1 < 10) {
            if (cal.get(Calendar.DAY_OF_MONTH) < 10) {
                return cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH) + 1) + "-0" + cal.get(Calendar.DAY_OF_MONTH);
            } else
                return cal.get(Calendar.YEAR) + "-0" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
        } else {
            if (cal.get(Calendar.DAY_OF_MONTH) < 10) {
                return cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-0" + cal.get(Calendar.DAY_OF_MONTH);
            } else
                return cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DAY_OF_MONTH);
        }
    }

    void confirm(String name, float quantity, String unit){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String message = name +" "+quantity+""+unit+" 이/가 추가되었습니다.";
        builder.setMessage(message);
        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    void showErrorMessage(String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);

        builder.setNeutralButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    String getToday(){
        if (mtoday + 1 < 10) {
            if (dtoday < 10) {
                return ytoday + "-0" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-0" + (mtoday + 1) + "-" + dtoday;
        } else {
            if (dtoday < 10) {
                return ytoday + "-" + (mtoday + 1) + "-0" + dtoday;
            } else
                return ytoday + "-" + (mtoday + 1) + "-" + dtoday;
        }
    }
}
