package com.example.babalzzafinal.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.RecommendController;
import com.example.babalzzafinal.Entity.User;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;

import java.util.ArrayList;

public class LogIn extends AppCompatActivity {
    private RecommendController controller;
    private User user;

    static ArrayList<UserIngredient> userIngredientArrayList;
    RecommendController ingredientController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Intent intent = getIntent();

        controller = new RecommendController(getApplicationContext());
        user = new User();
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수
    public void activity_LogIn(View view) {
        ingredientController = new RecommendController(this);

        EditText et_ID = findViewById(R.id.et_ID);
        EditText et_Password = findViewById(R.id.et_Password);
        String userId = et_ID.getText().toString();
        String password = et_Password.getText().toString();

        try {
            String result = login(userId, password);

            if (result.equals("ok")) {
                Intent login_successful;
                userIngredientArrayList = ingredientController.getAllUserIngredients();
                if(userIngredientArrayList.isEmpty())
                    login_successful = new Intent(this, NoIngredient.class);
                else
                    login_successful = new Intent(this, Recommend_Main.class);
                login_successful.putExtra("userid", userId);
                startActivity(login_successful);
                finish();
            }
            else
                Toast.makeText(LogIn.this, result, Toast.LENGTH_LONG).show();
        }
        catch (Exception ex) {
            String message = ex.getMessage().toString();
            Toast.makeText(LogIn.this, message, Toast.LENGTH_LONG).show();
            return;
        }
    }

    public String login (String userId, String password) {
        try {
            user = controller.UserByUserEmail(userId);

            if (user == null)
                return "로그인 실패";

            if (password.equals(user.getPassword()))
                return "ok";
            else
                return "사용자 정보를 확인해주십시오.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, com.example.babalzzafinal.Boundary.MainActivity.class);
        startActivity(intent);
        finish();
    }

}