package com.example.babalzzafinal.Entity;

public class ShoppingMemo {
    private Integer memo_id;
    private String igdname;
    private Float amount;
    private String unit;

    public ShoppingMemo(){}

    public Integer getMemo_Id() {return memo_id;}

    public void setMemo_Id(Integer memo_id) {this.memo_id = memo_id;}

    public String getIgdname() {return igdname;}

    public void setIgdname(String igdname) {this.igdname = igdname;}

    public Float getAmount() {return amount;}

    public void setAmount(Float amount) {this.amount = amount;}

    public String getUnit() {return unit;}

    public void setUnit(String unit) {this.unit = unit;}

}
