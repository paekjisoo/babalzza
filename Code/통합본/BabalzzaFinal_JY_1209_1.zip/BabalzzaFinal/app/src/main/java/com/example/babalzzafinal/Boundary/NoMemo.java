package com.example.babalzzafinal.Boundary;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzzafinal.Controller.IngredientController;
import com.example.babalzzafinal.Controller.MemoController;
import com.example.babalzzafinal.Entity.Ingredient;
import com.example.babalzzafinal.Entity.ShoppingMemo;
import com.example.babalzzafinal.Entity.UserIngredient;
import com.example.babalzzafinal.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class NoMemo extends AppCompatActivity {
    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<ShoppingMemo> shoppingMemoArrayList;
    IngredientController ingredientController;
    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_empty);

        Button addFirst = findViewById(R.id.addFirstButton);
        addFirst.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(NoMemo.this, Memo_Main.class);
                startActivity(intent);
            }
        });

        ingredientController = new IngredientController(this);
        memoController = new MemoController(this);
        userIngredientArrayList = ingredientController.getAllUserIngredients();
        shoppingMemoArrayList = memoController.getAllMemo();

        //bottomNavigationView 에서 클릭
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.fridge:
                        Intent intent;
                        if(userIngredientArrayList.isEmpty()) {
                            intent = new Intent(NoMemo.this, NoIngredient.class);
                        }
                        else {
                            intent = new Intent(NoMemo.this, UserIngredient_Activity.class);
                        }
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.schedule:
                        Toast.makeText(NoMemo.this, "추천으로 연결", Toast.LENGTH_SHORT).show();
                        intent = new Intent(NoMemo.this, Recommend_Main.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.memo:
                        if(shoppingMemoArrayList.isEmpty()){
                            return true;
                        }
                        else {
                            Toast.makeText(NoMemo.this, "장보기 메모로 연결", Toast.LENGTH_SHORT).show();
                            intent = new Intent(NoMemo.this, Memo_Main.class);
                            startActivity(intent);
                            finish();
                            return true;
                        }
                    }
                return false;
            }
        });

    }

    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("밥알짜 를 종료하시겠습니까?");

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Intent intent = new Intent(NoMemo.this, LogIn.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }
}

