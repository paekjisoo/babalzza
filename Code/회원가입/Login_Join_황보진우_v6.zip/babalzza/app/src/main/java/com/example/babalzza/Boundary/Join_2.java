package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;


public class Join_2 extends Activity {
    String userid;
    String nickname;
    String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_2);

        Intent join_1 = getIntent();
        userid = join_1.getStringExtra("userid");
        nickname = join_1.getStringExtra("nickname");
        password = join_1.getStringExtra("password");
    }

    public void activity_minus(View view) {
    }

    public void activity_plus(View view) {
    }

    public void activity_join_2(View view) {
        Intent join_2 = new Intent(this, Join_3.class);
        join_2.putExtra("userid", userid);
        join_2.putExtra("nickname", nickname);
        join_2.putExtra("password", password);
        startActivity(join_2);
    }
}
