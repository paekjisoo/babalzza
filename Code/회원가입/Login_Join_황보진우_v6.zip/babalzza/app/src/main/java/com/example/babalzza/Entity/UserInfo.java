package com.example.babalzza.Entity;

public class UserInfo {
    private String userid;
    private String ninckname;
    private String password;

    public String getId() {
        return userid;
    }

    public void setId(String userid) {
        this.userid = userid;
    }

    public String getNickname() {
        return ninckname;
    }

    public void setNickname(String ninckname) {
        this.ninckname = ninckname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
