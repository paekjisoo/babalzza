package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;

import com.example.babalzza.Entity.UserInfoManager;
import com.example.babalzza.R;

public class Join_6 extends Activity {
    private String userid;
    private String nickname;
    private String password;
    protected static UserInfoManager userInfoManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_6);
        Intent join_5 = getIntent();
        userInfoManager = new UserInfoManager(Join_6.this, "user.db",null,1);
        userid = join_5.getStringExtra("userid");
        nickname = join_5.getStringExtra("nickname");
        password = join_5.getStringExtra("password");
    }

    public void activity_join_6(View view) {
        String result = userInfoManager.insert(userid, nickname, password);
        if (result.equals("ok")) {
            Intent join_6 = new Intent(this, Join_7.class);
            startActivity(join_6);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }
}