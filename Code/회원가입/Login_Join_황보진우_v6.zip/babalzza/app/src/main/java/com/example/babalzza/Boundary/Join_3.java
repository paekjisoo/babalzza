package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

public class Join_3 extends Activity {
    String userid;
    String nickname;
    String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_3);
        Intent join_2 = getIntent();
        userid = join_2.getStringExtra("userid");
        nickname = join_2.getStringExtra("nickname");
        password = join_2.getStringExtra("password");
    }

    public void activity_join_3(View view) {
        Intent join_3 = new Intent(this, Join_4.class);
        join_3.putExtra("userid", userid);
        join_3.putExtra("nickname", nickname);
        join_3.putExtra("password", password);
        startActivity(join_3);
    }
}
