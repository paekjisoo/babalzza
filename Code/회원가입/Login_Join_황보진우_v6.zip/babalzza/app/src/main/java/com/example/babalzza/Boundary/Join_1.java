package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Controller.ValidationController;
import com.example.babalzza.Entity.UserInfoManager;
import com.example.babalzza.R;

public class Join_1 extends AppCompatActivity {
    private UserInfoManager userInfoManager;
    private boolean id_Checked;
    private boolean nickname_Checked;
    private String userid;
    private String nickname;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_1);
        Intent signin = getIntent();
        userInfoManager = new UserInfoManager(Join_1.this, "user.db",null,1);
    }

    // 입력받은 ID의 적절성을 확인하는 함수
    public void activity_checkID(View view) {
        id_Checked = false;
        EditText et_newUSERID = findViewById(R.id.et_newUSERID);
        userid = et_newUSERID.getText().toString();

        String result = ValidationController.check_USERID(userInfoManager, userid);

        if (result.equals("사용 가능한 아이디입니다.")) {
            id_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 Nickname의 중복 여부를 확인하는 함수
    public void activity_checkNickname(View view) {
        nickname_Checked = false;
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        nickname = et_Nickname.getText().toString();

        String result = ValidationController.check_NICKNAME(userInfoManager, nickname);

        if (result.equals("사용 가능한 닉네임입니다.")) {
            nickname_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 값들의 유효성을 확인하고 다음 화면으로 넘기는 함수
    public void activity_join_1(View view) {
        // ID 중복확인 필수
        if (id_Checked == false) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", "아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }

        // Nickname 중복확인 필수
        if (nickname_Checked == false) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", "닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }

        // 확인된 ID, 닉네임이 현재 입력된 정보와 다를 때
        EditText et_newEmail = findViewById(R.id.et_newUSERID);
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        String currentID = et_newEmail.getText().toString();
        String currentNick = et_Nickname.getText().toString();
        if (!currentID.equals(userid)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        if (!currentNick.equals(nickname)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }

        // 비밀번호의 적절성을 확인한 후 다음 액티비티로 유저정보를 전달
        EditText et_newPassword = findViewById(R.id.et_newPassword);
        EditText et_confirmPassword = findViewById(R.id.et_confirmPassword);
        String pw1 = et_newPassword.getText().toString();
        String pw2 = et_confirmPassword.getText().toString();

        String result = ValidationController.check_PASSWORD(pw1, pw2);

        if (result.equals("ok")) {
            Intent Join_1 = new Intent(this, Join_2.class);
            Join_1.putExtra("userid", userid);
            Join_1.putExtra("nickname", nickname);
            Join_1.putExtra("password", pw1);
            startActivity(Join_1);
            return;
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message",result);
            startActivity(pop);
            return;
        }
    }

    // 회원가입을 취소하고 첫 화면으로 돌아가는 함수
    public void activity_joinCancel(View view) { finish(); }
}