package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

public class Join_4 extends Activity {
    String userid;
    String nickname;
    String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_4);
        Intent join_3 = getIntent();
        userid = join_3.getStringExtra("userid");
        nickname = join_3.getStringExtra("nickname");
        password = join_3.getStringExtra("password");
    }

    public void activity_join_4(View view) {
        Intent join_4 = new Intent(this, Join_5.class);
        join_4.putExtra("userid", userid);
        join_4.putExtra("nickname", password);
        join_4.putExtra("password", nickname);
        startActivity(join_4);
    }
}
