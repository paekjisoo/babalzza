package com.example.babalzza.Controller;
import android.util.Log;

import com.example.babalzza.Entity.UserInfo;
import com.example.babalzza.Entity.UserInfoManager;

public class LoginController{

    public String login (UserInfoManager userInfoManager, String userId, String password) {

        if (userInfoManager == null)
            return "DB Load Failed";

        UserInfo userInfo = userInfoManager.getUserInfo(userId, "USERID");

        if (userInfo == null)
            return "로그인 실패";

        if (userId.equals(userInfo.getId()) &&
            password.equals(userInfo.getPassword()))
                return "ok";
        else
                return "사용자 정보를 확인해주십시오.";
    }
}
