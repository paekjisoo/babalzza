package com.example.babalzza.Entity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class UserInfoManager extends SQLiteOpenHelper {

    public UserInfoManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query = "CREATE TABLE IF NOT EXISTS user (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERID TEXT NOT NULL, NICKNAME TEXT NOT NULL, PASSWORD TEXT NOT NULL)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
        String query = "DROP TABLE IF EXISTS user";
        database.execSQL(query);
        onCreate(database);
    }

    public String insert(String userid, String nickname, String password) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "INSERT INTO user (USERID, NICKNAME, PASSWORD) VALUES ('" + userid + "', '" + nickname + "' , '" + password + "')";
            database.execSQL(query);
            return "ok";
        }
        catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public List<UserInfo> getAllUserInfos() {
        List<UserInfo> userInfos = new ArrayList<>();

        try{
            Cursor cursor = this.getAllData();

            if(!cursor.moveToFirst())
                return null;

            while(cursor.moveToNext()) {
                String userId = cursor.getString(cursor.getColumnIndex("USERID"));
                String nickName = cursor.getString(cursor.getColumnIndex("NICKNAME"));
                String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));

                UserInfo userInfo = new UserInfo();
                userInfo.setId(userId);
                userInfo.setNickname(nickName);
                userInfo.setPassword(password);

                userInfos.add(userInfo);
            }
        }
        catch (Exception ex) {
            return null;
        }

        return userInfos;
    }

    public UserInfo getUserInfo(String input, String searchby) {
        UserInfo userInfo = new UserInfo();
        Cursor cursor = this.getAllData();

        while(cursor.moveToNext()) {
            if (searchby.equals("USERID"))
                if (cursor.getString(1).equals(input)) {
                    userInfo.setId(cursor.getString(1));
                    userInfo.setNickname(cursor.getString(2));
                    userInfo.setPassword(cursor.getString(3));
                    break;
                }
            if (searchby.equals("NICKNAME"))
                if (cursor.getString(2).equals(input)) {
                    userInfo.setId(cursor.getString(1));
                    userInfo.setNickname(cursor.getString(2));
                    userInfo.setPassword(cursor.getString(3));
                    break;
                }
        }

        return userInfo;
    }

    public Cursor getAllData() {
        try {
            SQLiteDatabase database = this.getReadableDatabase();
            String query = "SELECT * FROM user";
            Cursor cursor = database.rawQuery(query, null);
            return cursor;
        }
        catch (Exception ex) {
            return null;
        }
    }

    public String delete(String userid) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "DELETE FROM user WHERE USERID = '" + userid + "';";
            database.execSQL(query);
            return"Deleted Successfully";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public void updatePassword(String userid, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE user SET PASSWORD = '" + password + "' WHERE USERID = '"+ userid +"';");
    }

    public void updateNickname(String userid, String nickname) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE user SET NICKNAME = '" + nickname + "' WHERE USERID = '"+ userid +"';");
    }
}