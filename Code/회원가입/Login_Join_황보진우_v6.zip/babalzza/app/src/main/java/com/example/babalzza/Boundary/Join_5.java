package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

public class Join_5 extends Activity {
    String userid;
    String nickname;
    String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_5);
        Intent join_4 = getIntent();
        userid = join_4.getStringExtra("userid");
        nickname = join_4.getStringExtra("nickname");
        password = join_4.getStringExtra("password");
    }

    public void activity_join_5(View view) {
        Intent join_5 = new Intent(this, Join_6.class);
        join_5.putExtra("userid", userid);
        join_5.putExtra("nickname", password);
        join_5.putExtra("password", nickname);
        startActivity(join_5);
    }
}
