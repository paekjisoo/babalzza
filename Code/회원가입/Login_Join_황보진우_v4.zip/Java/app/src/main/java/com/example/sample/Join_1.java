package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Join_1 extends Activity {
    private UserInformation mUserInformation;
    private SQLiteDatabase db;
    boolean ID_Checked;
    boolean Nickname_Checked;
    String userid;
    String nickname;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_1);
        Intent signin = getIntent();
        mUserInformation = new UserInformation(Join_1.this, "user.db",null,1);
    }

    // 입력받은 ID의 적절성과 중복 여부를 확인하는 함수
    public void activity_checkID(View view) {
        ID_Checked = false;
        EditText et_newEmail = findViewById(R.id.et_newEmail);
        userid = et_newEmail.getText().toString();
        // 중복 여부 판단
        Cursor cursor = mUserInformation.getAllData();
        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            if (userid.equals(temp_id)) {
                Intent pop = new Intent(this, PopupMessage.class);
                pop.putExtra("message", "이미 사용중인 아이디입니다.");
                startActivity(pop);
                return;
            }
        }
        ID_Checked = CheckID();
    }

    // 입력받은 ID의 적절성을 확인하는 함수
    protected boolean CheckID() {
        Intent pop = new Intent(this, PopupMessage.class);
        // 길이 체크
        if (userid.length() < 6 || userid.length() > 16) {
            pop.putExtra("message", "아이디는 6글자 이상, 16글자 이하의 알파벳, 또는 알파벳+숫자의 조합이어야 합니다.");
            startActivity(pop);
            return false;
        }
        // 패턴 체크(알파벳 또는 알파벳+숫자)
        boolean result = true;
        Pattern p1 = Pattern.compile("^[0-9a-zA-Z]*$");
        Matcher m1 = p1.matcher(userid);
        if (m1.find()) {
            Pattern p2 = Pattern.compile("^[0-9]*$");
            Matcher m2 = p2.matcher(userid);
            if (m2.find())
                result = false;
        } else
            result = false;
        // DB에 중복된 아이디가 있는지 체크 후 없으면 "사용 가능", 있으면 "사용할 수 없음"(미완)
        if (result) {
            pop.putExtra("message", "사용 가능한 아이디입니다.");
            startActivity(pop);
            return true;
        } else {
            pop.putExtra("message", "사용할 수 없는 아이디입니다.");
            startActivity(pop);
            return false;
        }
    }

    // 입력받은 Nickname의 중복 여부를 확인하는 함수
    public void activity_checkNickName(View view) {
        Nickname_Checked = false;
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        nickname = et_Nickname.getText().toString();
        Intent pop = new Intent(this, PopupMessage.class);
        // 닉네임 미입력 시
        if (nickname == null || nickname.equals("")) {
            pop.putExtra("message", "닉네임을 입력해주십시오.");
            startActivity(pop);
            return;
        }
        // 중복 여부 판단
        Cursor cursor = mUserInformation.getAllData();
        while(cursor.moveToNext()) {
            String temp_nick = cursor.getString(cursor.getColumnIndex("NICKNAME"));
            if (nickname.equals(temp_nick)) {
                pop.putExtra("message", "이미 사용중인 닉네임입니다.");
                startActivity(pop);
                return;
            }
        }
        pop.putExtra("message", "사용 가능한 닉네임입니다.");
        startActivity(pop);
        Nickname_Checked = true;
    }

    // 입력받은 값들의 유효성을 확인하고 다음 화면으로 넘기는 함수
    public void activity_join_1(View view) {
        Intent pop = new Intent(this, PopupMessage.class);
        // ID 중복확인 필수
        if (!ID_Checked) {
            pop.putExtra("message", "아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        // Nickname 중복확인 필수
        if (!Nickname_Checked) {
            pop.putExtra("message", "닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        // 확인된 ID, 닉네임이 현재 입력된 정보와 다를 때
        EditText et_newEmail = findViewById(R.id.et_newEmail);
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        String currentID = et_newEmail.getText().toString();
        String currentNick = et_Nickname.getText().toString();
        if (!currentID.equals(userid)) {
            pop.putExtra("message","아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        if (!currentNick.equals(nickname)) {
            pop.putExtra("message","닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        // 비밀번호 적절성 판단
        EditText et_newPassword = findViewById(R.id.et_newPassword);
        EditText et_confirmPassword = findViewById(R.id.et_confirmPassword);
        String pw1 = et_newPassword.getText().toString();
        String pw2 = et_confirmPassword.getText().toString();
        // 비밀번호의 조건 충족 여부에 따라 각기 다른 result 반환
        int result = checkPW(pw1);
        String message = "";
        switch (result) {
            case 0: break;
            case 1: message = "비밀번호를 입력하십시오."; break;
            case 2: message = "비밀번호는 8글자 이상, 16글자 미만입니다."; break;
            case 3: message = "알파벳 대문자, 소문자, 특수문자, 숫자 중 3개 이상을 조합하십시오."; break;
            case 99: message = "알수없는 오류";
        }
        // result가 0으로 나오면 계속 진행, 아니면 오류 메시지 팝업
        if (result != 0) {
            pop.putExtra("message", message);
            startActivity(pop);
            return;
        }
        else {
            // 비밀번호 두개의 일치여부 확인. 일치하면 회원가입, 아니면 오류 메시지 팝업
            if (!pw1.equals(pw2)) {
                message = "비밀번호가 일치하지 않습니다!";
                pop.putExtra("message", message);
                startActivity(pop);
                return;
            }
            else {
                // 회원가입승인, 회원정보 임시 저장 후 유저 선호정보 등록 화면으로 넘어감
                Intent join_1 = new Intent(this, Join_2.class);
                join_1.putExtra("userid", userid);
                join_1.putExtra("nickname", nickname);
                join_1.putExtra("password", pw1);
                startActivity(join_1);
                return;
            }
        }
    }

    // 비밀번호의 적절성을 확인하는 함수
    protected static int checkPW(String input) {
        try {
            // 입력 없음
            if (input == null || input.equals(""))
                return 1;
            // 길이 체크
            if (input.length() < 8 || input.length() > 16)
                return 2;
            // 패턴 체크(알파벳 대문자, 알파벳 소문자, 숫자, 특수문자 중 3개 이상 조합)
            Pattern pAlphabetLow = Pattern.compile("[a-z]"); Matcher mAlphabetLow = pAlphabetLow.matcher(input);
            Pattern pAlphabetUp = Pattern.compile("[A-Z]"); Matcher mAlphabetUp = pAlphabetUp.matcher(input);
            Pattern pSymbol = Pattern.compile("\\p{Punct}"); Matcher mSymbol = pSymbol.matcher(input);
            Pattern pNumber = Pattern.compile("[0-9]"); Matcher mNumber = pNumber.matcher(input);
            int result = 0;
            if (mAlphabetLow.find()) result++;
            if (mAlphabetUp.find()) result++;
            if (mSymbol.find()) result++;
            if (mNumber.find()) result++;
            if (result < 3) return 3;
            else return 0;
        }
        catch (Exception ex) {
            return 99;
        }
    }

    // 회원가입을 취소하고 첫 화면으로 돌아가는 함수
    public void activity_joinCancel(View view) { finish(); }
}