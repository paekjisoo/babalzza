package com.example.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ViewUserInfo extends Activity{
    private UserInformation mUserInformation;
    protected String userid;
    protected String nickname;
    protected String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewuserinfo);
        Intent login_successful = getIntent();

        userid = login_successful.getStringExtra("userid");

        mUserInformation = new UserInformation(getApplicationContext(), "user.db", null, 1);
        Cursor cursor = mUserInformation.getAllData();
        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            if (userid.equals(temp_id)) {
                nickname = cursor.getString(cursor.getColumnIndex("NICKNAME"));
                password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                break;
            }
        }

        TextView t_viewNN = findViewById(R.id.t_viewNN);
        TextView t_viewID = findViewById(R.id.t_viewID);
        TextView t_viewPW = findViewById(R.id.t_viewPW);

        t_viewNN.setText(nickname);
        t_viewID.setText(userid);
        t_viewPW.setText(password);
    }

    // 닉네임을 변경하는 함수
    public void activity_changeNN(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("닉네임 변경");
        final EditText et_Nickname = new EditText(this);
        alert.setView(et_Nickname);
        alert.setPositiveButton("변경", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String new_Nickname = et_Nickname.getText().toString();
                if(checkNickName(new_Nickname))
                    mUserInformation.updateNickname(userid, new_Nickname);
                TextView t_viewNN = findViewById(R.id.t_viewNN);
                t_viewNN.setText(new_Nickname);
            }
        });
        alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.show();
    }

    // 비밀번호를 변경하는 함수
    public void activity_changePW(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("비밀번호 변경");
        alert.setMessage("비밀번호는 알파벳 대문자, 소문자, 특수문자, 숫자의 4개 중 최소 3개 조합. 글자수는 8자 이상, 16자 이하");
        final EditText et_Password = new EditText(this);
        alert.setView(et_Password);
        alert.setPositiveButton("변경", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String new_Password = et_Password.getText().toString();
                int result = checkPW(new_Password);
                if (result == 0) {
                    mUserInformation.updatePassword(userid, new_Password);
                    TextView t_viewPW = findViewById(R.id.t_viewPW);
                    t_viewPW.setText(new_Password);
                }
                else {
                    Toast.makeText(ViewUserInfo.this, "부적절한 비밀번호", Toast.LENGTH_LONG).show();
                }
            }
        });
        alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.show();
    }

    // 닉네임 중복 판단
    public boolean checkNickName(String nickname) {
        // 닉네임 미입력 시
        if (nickname == null || nickname.equals(""))
            return false;
        // 중복 여부 판단
        Cursor cursor = mUserInformation.getAllData();
        while(cursor.moveToNext()) {
            String temp_nick = cursor.getString(cursor.getColumnIndex("NICKNAME"));
            if (nickname.equals(temp_nick))
                return false;
        }
        return true;
    }

    // 비밀번호 적절성 판단
    protected static int checkPW(String input) {
        try {
            // 입력 없음
            if (input == null || input.equals(""))
                return 1;
            // 길이 체크
            if (input.length() < 8 || input.length() > 16)
                return 2;
            // 패턴 체크(알파벳 대문자, 알파벳 소문자, 숫자, 특수문자 중 3개 이상 조합)
            Pattern pAlphabetLow = Pattern.compile("[a-z]"); Matcher mAlphabetLow = pAlphabetLow.matcher(input);
            Pattern pAlphabetUp = Pattern.compile("[A-Z]"); Matcher mAlphabetUp = pAlphabetUp.matcher(input);
            Pattern pSymbol = Pattern.compile("\\p{Punct}"); Matcher mSymbol = pSymbol.matcher(input);
            Pattern pNumber = Pattern.compile("[0-9]"); Matcher mNumber = pNumber.matcher(input);
            int result = 0;
            if (mAlphabetLow.find()) result++;
            if (mAlphabetUp.find()) result++;
            if (mSymbol.find()) result++;
            if (mNumber.find()) result++;
            if (result < 3) return 3;
            else return 0;
        }
        catch (Exception ex) {
            return 99;
        }
    }

    // 여기서는 백버튼을 눌러도 뒤로가지 않는다.(로그인 화면으로 돌아가지 않는다)
    @Override
    public void onBackPressed() {}
}