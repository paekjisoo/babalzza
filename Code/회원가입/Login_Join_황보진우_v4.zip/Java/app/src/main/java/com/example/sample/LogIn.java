package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends Activity {
    private UserInformation mUserInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Intent login = getIntent();
        mUserInformation = new UserInformation(getApplicationContext(), "user.db", null, 1);
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수
    public void activity_LogIn(View view) {
        EditText et_ID = findViewById(R.id.et_ID);
        EditText et_Password = findViewById(R.id.et_Password);
        String userid = et_ID.getText().toString();
        String password = et_Password.getText().toString();

        Cursor cursor = mUserInformation.getAllData();
        if(cursor.getCount() == 0) {
            Toast.makeText(LogIn.this, "로그인 실패", Toast.LENGTH_LONG).show();
            return;
        }
        else {
            while(cursor.moveToNext()) {
                String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
                String temp_pw = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                if (userid.equals(temp_id)) {
                    if (password.equals(temp_pw)) {
                        Intent login_successful = new Intent(this, ViewUserInfo.class);
                        login_successful.putExtra("userid", userid);
                        startActivity(login_successful);
                        return;
                    }
                    else {
                        Toast.makeText(LogIn.this, "비밀번호를 확인해주십시오.", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
            }
            Toast.makeText(LogIn.this, "아이디를 찾을 수 없습니다.", Toast.LENGTH_LONG).show();
            return;
        }
    }
}