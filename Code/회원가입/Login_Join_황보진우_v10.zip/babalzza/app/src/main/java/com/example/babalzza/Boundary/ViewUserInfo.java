package com.example.babalzza.Boundary;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Controller.UserInformationController;
import com.example.babalzza.Controller.ValidationController;
import com.example.babalzza.Entity.UserInformation;
import com.example.babalzza.R;

public class ViewUserInfo extends AppCompatActivity {
    protected String userid;
    protected String nickname;
    protected String password;
    protected static UserInformation userInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewuserinfo);
        Intent intent = getIntent();
        userInformation = new UserInformation(getApplicationContext());

        userid = intent.getStringExtra("userid");
        nickname = UserInformationController.getUserInfo(getApplicationContext(), userInformation, userid, "USERID").getNickname();
        password = UserInformationController.getUserInfo(getApplicationContext(), userInformation, userid, "USERID").getPassword();

        TextView viewNickname = findViewById(R.id.viewNickname);
        TextView viewUserId = findViewById(R.id.viewUserId);
        TextView viewPassword = findViewById(R.id.viewPassword);

        viewNickname.setText(nickname);
        viewUserId.setText(userid);
        viewPassword.setText(password);
    }

    // 닉네임을 변경하는 함수
    public void activity_changeNN(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("닉네임 변경");
        final EditText newNickname = new EditText(this);
        alert.setView(newNickname);
        alert.setPositiveButton("변경", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String new_Nickname = newNickname.getText().toString();
                String result = ValidationController.check_NICKNAME(getApplicationContext(), userInformation, new_Nickname);
                if(result.equals("사용 가능한 닉네임입니다."))
                    userInformation.updateNickname(userid, new_Nickname);
                TextView t_viewNN = findViewById(R.id.viewNickname);
                t_viewNN.setText(new_Nickname);
            }
        });
        alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.show();
    }

    // 비밀번호를 변경하는 함수
    public void activity_changePW(View view) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("비밀번호 변경");
        alert.setMessage("비밀번호는 알파벳 대문자, 소문자, 특수문자, 숫자의 4개 중 최소 3개 조합. 글자수는 8자 이상, 16자 이하");
        final EditText newPassword = new EditText(this);
        alert.setView(newPassword);
        alert.setPositiveButton("변경", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String new_Password = newPassword.getText().toString();
                String result = ValidationController.check_PASSWORD(new_Password, new_Password);
                if (result.equals("ok")) {
                    userInformation.updatePassword(userid, new_Password);
                    TextView t_viewPW = findViewById(R.id.viewPassword);
                    t_viewPW.setText(new_Password);
                }
                else {
                    Toast.makeText(ViewUserInfo.this, "부적절한 비밀번호", Toast.LENGTH_LONG).show();
                }
            }
        });
        alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        alert.show();
    }

    // 여기서는 백버튼을 눌러도 뒤로가지 않는다.(로그인 화면으로 돌아가지 않는다)
    @Override
    public void onBackPressed() {}

    // 로그아웃 후 최초 화면으로 돌아간다.
    public void activity_logout(View view) {
        Intent intent = new Intent(this, FirstScreen.class);
        startActivity(intent);
    }
}