package com.example.babalzza.Controller;

import android.content.Context;

import com.example.babalzza.Entity.UserInformation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationController {

    // 아이디 적절성 체크
    public static String check_USERID(Context context, UserInformation userInformation, String userid) {
        String result;

        // 길이 체크
        result = lengthCheck_USERID(userid);
        if (!result.equals("ok"))
            return result;
        // 패턴 체크
        result = patternCheck_USERID(userid);
        if (!result.equals("ok"))
            return result;
        // 중복 체크
        result = overlapCheck_USERID(context, userInformation, userid);
        return result;
    }


    // 아이디 길이 체크
    public static String lengthCheck_USERID(String userid) {
        if (userid.length() < 6 || userid.length() > 16)
            return "아이디는 6글자 이상, 16글자 이하의 알파벳, 또는 알파벳+숫자의 조합이어야 합니다.";
        else
            return "ok";
    }

    // 아이디 패턴 체크(알파벳 또는 알파벳+숫자)
    public static String patternCheck_USERID(String userid) {
        Pattern p1 = Pattern.compile("^[0-9a-zA-Z]*$");
        Matcher m1 = p1.matcher(userid);

        if (m1.find()) {
            Pattern p2 = Pattern.compile("^[0-9]*$");
            Matcher m2 = p2.matcher(userid);
            if (m2.find())
                return "형식에 맞지 않는 아이디입니다.";
            else
                return "ok";
        }
        else
            return "형식에 맞지 않는 아이디입니다.";
    }

    // 아이디 중복 체크
    public static String overlapCheck_USERID(Context context, UserInformation userInformation, String userId) {
        try {
            UserInformation userInfo = UserInformationController.getUserInfo(context, userInformation, userId, "USERID");

            if(userInfo == null) {
                return "' " +  userId + " '" +"(은)는\n\n사용하실 수 있는 아이디 입니다.";
            }
            else {
                return "' " +  userId + " '" + "(은)는\n\n이미 있는 아이디 입니다.";
            }
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    // 닉네임 적절성 체크
    public static String check_NICKNAME(Context context, UserInformation userInformation, String nickname) {
        // 닉네임 미입력 시
        if (nickname == null || nickname.equals(""))
            return "닉네임을 입력해주십시오.";

        // 중복 판단
        try {
            UserInformation userInfo = UserInformationController.getUserInfo(context, userInformation, nickname, "NICKNAME");

            if(userInfo == null)
                return "' " +  nickname + " '" +"(은)는\n\n사용하실 수 있는 닉네임 입니다.";
            else
                return "' " + nickname + " '" + "(은)는\n\n이미 있는 닉네임 입니다.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    // 비밀번호 적절성 체크
    public static String check_PASSWORD (String pw1, String pw2) {

        try {
            // 입력 없음
            if (pw1 == null || pw1.equals(""))
                return "비밀번호를 입력하십시오.";

            // 길이 체크
            if (pw1.length() < 8 || pw1.length() > 16)
                return "비밀번호는 8글자 이상, 16글자 미만입니다.";

            // 패턴 체크(알파벳 대문자, 알파벳 소문자, 숫자, 특수문자 중 3개 이상 조합)
            Pattern pAlphabetLow = Pattern.compile("[a-z]"); Matcher mAlphabetLow = pAlphabetLow.matcher(pw1);
            Pattern pAlphabetUp = Pattern.compile("[A-Z]"); Matcher mAlphabetUp = pAlphabetUp.matcher(pw1);
            Pattern pSymbol = Pattern.compile("\\p{Punct}"); Matcher mSymbol = pSymbol.matcher(pw1);
            Pattern pNumber = Pattern.compile("[0-9]"); Matcher mNumber = pNumber.matcher(pw1);
            int result = 0;
            if (mAlphabetLow.find()) result++;
            if (mAlphabetUp.find()) result++;
            if (mSymbol.find()) result++;
            if (mNumber.find()) result++;
            if (result < 3) return "알파벳 대문자, 소문자, 특수문자, 숫자 중 3개 이상을 조합하십시오.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }

        // 비밀번호 두개의 일치여부 확인. 일치하면 회원가입, 아니면 오류 메시지 팝업
        if (!pw1.equals(pw2))
            return "비밀번호가 일치하지 않습니다!";
        else
            return "ok";
    }
}
