package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Controller.IngredientController;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import com.example.babalzza.Resource.IngredientAdapter;
import java.util.ArrayList;

public class Join_test extends AppCompatActivity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도
    private ArrayList<Boolean> preferencesCooking;// 조리법별 선호도
    private int proficiency; // 난이도별 선호도

    private TextView tuserid, tnickname, tpassword, tproficiency;
    private ListView list1, list2, list3, list4;
    private IngredientAdapter adapter1;
    private ArrayAdapter<String> adapter2, adapter3, adapter4;
    private ArrayList<String> Nationality, Category, Cooking;
    private Ingredient ingredient;
    private ArrayList<Ingredient> selected;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_test);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");
        preferencesCooking = (ArrayList<Boolean>) intent.getSerializableExtra("preferencesCooking");
        proficiency = intent.getIntExtra("proficiency", 0);

        tuserid = findViewById(R.id.userid);
        tnickname = findViewById(R.id.nickname);
        tpassword = findViewById(R.id.password);
        tproficiency = findViewById(R.id.proficiency);

        tuserid.setText(userid);
        tnickname.setText(nickname);
        tpassword.setText(password);
        tproficiency.setText(String.valueOf(proficiency));

        list1 = findViewById(R.id.list1);
        list2 = findViewById(R.id.list2);
        list3 = findViewById(R.id.list3);
        list4 = findViewById(R.id.list4);

        // 못먹는 식재료
        selected = new ArrayList<>();
        ingredient = new Ingredient(getApplicationContext());
        for (int i = 0; i < badIngredients.size(); i++) {
            int id = badIngredients.get(i);
            Ingredient item = IngredientController.getIngredientInfo(getApplicationContext(), ingredient, id);
            selected.add(item);
        }
        adapter1 = new IngredientAdapter(selected);
        list1.setAdapter(adapter1);

        // 선호 국가
        Nationality = new ArrayList<>();
        for(int i = 0; i < 5; i++) {
            String item = new String();
            switch (preferencesNationality.get(i)) {
                case 2:
                    item = "No." + (i+1) + ": 너무 좋아요";
                    break;
                case 1:
                    item = "No." + (i+1) + ": 좋아요";
                    break;
                case 0:
                    item = "No." + (i+1) + ": 보통이에요";
                    break;
                case -1:
                    item = "No." + (i+1) + ": 싷어요";
                    break;
                case -2:
                    item = "No." + (i+1) + ": 너무 싫어요";
            }
            Nationality.add(item);
        }
        adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_1, Nationality);
        list2.setAdapter(adapter2);

        // 선호 식재료
        Category = new ArrayList<>();
        for(int i = 0; i < 22; i++) {
            String item = new String();
            switch (preferencesCategory.get(i)) {
                case 2:
                    item = "No." + (i+1) + ": 너무 좋아요";
                    break;
                case 1:
                    item = "No." + (i+1) + ": 좋아요";
                    break;
                case 0:
                    item = "No." + (i+1) + ": 보통이에요";
                    break;
                case -1:
                    item = "No." + (i+1) + ": 싷어요";
                    break;
                case -2:
                    item = "No." + (i+1) + ": 너무 싫어요";
            }
            Category.add(item);
        }
        adapter3 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_1, Category);
        list3.setAdapter(adapter3);

        // 선호 조리법
        Cooking = new ArrayList<>();
        for(int i = 0; i < 8; i++) {
            if (preferencesCooking.get(i))
                Cooking.add("No." + (i+1) + ": " + "좋아요");
            else
                Cooking.add("No." + (i+1) + ": " + "싫어요");
        }
        adapter4 = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, Cooking);
        list4.setAdapter(adapter4);

        setListViewHeightBasedOnChildren(list1);
    }
    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            // pre-condition
            return;
        }

        int totalHeight = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);

        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }
}
