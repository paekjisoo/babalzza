package com.example.babalzza.Controller;


import android.content.Context;
import com.example.babalzza.Entity.Ingredient;

import java.util.ArrayList;

public class IngredientController {

    public static String insert(Ingredient ingredient, String name) {
        String result = ingredient.insert(name);
        return result;
    }

    public static Ingredient getIngredientInfo(Context context, Ingredient ingredient, String name) {
        ArrayList<Ingredient> ingredients;
        ingredients = ingredient.getAllIngredient(context);

        if (ingredients == null)
            return null;

        for (int i = 0; i < ingredients.size(); i++) {
            Ingredient temp = ingredients.get(i);
            if (temp.getName().equals(name)) return ingredients.get(i);
        }

        return null;
    }

    public static Ingredient getIngredientInfo(Context context, Ingredient ingredient, int igr_id) {
        ArrayList<Ingredient> ingredients;
        ingredients = ingredient.getAllIngredient(context);

        if (ingredients == null)
            return null;

        for (int i = 0; i < ingredients.size(); i++) {
            Ingredient temp = ingredients.get(i);
            if (temp.getIgr_id() == igr_id) return ingredients.get(i);
        }

        return null;
    }
}
