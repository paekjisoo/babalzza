package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_3 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferencesNationality;

    private Spinner listKorea, listJapan, listChina, listWestern, listOthers;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> preferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_3);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");

        preferences = new ArrayList<>();
        preferences.add("보통이에요");
        preferences.add("너무 좋아요");
        preferences.add("좋아요");
        preferences.add("싫어요");
        preferences.add("너무 싫어요");
        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, preferences);

        // 국가별 리스트 매칭
        listKorea = findViewById(R.id.listKorea);
        listJapan = findViewById(R.id.listJapan);
        listChina = findViewById(R.id.listChina);
        listWestern = findViewById(R.id.listWestern);
        listOthers = findViewById(R.id.listOthers);

        // 각 리스트에 리스너 달기
        listKorea.setOnItemSelectedListener(this);
        listJapan.setOnItemSelectedListener(this);
        listChina.setOnItemSelectedListener(this);
        listWestern.setOnItemSelectedListener(this);
        listOthers.setOnItemSelectedListener(this);

        // 5개의 리스트에 하나의 어댑터를 세팅
        listKorea.setAdapter(adapter);
        listJapan.setAdapter(adapter);
        listChina.setAdapter(adapter);
        listWestern.setAdapter(adapter);
        listOthers.setAdapter(adapter);

        // 다음 액티비티로 넘길 선호도 리스트를 999으로 초기화한다.
        preferencesNationality = new ArrayList<>();
        for (int i = 0; i < 5; i++) preferencesNationality.add(999);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = (String) parent.getItemAtPosition(position);
        int index = 0;

        switch(parent.getId()) {
            case R.id.listKorea:
                index = 0;
                break;
            case R.id.listJapan:
                index = 1;
                break;
            case R.id.listChina:
                index = 2;
                break;
            case R.id.listWestern:
                index = 3;
                break;
            case R.id.listOthers:
                index = 4;
        }

        switch(item) {
            case "너무 좋아요":
                preferencesNationality.set(index, 2);
                break;
            case "좋아요":
                preferencesNationality.set(index, 1);
                break;
            case "보통이에요":
                preferencesNationality.set(index, 0);
                break;
            case "싫어요":
                preferencesNationality.set(index, -1);
                break;
            case "너무 싫어요":
                preferencesNationality.set(index, -2);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {}

    public void next(View view) {
        Intent intent = new Intent(this, Join_4.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        intent.putExtra("badIngredients", badIngredients);
        intent.putExtra("preferencesNationality", preferencesNationality);
        startActivity(intent);
    }

    public void back(View view) { finish(); }

    @Override
    public void onBackPressed() { }
}
