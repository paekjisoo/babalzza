package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzza.Controller.UserInformationController;
import com.example.babalzza.Entity.UserInformation;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_7 extends AppCompatActivity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도
    private ArrayList<Boolean> preferencesCooking;// 조리법별 선호도
    private int proficiency; // 난이도별 선호도
    private UserInformation userInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_7);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");
        preferencesCooking = (ArrayList<Boolean>) intent.getSerializableExtra("preferencesCooking");
        proficiency = intent.getIntExtra("proficiency", 0);

        userInformation = new UserInformation(getApplicationContext());
        String result = UserInformationController.insert(userInformation, userid, nickname, password);

        // 회원 추가 실패 시 첫 화면으로 돌아간다.
        if (result.equals("ok")) {
            startScoreAdjustment();
        }
        else {
            Intent goBack = new Intent(this, FirstScreen.class);
            startActivity(goBack);
            Toast.makeText(getApplicationContext(), "회원가입 실패 : " + result, Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // 회원 선호 정보를 메뉴 점수에 반영한다. (미완)
    public void startScoreAdjustment() {

    }

    // 로그인 화면으로 돌아간다.
    public void next(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
        finish();
    }

    public void onBackPressed() { }
}
