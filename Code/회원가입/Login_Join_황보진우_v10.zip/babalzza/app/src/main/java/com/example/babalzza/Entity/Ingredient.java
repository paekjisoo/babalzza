package com.example.babalzza.Entity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.Image;
import java.util.ArrayList;

public class Ingredient extends SQLiteOpenHelper {
    private int Igr_id;
    private String name;
    private Image image;
    private int code;
    private String measure;
    private String refrigeratedterm;
    private String freezedterm;

    public int getIgr_id() { return Igr_id; }
    public void setIgd_id(int Igr_id) { this.Igr_id = Igr_id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Image getImage() { return image; }
    public void setImage(Image image) { this.image = image; }
    public Integer getCode() { return code; }
    public void setCode(Integer code) { this.code = code; }
    public String getMeasure() { return measure; }
    public void setMeasure(String measure) { this.measure = measure; }
    public String getRefrigeratedterm() { return refrigeratedterm; }
    public void setRefrigeratedterm(String refrigeratedterm) { this.refrigeratedterm = refrigeratedterm; }
    public String getFreezedterm() { return freezedterm; }
    public void setFreezedterm(String freezedterm) { this.freezedterm = freezedterm; }

    public Ingredient(Context context) {
        super(context, "ingredient", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE IF NOT EXISTS ingredient" +
                " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NAME TEXT, " +
                "IMAGE IMAGE, " +
                "CODE INTEGER, " +
                "MEASURE TEXT, " +
                "REFRIGERATEDTERM TEXT, " +
                "FREEZEDTERM TEXT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS ingredient";
        db.execSQL(query);
        onCreate(db);
    }

    public String insert(String name) {
        try {
            SQLiteDatabase database = getWritableDatabase();
            String query = "INSERT INTO ingredient" +
                    " (NAME) VALUES (" +
                    "'" + name + "')";
            database.execSQL(query);
            return "ok";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public ArrayList<Ingredient> getAllIngredient(Context ct) {
        String query = "SELECT * FROM Ingredient";
        ArrayList<Ingredient> ingredientArrayList = new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.rawQuery(query, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Ingredient ingredient = new Ingredient(ct);

                ingredient.setIgd_id(cursor.getInt(0));
                ingredient.setName(cursor.getString(1));
                ingredient.setCode(cursor.getInt(2));
                ingredient.setMeasure(cursor.getString(3));
                ingredient.setRefrigeratedterm(cursor.getString(4));
                ingredient.setFreezedterm(cursor.getString(5));

                ingredientArrayList.add(ingredient);
            }
        }
        database.close();
        return ingredientArrayList;
    }
}
