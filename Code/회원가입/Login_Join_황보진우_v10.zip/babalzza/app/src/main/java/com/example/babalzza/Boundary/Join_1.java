package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Controller.ValidationController;
import com.example.babalzza.Entity.UserInformation;
import com.example.babalzza.R;

public class Join_1 extends AppCompatActivity {
    private UserInformation userInformation;
    private boolean id_Checked = false;
    private boolean nickname_Checked = false;
    private String userid;
    private String nickname;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_1);

        Intent intent = getIntent();

        userInformation = new UserInformation(getApplicationContext());
    }

    // 입력받은 ID의 적절성을 확인하는 함수
    public void checkID(View view) {
        id_Checked = false;
        EditText newUserId = findViewById(R.id.newUserId);
        userid = newUserId.getText().toString();

        String result = ValidationController.check_USERID(getApplicationContext(), userInformation, userid);

        if (result.equals("' " +  userid + " '" +"(은)는\n\n사용하실 수 있는 아이디 입니다.")) {
            id_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 Nickname의 중복 여부를 확인하는 함수
    public void checkNickname(View view) {
        nickname_Checked = false;
        EditText newNickname = findViewById(R.id.newNickname);
        nickname = newNickname.getText().toString();

        String result = ValidationController.check_NICKNAME(getApplicationContext(), userInformation, nickname);

        if (result.equals("' " +  nickname + " '" +"(은)는\n\n사용하실 수 있는 닉네임 입니다.")) {
            nickname_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 값들의 유효성을 확인하고 다음 화면으로 넘기는 함수
    public void next(View view) {
        // 중복확인 필수
        if (id_Checked == false || nickname_Checked == false) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", "아이디, 닉네임\n\n 중복확인을 하지 않았습니다.");
            startActivity(pop);
            return;
        }

        // 확인된 ID, 닉네임이 현재 입력된 정보와 다를 때
        EditText newUserId = findViewById(R.id.newUserId);
        EditText newNickname = findViewById(R.id.newNickname);
        String currentID = newUserId.getText().toString();
        String currentNick = newNickname.getText().toString();
        if (!currentID.equals(userid)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        if (!currentNick.equals(nickname)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }

        // 비밀번호의 적절성을 확인한 후 다음 액티비티로 유저정보를 전달
        EditText newPassword = findViewById(R.id.newPassword);
        EditText confirmPassword = findViewById(R.id.confirmPassword);
        String pw1 = newPassword.getText().toString();
        String pw2 = confirmPassword.getText().toString();

        String result = ValidationController.check_PASSWORD(pw1, pw2);

        if (result.equals("ok")) {
            Intent intent = new Intent(this, Join_2.class);
            intent.putExtra("userid", userid);
            intent.putExtra("nickname", nickname);
            intent.putExtra("password", pw1);
            startActivity(intent);
            return;
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message",result);
            startActivity(pop);
            return;
        }
    }

    // 회원가입을 취소하고 첫 화면으로 돌아가는 함수
    public void activity_joinCancel(View view) { finish(); }
}