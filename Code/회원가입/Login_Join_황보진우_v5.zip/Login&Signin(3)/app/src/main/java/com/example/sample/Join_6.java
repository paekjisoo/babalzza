package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Join_6 extends Activity {
    String userid;
    String nickname;
    String password;
    SQLiteDatabase db;
    UserInformation mUserInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_6);
        Intent join_5 = getIntent();
        userid = join_5.getStringExtra("userid");
        nickname = join_5.getStringExtra("nickname");
        password = join_5.getStringExtra("password");
    }

    public void activity_join_6(View view) {
        mUserInformation = new UserInformation(getApplicationContext(), "user.db", null, 1);
        mUserInformation.insert(userid, nickname, password);
        Intent join_6 = new Intent(this, Join_7.class);
        startActivity(join_6);
        return;
    }
}