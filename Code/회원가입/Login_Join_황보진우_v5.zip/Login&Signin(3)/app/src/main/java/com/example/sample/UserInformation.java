package com.example.sample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserInformation extends SQLiteOpenHelper {

    public UserInformation(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + "user " +
                "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "USERID TEXT, " +
                "NICKNAME TEXT, " +
                "PASSWORD TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "user");
        onCreate(db);
    }

    public void insert(String userid, String nickname, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put("USERID", userid);
        value.put("NICKNAME", nickname);
        value.put("PASSWORD", password);
        db.insert("user", null, value);
    }

    public void delete(String userid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM user WHERE USERID = '" + userid + "';");
        db.close();
    }

    public void updatePassword(String userid, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE user SET PASSWORD = '" + password + "' WHERE USERID = '"+ userid +"';");
        db.close();
    }

    public void updateNickname(String userid, String nickname) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE user SET NICKNAME = '" + nickname + "' WHERE USERID = '"+ userid +"';");
        db.close();
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user", null);
        return cursor;
    }
}