package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

public class Join_7 extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_7);
        Intent join_6 = getIntent();
    }

    public void activity_LogInScreen(View view) {
        Intent login = new Intent(this, LogIn.class);
        startActivity(login);
    }
}
