package com.example.Babalzza.Controller;

import android.database.Cursor;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Babalzza.Entity.UserInformation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationController extends AppCompatActivity {
    protected static UserInformation userInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // DB 생성
        userInformation = new UserInformation(ValidationController.this, "user.db",null,1);
    }

    public static String validation_USERID(String userid) {
        // 길이 체크
        if (userid.length() < 6 || userid.length() > 16)
            return "아이디는 6글자 이상, 16글자 이하의 알파벳, 또는 알파벳+숫자의 조합이어야 합니다.";

        // 패턴 체크(알파벳 또는 알파벳+숫자)
        Pattern p1 = Pattern.compile("^[0-9a-zA-Z]*$");
        Matcher m1 = p1.matcher(userid);
        if (m1.find()) {
            Pattern p2 = Pattern.compile("^[0-9]*$");
            Matcher m2 = p2.matcher(userid);
            if (m2.find())
                return "형식에 맞지 않는 아이디입니다.";
        }
        else {
            return "형식에 맞지 않는 아이디입니다.";
        }

            // 중복 여부 판단
            Cursor cursor = userInformation.getAllData();
            while (cursor.moveToNext()) {
                String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
                if (userid.equals(temp_id))
                    return "이미 사용중인 아이디입니다.";
            }

            return "사용가능한 아이디입니다.";
    }

    public static String validation_NICKNAME(String nickname) {
        // 닉네임 미입력 시
        if (nickname == null || nickname.equals(""))
            return "닉네임을 입력해주십시오.";

        // 중복 여부 판단
        Cursor cursor = userInformation.getAllData();
        while(cursor.moveToNext()) {
            String temp_nick = cursor.getString(cursor.getColumnIndex("NICKNAME"));
            if (nickname.equals(temp_nick))
                return "이미 사용중인 닉네임입니다.";
        }

        return "사용 가능한 닉네임입니다.";
    }

    public static String validation_PASSWORD (String pw1, String pw2) {
        // 비밀번호 적절성 판단
        try {
            // 입력 없음
            if (pw1 == null || pw1.equals(""))
                return "비밀번호를 입력하십시오.";
            // 길이 체크
            if (pw1.length() < 8 || pw1.length() > 16)
                return "비밀번호는 8글자 이상, 16글자 미만입니다.";
            // 패턴 체크(알파벳 대문자, 알파벳 소문자, 숫자, 특수문자 중 3개 이상 조합)
            Pattern pAlphabetLow = Pattern.compile("[a-z]"); Matcher mAlphabetLow = pAlphabetLow.matcher(pw1);
            Pattern pAlphabetUp = Pattern.compile("[A-Z]"); Matcher mAlphabetUp = pAlphabetUp.matcher(pw1);
            Pattern pSymbol = Pattern.compile("\\p{Punct}"); Matcher mSymbol = pSymbol.matcher(pw1);
            Pattern pNumber = Pattern.compile("[0-9]"); Matcher mNumber = pNumber.matcher(pw1);
            int result = 0;
            if (mAlphabetLow.find()) result++;
            if (mAlphabetUp.find()) result++;
            if (mSymbol.find()) result++;
            if (mNumber.find()) result++;
            if (result < 3) return "알파벳 대문자, 소문자, 특수문자, 숫자 중 3개 이상을 조합하십시오.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }

        // 비밀번호 두개의 일치여부 확인. 일치하면 회원가입, 아니면 오류 메시지 팝업
        if (!pw1.equals(pw2))
            return "비밀번호가 일치하지 않습니다!";
        else
            return "ok";
    }
}
