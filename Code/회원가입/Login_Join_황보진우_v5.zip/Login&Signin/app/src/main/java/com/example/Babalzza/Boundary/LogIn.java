package com.example.Babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.Babalzza.Controller.LoginController;
import com.example.sample.R;

public class LogIn extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Intent login = getIntent();
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수
    public void activity_LogIn(View view) {
        EditText et_ID = findViewById(R.id.et_ID);
        EditText et_Password = findViewById(R.id.et_Password);
        String userid = et_ID.getText().toString();
        String password = et_Password.getText().toString();

        String result = LoginController.loginResult(userid, password);

        if (result.equals("ok")) {
            Intent login_successful = new Intent(this, ViewUserInfo.class);
            login_successful.putExtra("userid", userid);
            startActivity(login_successful);
            finish();
        }
        else {
            Toast.makeText(LogIn.this, result, Toast.LENGTH_LONG).show();
            return;
        }
    }

    public void onBackPressed() {
        Intent FirstScreen = new Intent(this, FirstScreen.class);
        startActivity(FirstScreen);
        finish();
    }

}