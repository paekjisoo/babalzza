package com.example.Babalzza.Controller;

import android.database.Cursor;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.Babalzza.Entity.UserInformation;

public class UserInformationController extends AppCompatActivity {
    protected static UserInformation userInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // DB 생성
        userInformation = new UserInformation(UserInformationController.this, "user.db",null,1);
    }

    public static void addUserInformation(String userid, String nickname, String password) {
        userInformation.insert(userid, nickname, password);
    }

    public static void updateNickname(String nickname, String userid) {
        userInformation.updateNickname(nickname, userid);
    }

    public static void updatePassword(String password, String userid) {
        userInformation.updateNickname(password, userid);
    }

    public static void deleteUserInformation(String userid) {
        userInformation.delete(userid);
    }

    public static String getNickname(String userid) {
        String result = "";
        Cursor cursor = userInformation.getAllData();

        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            if (userid.equals(temp_id)) {
                result = cursor.getString(cursor.getColumnIndex("NICKNAME"));
                break;
            }
        }
        return result;
    }

    public static String getPassword(String userid) {
        String result = "";
        Cursor cursor = userInformation.getAllData();

        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            if (userid.equals(temp_id)) {
                result = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                break;
            }
        }
        return result;
    }
}
