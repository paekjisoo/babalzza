package com.example.Babalzza.Controller;

import android.database.Cursor;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.Babalzza.Entity.UserInformation;

public class LoginController extends AppCompatActivity {
    protected static UserInformation userInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // DB 생성
        userInformation = new UserInformation(LoginController.this, "user.db",null,1);
    }

    public static String loginResult (String userid, String password) {
        Cursor cursor = userInformation.getAllData();
        if(cursor.getCount() == 0)
            return "로그인 실패";
        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            String temp_pw = cursor.getString(cursor.getColumnIndex("PASSWORD"));
            if (userid.equals(temp_id)) {
                if (password.equals(temp_pw))
                    return "ok";
                else
                    return "비밀번호를 확인해주십시오.";
            }
        }
        return "아이디를 찾을 수 없습니다.";
    }
}
