package com.example.Babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Babalzza.Entity.UserInformation;
import com.example.Babalzza.Controller.ValidationController;
import com.example.sample.R;

public class Join_1 extends AppCompatActivity {
    private UserInformation mUserInformation;
    boolean ID_Checked;
    boolean Nickname_Checked;
    String userid;
    String nickname;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_1);
        Intent signin = getIntent();
        mUserInformation = new UserInformation(Join_1.this, "user.db",null,1);
    }

    public void activity_checkID(View view) {
        EditText et_newEmail = findViewById(R.id.et_newEmail);
        String userid = et_newEmail.getText().toString();
        String result = ValidationController.validation_USERID(userid);

        if (result.equals("사용 가능한 아이디입니다.")) {
            ID_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 Nickname의 중복 여부를 확인하는 함수
    public void activity_checkNickName(View view) {
        Nickname_Checked = false;
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        nickname = et_Nickname.getText().toString();

        String result = ValidationController.validation_NICKNAME(nickname);

        if (result.equals("사용 가능한 닉네임입니다.")) {
            Nickname_Checked = true;
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 입력받은 값들의 유효성을 확인하고 다음 화면으로 넘기는 함수
    public void activity_join_1(View view) {
        // ID 중복확인 필수
        if (!ID_Checked) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", "아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        // Nickname 중복확인 필수
        if (!Nickname_Checked) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", "닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        // 확인된 ID, 닉네임이 현재 입력된 정보와 다를 때
        EditText et_newEmail = findViewById(R.id.et_newEmail);
        EditText et_Nickname = findViewById(R.id.et_Nickname);
        String currentID = et_newEmail.getText().toString();
        String currentNick = et_Nickname.getText().toString();
        if (!currentID.equals(userid)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","아이디 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }
        if (!currentNick.equals(nickname)) {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message","닉네임 중복 확인을 해주세요.");
            startActivity(pop);
            return;
        }

        // 비밀번호의 적절성을 확인한 후 다음 액티비티로 유저정보를 전달
        EditText et_newPassword = findViewById(R.id.et_newPassword);
        EditText et_confirmPassword = findViewById(R.id.et_confirmPassword);
        String pw1 = et_newPassword.getText().toString();
        String pw2 = et_confirmPassword.getText().toString();

        String result = ValidationController.validation_PASSWORD(pw1, pw2);

        if (result.equals("ok")) {
            Intent next = new Intent(this, Join_2.class);
            next.putExtra("userid", userid);
            next.putExtra("nickname", nickname);
            next.putExtra("password", pw1);
            startActivity(next);
            return;
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message",result);
            startActivity(pop);
            return;
        }
    }

    // 회원가입을 취소하고 첫 화면으로 돌아가는 함수
    public void activity_joinCancel(View view) { finish(); }

}