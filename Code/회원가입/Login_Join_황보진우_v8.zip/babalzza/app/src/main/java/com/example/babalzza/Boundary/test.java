package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import com.example.babalzza.Resource.IngredientAdapter;
import java.util.ArrayList;

public class test extends AppCompatActivity {
    private String userId;
    private String nickname;
    private String password;
    private ArrayList<Integer> selectedItemIds;
    private Ingredient ingredient;
    private ArrayList<Ingredient> ingredients;
    private ArrayList<Ingredient> selectedIngredients;
    private IngredientAdapter adapter;
    private ListView list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        Intent intent = getIntent();

        userId = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        selectedItemIds = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");

        selectedIngredients = new ArrayList<>();
        ingredient = new Ingredient(getApplicationContext());
        ingredients = ingredient.getAllIngredient(getApplicationContext());

        for (int i : selectedItemIds)
            selectedIngredients.add(ingredients.get(i - 1));

        adapter = new IngredientAdapter(selectedIngredients);
        list = findViewById(R.id.testView);
        list.setAdapter(adapter);
    }
}
