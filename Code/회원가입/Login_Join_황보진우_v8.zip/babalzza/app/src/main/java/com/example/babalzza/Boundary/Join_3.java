package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ExpandableListView;

import androidx.annotation.Nullable;

import com.example.babalzza.R;
import com.example.babalzza.Resource.PreferenceAdapter;

import java.util.ArrayList;

public class Join_3 extends Activity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> selectedItemsIds; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferences;
    private PreferenceAdapter adapter;
    private ExpandableListView listKorea, listJapan, listChina, listWestern, listOthers;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_3);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        selectedItemsIds = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");

        adapter = new PreferenceAdapter(R.layout.row_expandable, R.layout.row_expandable);

        listKorea = findViewById(R.id.listKorea);
        listJapan = findViewById(R.id.listJapan);
        listChina = findViewById(R.id.listChina);
        listWestern = findViewById(R.id.listWestern);
        listOthers = findViewById(R.id.listOthers);

        listKorea.setAdapter(adapter);
        listJapan.setAdapter(adapter);
        listChina.setAdapter(adapter);
        listWestern.setAdapter(adapter);
        listOthers.setAdapter(adapter);

        preferences = new ArrayList<>();
        for (int i = 0; i < 5; i++) preferences.add(0);

        setClickListener(listKorea, 0);
        setClickListener(listJapan, 1);
        setClickListener(listChina, 2);
        setClickListener(listWestern, 3);
        setClickListener(listOthers, 4);
    }

    private void setClickListener(ExpandableListView list, final int group) {
       list.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
           @Override
           public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
               String preference = (String) parent.getItemAtPosition(childPosition);
               switch(preference) {
                   case "너무 좋아요":
                       preferences.set(group, 2);
                       break;
                   case "좋아요":
                       preferences.set(group, 1);
                       break;
                   case "보통이에요":
                       preferences.set(group, 0);
                       break;
                   case "싫어요":
                       preferences.set(group, -1);
                       break;
                   case "너무 싫어요":
                       preferences.set(group, -2);
               }
               return false;
           }
       });
    }

    public void activity_join_3(View view) {
        Intent intent = new Intent(this, Join_4.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        intent.putExtra("badIngredients", selectedItemsIds);
        intent.putExtra("preferencesNationality", preferences);
        Log.d("LOG_TEST:", "" + preferences.get(0));
        Log.d("LOG_TEST:", "" + preferences.get(1));
        Log.d("LOG_TEST:", "" + preferences.get(2));
        Log.d("LOG_TEST:", "" + preferences.get(3));
        Log.d("LOG_TEST:", "" + preferences.get(4));
        startActivity(intent);
    }
}
