package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

import java.util.ArrayList;

public class Join_5 extends Activity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> selectedItemsIds; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_5);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        selectedItemsIds = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");
    }

    public void activity_join_5(View view) {
        Intent intent = new Intent(this, Join_6.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", password);
        intent.putExtra("password", nickname);
        intent.putExtra("badIngredients", selectedItemsIds);
        intent.putExtra("preferencesNationality", preferencesNationality);
        intent.putExtra("preferencesCategory", preferencesCategory);
        startActivity(intent);
    }
}
