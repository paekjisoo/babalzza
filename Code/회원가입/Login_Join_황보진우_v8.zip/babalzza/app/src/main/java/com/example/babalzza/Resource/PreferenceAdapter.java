package com.example.babalzza.Resource;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import com.example.babalzza.R;

import java.util.ArrayList;

public class PreferenceAdapter extends BaseExpandableListAdapter {
    private int groupLayout = 0;
    private int childLayout = 0;
    private String groupName;
    private ArrayList<String> preferences = new ArrayList<>();

    public PreferenceAdapter(int groupLayout, int childLayout) {
        this.groupLayout = groupLayout;
        this.childLayout = childLayout;
        this.groupName = "선호도";
        this.preferences.add("너무 좋아요");
        this.preferences.add("좋아요");
        this.preferences.add("보통이에요");
        this.preferences.add("싫어요");
        this.preferences.add("너무 싫어요");
    }

    @Override
    public int getGroupCount() {
        return 1;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return preferences.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return null;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return preferences.get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return 0;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(this.groupLayout, parent, false);
        }

        TextView groupText = convertView.findViewById(R.id.childText);
        groupText.setText(groupName);

        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(this.groupLayout, parent, false);
        }

        TextView childText = convertView.findViewById(R.id.childText);
        childText.setText(preferences.get(childPosition));

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
