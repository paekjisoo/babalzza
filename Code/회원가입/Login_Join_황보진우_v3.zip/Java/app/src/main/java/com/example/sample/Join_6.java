package com.example.sample;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Join_6 extends Activity {
    String userid;
    String nickname;
    String password;
    SQLiteDatabase db;
    UserInformation mUserInformation;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_6);
        Intent join_5 = getIntent();
        userid = join_5.getStringExtra("userid");
        nickname = join_5.getStringExtra("nickname");
        password = join_5.getStringExtra("password");
    }

    public void activity_join_6(View view) {
        boolean result = insert(userid, nickname, password);
        if (!result) {
            Toast.makeText(Join_6.this, "회원가입 오류", Toast.LENGTH_LONG).show();
            Intent failed = new Intent(this, FirstScreen.class);
            startActivity(failed);
            return;
        }
        else {
            Intent join_6 = new Intent(this, Join_7.class);
            startActivity(join_6);
            return;
        }
    }

    // DB 함수
    public boolean insert(String userid, String nickname, String password) {
        db = mUserInformation.getWritableDatabase();
        ContentValues value = new ContentValues();

        value.put("USERID", userid);
        value.put("NICKNAME", nickname);
        value.put("PASSWORD", password);
        long result = db.insert("user_table", null, value);

        if (result == -1)
            return false;
        else
            return true;
    }
}