package com.example.babalzza.Resource;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import java.util.ArrayList;

public class IngredientAdapter extends BaseAdapter implements Filterable {
    private ArrayList<Ingredient> ingredients;
    private ArrayList<Ingredient> filteredIngredients;
    private Filter filter;

    public IngredientAdapter(Context context, Ingredient ingredient) {
        ingredients = ingredient.getAllIngredient(context);
        filteredIngredients = ingredients;
    }
    public IngredientAdapter(ArrayList<Ingredient> ingredients) {
        this.ingredients = ingredients;
        filteredIngredients = ingredients;
    }

    @Override
    public int getCount() {
        return filteredIngredients.size();
    }

    @Override
    public Object getItem(int position) {
        return filteredIngredients.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.row_listview, parent, false);
        }

        TextView ingredientName = convertView.findViewById(R.id.ingredientName);
        Ingredient item = filteredIngredients.get(position);

        ingredientName.setText(item.getName());

        return convertView;
    }

    @Override
    public Filter getFilter() {
        if (filter == null)
            filter = new IngredientFilter();
        return filter;
    }

    private class IngredientFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint == null || constraint.length() == 0) {
                results.values = ingredients;
                results.count = ingredients.size();
            }
            else {
                ArrayList<Ingredient> itemList = new ArrayList<>();
                for (Ingredient item : ingredients) {
                    if (item.getName().toUpperCase().contains(constraint.toString().toUpperCase()))
                        itemList.add(item);
                }
                results.values = itemList;
                results.count = itemList.size();
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredIngredients =(ArrayList<Ingredient>) results.values;
            if (results.count > 0)
                notifyDataSetChanged();
            else
                notifyDataSetInvalidated();
        }
    }
}
