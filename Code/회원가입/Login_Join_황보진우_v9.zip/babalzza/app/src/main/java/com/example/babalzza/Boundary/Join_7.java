package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

public class Join_7 extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_7);
        Intent intent = getIntent();
    }

    public void activity_LogInScreen(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
    }

    // 이미 회원가입이 끝났으므로 더 이상 뒤로 갈 수 없다.
    public void onBackPressed() { }
}
