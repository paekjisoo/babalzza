package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;

import androidx.annotation.Nullable;

import com.example.babalzza.Entity.UserInformation;
import com.example.babalzza.R;

import java.util.ArrayList;

public class Join_6 extends Activity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료의 id가 담긴 리스트
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도
    private ArrayList<Boolean> preferencesCooking;// 조리법별 선호도
    private int difficulty; // 난이도별 선호도
    protected static UserInformation userInformation;
    private ToggleButton easy, normal, hard;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_6);

        Intent intent = getIntent();
        userInformation = new UserInformation(getApplicationContext());
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");
        preferencesCooking = (ArrayList<Boolean>) intent.getSerializableExtra("preferencesCooking");

        easy = findViewById(R.id.easy);
        normal = findViewById(R.id.normal);
        hard = findViewById(R.id.hard);
    }

    // 지금까지 저장해온 유저 선호 정보를 메뉴 점수에 일괄 적용하고 회원 정보를 저장한다.
    public void activity_join_6(View view) {
        String result = userInformation.insert(userid, nickname, password);
        if (result.equals("ok")) {
            Intent intent = new Intent(this, Join_Result.class);

            intent.putExtra("userid", userid);
            intent.putExtra("nickname", password);
            intent.putExtra("password", nickname);
            intent.putExtra("badIngredients", badIngredients);
            intent.putExtra("preferencesNationality", preferencesNationality);
            intent.putExtra("preferencesCategory", preferencesCategory);
            intent.putExtra("preferencesCooking", preferencesCooking);
            intent.putExtra("proficiency", difficulty);

            startActivity(intent);
        }
        else {
            Intent pop = new Intent(this, PopupMessage.class);
            pop.putExtra("message", result);
            startActivity(pop);
        }
    }

    // 이용자의 요리 숙련도를 -1, 0, 1의 Integer 값으로 저장하며, 하나가 check되면 나머지는 uncheck된다.
    public void updateProficiency(View view) {
        int id = view.getId();
        switch(id) {
            case R.id.easy:
                difficulty = -1;
                normal.setChecked(false);
                hard.setChecked(false);
                break;
            case R.id.normal:
                difficulty = 0;
                easy.setChecked(false);
                hard.setChecked(false);
                break;
            case R.id.hard:
                difficulty = 1;
                easy.setChecked(false);
                normal.setChecked(false);
        }
    }
}