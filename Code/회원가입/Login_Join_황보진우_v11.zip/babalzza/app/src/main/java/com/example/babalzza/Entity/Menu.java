package com.example.babalzza.Entity;

public class Menu {
    Integer menu_id;
    String name;
    String code;
    String country;
    String time;
    String level;
    String recipelink;

    public Menu() {
    }

    public Menu(Integer menu_id, String name, String code, String country, String time, String level, String recipelink) {
        this.menu_id = menu_id;
        this.name = name;
        this.code = code;
        this.country = country;
        this.time = time;
        this.level = level;
        this.recipelink = recipelink;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getRecipelink() {
        return recipelink;
    }

    public void setRecipelink(String recipelink) {
        this.recipelink = recipelink;
    }
}
