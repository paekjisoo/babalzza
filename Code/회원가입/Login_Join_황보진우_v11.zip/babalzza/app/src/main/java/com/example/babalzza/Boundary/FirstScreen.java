package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.R;

public class FirstScreen extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_screen);
        Intent intent = getIntent();
    }

    public void activity_LogInScreen(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
    }

    public void activity_JoinScreen(View view) {
        Intent intent = new Intent(this, Join_1.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        System.runFinalization();
        System.exit(0);
    }
}
