package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_5 extends AppCompatActivity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도
    private ArrayList<Boolean> preferencesCooking;// 조리법별 선호도

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_5);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");

        // 조리법별 선호도는 토글 스위치를 통해 불리언 값을 조정한다. 우선 최초 값을 모두 false로 맞춰준다.
        preferencesCooking = new ArrayList<>();
        for (int i = 0; i < 8; i++)
            preferencesCooking.add(false);
    }

    // 현재 인덱스 i에 저장된 값을 반전시켜준다.
    private void togle(int i) {
        if (preferencesCooking.get(i))
            preferencesCooking.set(i, false);
        else
            preferencesCooking.set(i, true);
        return;
    }

    // 버튼 클릭 이벤트
    public void updatePreference(View view) {
        int id = view.getId();
        switch(id) {
            case R.id.cooking01:
                togle(0);
                break;
            case R.id.cooking02:
                togle(1);
                break;
            case R.id.cooking03:
                togle(2);
                break;
            case R.id.cooking04:
                togle(3);
                break;
            case R.id.cooking05:
                togle(4);
                break;
            case R.id.cooking06:
                togle(5);
                break;
            case R.id.cooking07:
                togle(6);
                break;
            case R.id.cooking08:
                togle(7);
        }
    }

    public void next(View view) {
        Intent intent = new Intent(this, Join_6.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        intent.putExtra("badIngredients", badIngredients);
        intent.putExtra("preferencesNationality", preferencesNationality);
        intent.putExtra("preferencesCategory", preferencesCategory);
        intent.putExtra("preferencesCooking", preferencesCooking);
        intent.putExtra("badIngredients", badIngredients);Log.d("LOG_TEST", userid + ", " + nickname + ", " + password);
        startActivity(intent);
    }

    public void back(View view) { finish(); }

    @Override
    public void onBackPressed() { }
}
