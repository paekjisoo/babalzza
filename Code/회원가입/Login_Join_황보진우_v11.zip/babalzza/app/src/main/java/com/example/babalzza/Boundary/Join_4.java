package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_4 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도

    private Spinner list01, list02, list03, list04, list05, list06, list07, list08, list09, list10, list11,
            list12, list13, list14, list15, list16, list17, list18, list19, list20, list21, list22;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> preferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_4);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");

        preferencesCategory = new ArrayList<>();
        for (int i = 0; i < 22; i++)
            preferencesCategory.add(999);

        preferences = new ArrayList<>();
        preferences.add("보통이에요");
        preferences.add("너무 좋아요");
        preferences.add("좋아요");
        preferences.add("싫어요");
        preferences.add("너무 싫어요");
        adapter = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, preferences);

        list01 = findViewById(R.id.list01);
        list02 = findViewById(R.id.list02);
        list03 = findViewById(R.id.list03);
        list04 = findViewById(R.id.list04);
        list05 = findViewById(R.id.list05);
        list06 = findViewById(R.id.list06);
        list07 = findViewById(R.id.list07);
        list08 = findViewById(R.id.list08);
        list09 = findViewById(R.id.list09);
        list10 = findViewById(R.id.list10);
        list11 = findViewById(R.id.list11);
        list12 = findViewById(R.id.list12);
        list13 = findViewById(R.id.list13);
        list14 = findViewById(R.id.list14);
        list15 = findViewById(R.id.list15);
        list16 = findViewById(R.id.list16);
        list17 = findViewById(R.id.list17);
        list18 = findViewById(R.id.list18);
        list19 = findViewById(R.id.list19);
        list20 = findViewById(R.id.list20);
        list21 = findViewById(R.id.list21);
        list22 = findViewById(R.id.list22);

        list01.setAdapter(adapter);
        list02.setAdapter(adapter);
        list03.setAdapter(adapter);
        list04.setAdapter(adapter);
        list05.setAdapter(adapter);
        list06.setAdapter(adapter);
        list07.setAdapter(adapter);
        list08.setAdapter(adapter);
        list09.setAdapter(adapter);
        list10.setAdapter(adapter);
        list11.setAdapter(adapter);
        list12.setAdapter(adapter);
        list13.setAdapter(adapter);
        list14.setAdapter(adapter);
        list15.setAdapter(adapter);
        list16.setAdapter(adapter);
        list17.setAdapter(adapter);
        list18.setAdapter(adapter);
        list19.setAdapter(adapter);
        list20.setAdapter(adapter);
        list21.setAdapter(adapter);
        list22.setAdapter(adapter);

        list01.setOnItemSelectedListener(this);
        list02.setOnItemSelectedListener(this);
        list03.setOnItemSelectedListener(this);
        list04.setOnItemSelectedListener(this);
        list05.setOnItemSelectedListener(this);
        list06.setOnItemSelectedListener(this);
        list07.setOnItemSelectedListener(this);
        list08.setOnItemSelectedListener(this);
        list09.setOnItemSelectedListener(this);
        list10.setOnItemSelectedListener(this);
        list11.setOnItemSelectedListener(this);
        list12.setOnItemSelectedListener(this);
        list13.setOnItemSelectedListener(this);
        list14.setOnItemSelectedListener(this);
        list15.setOnItemSelectedListener(this);
        list16.setOnItemSelectedListener(this);
        list17.setOnItemSelectedListener(this);
        list18.setOnItemSelectedListener(this);
        list19.setOnItemSelectedListener(this);
        list20.setOnItemSelectedListener(this);
        list21.setOnItemSelectedListener(this);
        list22.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = (String) parent.getItemAtPosition(position);
        int index = 999;

        switch(parent.getId()) {
            case R.id.list01: index = 0; break;
            case R.id.list02: index = 1; break;
            case R.id.list03: index = 2; break;
            case R.id.list04: index = 3; break;
            case R.id.list05: index = 4; break;
            case R.id.list06: index = 5; break;
            case R.id.list07: index = 6; break;
            case R.id.list08: index = 7; break;
            case R.id.list09: index = 8; break;
            case R.id.list10: index = 9; break;
            case R.id.list11: index = 10; break;
            case R.id.list12: index = 11; break;
            case R.id.list13: index = 12; break;
            case R.id.list14: index = 13; break;
            case R.id.list15: index = 14; break;
            case R.id.list16: index = 15; break;
            case R.id.list17: index = 16; break;
            case R.id.list18: index = 17; break;
            case R.id.list19: index = 18; break;
            case R.id.list20: index = 19; break;
            case R.id.list21: index = 20; break;
            case R.id.list22: index = 21;
        }

        switch(item) {
            case "너무 좋아요":
                preferencesCategory.set(index, 2);
                break;
            case "좋아요":
                preferencesCategory.set(index, 1);
                break;
            case "보통이에요":
                preferencesCategory.set(index, 0);
                break;
            case "싫어요":
                preferencesCategory.set(index, -1);
                break;
            case "너무 싫어요":
                preferencesCategory.set(index, -2);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {}

    public void next(View view) {
        Intent intent = new Intent(this, Join_5.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", password);
        intent.putExtra("password", nickname);
        intent.putExtra("badIngredients", badIngredients);
        intent.putExtra("preferencesNationality", preferencesNationality);
        intent.putExtra("preferencesCategory", preferencesCategory);
        intent.putExtra("badIngredients", badIngredients);
        Log.d("LOG_TEST", userid + ", " + nickname + ", " + password);
        startActivity(intent);
    }

    public void back(View view) { finish(); }

    @Override
    public void onBackPressed() { }
}
