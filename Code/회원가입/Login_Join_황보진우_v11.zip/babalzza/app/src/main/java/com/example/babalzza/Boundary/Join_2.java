package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzza.Controller.RecommendController;
import com.example.babalzza.Resource.IngredientAdapter;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_2 extends AppCompatActivity {
    private String userId;
    private String nickname;
    private String password;
    private ListView ingredientList;
    private ListView selectedIngredientList;
    private EditText search;
    private IngredientAdapter adapter_1, adapter_2;
    private ArrayList<Ingredient> ingredients, selectedIgredients;
    private RecommendController controller;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료의 id가 담긴 리스트

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_2);

        // 이전 화면에서 회원 정보 전달
        Intent intent = getIntent();
        userId = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");

        // 식재료 검색창과 리스트 뷰 매칭
        search = findViewById(R.id.search);
        ingredientList = findViewById(R.id.ingredientList);
        selectedIngredientList = findViewById(R.id.selectedIngredientList);

        // 리스트 생성
        ingredients = new ArrayList<>();
        controller = new RecommendController(getApplicationContext());
        ingredients = controller.getAllingredients();
        selectedIgredients = new ArrayList<>();
        badIngredients = new ArrayList<>();

        // 어댑터 생성, 리스트뷰에 어댑터 매칭
        adapter_1 = new IngredientAdapter(ingredients);
        adapter_2 = new IngredientAdapter(selectedIgredients);
        ingredientList.setAdapter(adapter_1);
        selectedIngredientList.setAdapter(adapter_2);

        // 식재료 검색 기능
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                String filterText = s.toString();
                if (filterText.length() > 0)
                    ((IngredientAdapter)ingredientList.getAdapter()).getFilter().filter(filterText);
                else
                    ingredientList.clearTextFilter();
            }
        });

        // 식재료 선택 기능
        ingredientList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredient item = (Ingredient) parent.getItemAtPosition(position);
                int itemId = item.getIgd_id();

                if(selectedIgredients.contains(item)) {
                    Toast.makeText(getApplicationContext(), "이미 선택한 식재료입니다.", Toast.LENGTH_SHORT);
                    return;
                }
                else {
                    selectedIgredients.add(item);
                    badIngredients.add(itemId);
                    adapter_2.notifyDataSetChanged();
                    return;
                }
            }
        });

        // 선택한 식재료 삭제 기능
        selectedIngredientList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ingredient item = (Ingredient) parent.getItemAtPosition(position);
                int itemId = item.getIgd_id();

                selectedIgredients.remove(item);
                badIngredients.remove((Integer)itemId);
                adapter_2.notifyDataSetChanged();
            }
        });
    }

    // 회원정보 + 유저가 선택한 식재료들을 담은 리스트를 다음 화면으로 넘긴다.
    public void next(View view) {
        Intent intent = new Intent(this, Join_3.class);
        intent.putExtra("userid", userId);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        intent.putExtra("badIngredients", badIngredients);Log.d("LOG_TEST", userId + ", " + nickname + ", " + password);
        startActivity(intent);
    }

    public void back(View view) { finish(); }

    @Override
    public void onBackPressed() { }
}
