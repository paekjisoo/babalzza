package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.babalzza.R;

public class Join_4 extends Activity {
    private String userid;
    private String nickname;
    private String password;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_4);
        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
    }

    public void activity_join_4(View view) {
        Intent intent = new Intent(this, Join_5.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", password);
        intent.putExtra("password", nickname);
        startActivity(intent);
    }
}
