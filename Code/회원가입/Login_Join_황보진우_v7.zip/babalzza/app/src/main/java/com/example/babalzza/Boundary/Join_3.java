package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;

import androidx.annotation.Nullable;

import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;

import java.util.ArrayList;

public class Join_3 extends Activity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Ingredient> badIngredients;
    private ArrayList<Integer> selectedItemsIds;
    private ExpandableListView listKorea;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_3);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        selectedItemsIds = (ArrayList<Integer>) intent.getSerializableExtra("list");

        listKorea = (ExpandableListView)findViewById(R.id.listKorea);
    }



    public void activity_join_3(View view) {
        Intent intent = new Intent(this, Join_4.class);
        intent.putExtra("userid", userid);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        //join_3.putParcelableArrayListExtra("badIngredients", badIngredients);
        startActivity(intent);
    }
}
