package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import androidx.annotation.Nullable;

import com.example.babalzza.Resource.IngredientAdapter;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_2 extends Activity {
    private String userId;
    private String nickname;
    private String password;
    private ListView ingredientList;
    private EditText search;
    private Ingredient ingredient;
    private IngredientAdapter adapter;
    private ArrayList<Ingredient> badIngredients = new ArrayList<Ingredient>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_2);

        // 이전 화면에서 회원 정보 전달
        Intent intent = getIntent();
        userId = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");

        // 식재료 목록을 띄우기 위한 검색창과 리스트 뷰 매칭
        search = (EditText) findViewById(R.id.search);
        ingredientList = (ListView) findViewById(R.id.ingredientList);

        // DB 호출, 어댑터 생성, 리스트뷰에 어댑터 매칭
        ingredient = new Ingredient(getApplicationContext());
        adapter = new IngredientAdapter(getApplicationContext(), ingredient);
        ingredientList.setAdapter(adapter);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //searchIngredient(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                String filterText = s.toString();
                if (filterText.length() > 0)
                    ((IngredientAdapter)ingredientList.getAdapter()).getFilter().filter(filterText);
                    //ingredientList.setFilterText(filterText);
                else
                    ingredientList.clearTextFilter();
            }
        });
    }

    // 회원정보 + 유저가 선택한 식재료들을 담은 리스트를 다음 화면으로 넘긴다.
    public void next(View view) {
        SparseBooleanArray checkedItems = ingredientList.getCheckedItemPositions();
        ArrayList<Integer> checkedItemIds = new ArrayList<>();

        for(int i = 0; i <= checkedItems.size(); i++)
            if(checkedItems.get(i)) checkedItemIds.add(i);

        Intent intent = new Intent(this, test.class);
        intent.putExtra("userid", userId);
        intent.putExtra("nickname", nickname);
        intent.putExtra("password", password);
        intent.putExtra("list", checkedItemIds);
        startActivity(intent);
    }
}
