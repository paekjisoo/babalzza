package com.example.babalzza.Controller;


import android.content.Context;
import android.util.Log;

import com.example.babalzza.Entity.UserInformation;
import java.util.ArrayList;

public class UserInformationController {

    public static String insert(UserInformation userInformation, String userid, String nickname, String password) {
        String result = userInformation.insert(userid, nickname, password);
        return result;
    }

    public static UserInformation getUserInfo(Context context, UserInformation userInformation, String input, String type) {
        ArrayList<UserInformation> userInfos;
        userInfos = userInformation.getAllUsers(context);

        if(userInfos == null) {
            return null;
        }

        for (int i = 0; i < userInfos.size(); i++) {
            UserInformation temp = userInfos.get(i);
            switch(type) {
                case "USERID":
                    if (temp.getUserId().equals(input))
                        return userInfos.get(i);
                    break;
                case "NICKNAME":
                    if (temp.getNickname().equals(input))
                        return userInfos.get(i);
            }
        }
        return null;
    }
}
