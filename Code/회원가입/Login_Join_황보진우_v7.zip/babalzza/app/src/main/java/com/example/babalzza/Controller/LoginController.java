package com.example.babalzza.Controller;

import android.content.Context;

import com.example.babalzza.Entity.UserInformation;

public class LoginController{
    public static String login (Context context, UserInformation userInformation, String userId, String password) {
        try {
            //if (userInformation == null)
             //   return "DB Load Failed";

            UserInformation user = UserInformationController.getUserInfo(context, userInformation, userId, "USERID");

            if (user == null)
                return "로그인 실패";

            if (userId.equals(user.getUserId()) &&
                    password.equals(user.getPassword()))
                return "ok";
            else
                return "사용자 정보를 확인해주십시오.";
        }
        catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }
}
