package com.example.babalzza.Entity;

public class MenuScore {
    Integer user_id;
    Integer menu_id;
    float score;
    String recentassign;

    public MenuScore() {
    }

    public MenuScore(Integer user_id, Integer menu_id, float score, String recentassign) {
        this.user_id = user_id;
        this.menu_id = menu_id;
        this.score = score;
        this.recentassign = recentassign;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public String getRecentassign() {
        return recentassign;
    }

    public void setRecentassign(String recentassign) {
        this.recentassign = recentassign;
    }
}
