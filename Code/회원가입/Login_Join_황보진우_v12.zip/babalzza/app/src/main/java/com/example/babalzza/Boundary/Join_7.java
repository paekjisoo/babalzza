package com.example.babalzza.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.babalzza.Controller.RecommendController;
import com.example.babalzza.Entity.Menu;
import com.example.babalzza.Entity.MenuIngredient;
import com.example.babalzza.Entity.MenuScore;
import com.example.babalzza.Entity.User;
import com.example.babalzza.R;
import java.util.ArrayList;

public class Join_7 extends AppCompatActivity {
    private String userid;
    private String nickname;
    private String password;
    private ArrayList<Integer> badIngredients; // 못먹는 식재료
    private ArrayList<Integer> preferencesNationality; // 국가별 선호도
    private ArrayList<Integer> preferencesCategory; // 식재료별 선호도
    private ArrayList<Boolean> preferencesCooking; // 조리법별 선호도
    private int proficiency; // 숙련도

    private RecommendController controller;
    private User user;
    private MenuScore menuScore;
    private Menu menu;
    private ArrayList<MenuIngredient> menuIngredients;
    private ArrayList<Menu> menus;
    private ArrayList<MenuScore> menuScores;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join_7);

        Intent intent = getIntent();
        userid = intent.getStringExtra("userid");
        nickname = intent.getStringExtra("nickname");
        password = intent.getStringExtra("password");
        badIngredients = (ArrayList<Integer>) intent.getSerializableExtra("badIngredients");
        preferencesNationality = (ArrayList<Integer>) intent.getSerializableExtra("preferencesNationality");
        preferencesCategory = (ArrayList<Integer>) intent.getSerializableExtra("preferencesCategory");
        preferencesCooking = (ArrayList<Boolean>) intent.getSerializableExtra("preferencesCooking");
        proficiency = intent.getIntExtra("proficiency", 0);

        // 회원정보 DB에 입력
        user = new User();
        controller = new RecommendController(getApplicationContext());
        user.setName(nickname);
        user.setEmail(userid);
        user.setPassword(password);
        intent.putExtra("badIngredients", badIngredients);
        boolean result = controller.insertUser(user);

        // 회원 추가 실패 시 첫 화면으로 돌아간다.
        if (result) {
            menuScores = new ArrayList<>();
            menus = controller.getAllMenu();
            startScoreAdjustment();
        }
        else {
            Intent goBack = new Intent(this, FirstScreen.class);
            startActivity(goBack);
            Toast.makeText(getApplicationContext(), "회원가입 실패 : " + result, Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // 회원 선호 정보를 메뉴 점수에 반영한다.
    public void startScoreAdjustment() {
        // 메뉴 스코어 전체를 1로 초기화
        controller.clearMenuScore();
        for (int i = 0; i < menus.size(); i++) {
            menuScore = new MenuScore();
            menuScore.setMenu_id(i+1);
            menuScore.setUser_id(controller.UserByUserEmail(userid).getUser_id());
            menuScore.setScore(1);
            menuScore.setRecentassign("1900-01-01");
            menuScores.add(menuScore);
        }

        // 못먹는 식재료가 들어간 메뉴는 -999점 처리
        for (int i = 0; i < menuScores.size(); i++) {
            menuIngredients = new ArrayList<>();
            menuScore = menuScores.get(i);
            menu = menus.get(i);
            menuIngredients = controller.getAllMenuIngredientByMenuId(menu.getMenu_id());
            for (int j = 0; j < menuIngredients.size(); j++) {
                int igd1 = menuIngredients.get(j).getIgd_menu();
                for (int k = 0; k < badIngredients.size(); k++) {
                    int igd2 = badIngredients.get(k);
                    if (igd1 == igd2) {
                        menuScore.setScore(-999);
                        menuScores.set(i, menuScore);
                        break;
                    }
                }
            }
        }

        // 국가별 선호도 적용
        for (int i = 0; i < menuScores.size(); i++) {
            menu = menus.get(i);
            menuScore = menuScores.get(i);

            float currentScore = menuScore.getScore();
            float var = adjustmentByNationality(menu.getCountry());

            if (currentScore == -999) continue;

            menuScore.setScore(currentScore + var);
            menuScores.set(i, menuScore);
        }

        // 식재료 별 선호도 적용
        for (int i = 0; i < menuScores.size(); i++) {
            menu = menus.get(i);
            menuScore = menuScores.get(i);

            float currentScore = menuScore.getScore();
            if (currentScore == -999) continue;

            String first_code = "";
            String second_code = "";
            char[] mcode = menu.getCode().toCharArray();
            for (int j = 0; j < 2; j++)
                first_code += Character.toString(mcode[mcode.length - 4 + j]);
            for (int j = 0; j < 2; j++)
                second_code += Character.toString(mcode[mcode.length - 2 + j]);

            float var = 0;
            var += (adjustmentByCategory(first_code) * 0.1f);
            var += (adjustmentByCategory(first_code) * 0.1f);

            menuScore.setScore(currentScore + var);
            menuScores.set(i, menuScore);
        }

        // 조리법 별 선호도 적용
        for (int i = 0; i < menuScores.size(); i++) {
            menu = menus.get(i);
            menuScore = menuScores.get(i);

            float currentScore = menuScore.getScore();
            if (currentScore == -999) continue;

            String code = "";
            char[] mcode = menu.getCode().toCharArray();
            code += Character.toString(mcode[1]);

            float var = adjustmentByCooking(code);
            menuScore.setScore(currentScore + var);
            menuScores.set(i, menuScore);
        }

        // 난이도 별 선호도 적용
        switch(proficiency) {
            case -1:
                adjustmentByProficiency("쉬움");
                break;
            case 0:
                adjustmentByProficiency("보통");
                break;
            case 1:
                adjustmentByProficiency("어려움");
        }

        // 완성된 메뉴 스코어 DB에 저장
        for (int i = 0; i < menuScores.size(); i++) {
            controller.insertMenuScore(menuScores.get(i));
        }
    }

    public float adjustmentByNationality(String country) {
        float var = 0;

        switch (country) {
            case "한식":
                var += (preferencesNationality.get(0) * 0.1f);
                break;
            case "일식":
                var += (preferencesNationality.get(1) * 0.1f);
                break;
            case "중식":
                var += (preferencesNationality.get(2) * 0.1f);
                break;
            case "양식":
                var += (preferencesNationality.get(3) * 0.1f);
                break;
            case "기타":
                var += (preferencesNationality.get(4) * 0.1f);
        }

        return var;
    }

    public float adjustmentByCategory(String code) {
        float var = 0;

        switch(code) {
            case "00":
                break;
            case "11":
                var += (preferencesCategory.get(0) * 0.1f);
                break;
            case "12":
                var += (preferencesCategory.get(1) * 0.1f);
                break;
            case "13":
                var += (preferencesCategory.get(2) * 0.1f);
                break;
            case "14":
                var += (preferencesCategory.get(3) * 0.1f);
                break;
            case "15":
                var += (preferencesCategory.get(4) * 0.1f);
                break;
            case "21":
                var += (preferencesCategory.get(5) * 0.1f);
                break;
            case "22":
                var += (preferencesCategory.get(6) * 0.1f);
                break;
            case "23":
                var += (preferencesCategory.get(7) * 0.1f);
                break;
            case "24":
                var += (preferencesCategory.get(8) * 0.1f);
                break;
            case "25":
                var += (preferencesCategory.get(9) * 0.1f);
                break;
            case "26":
                var += (preferencesCategory.get(10) * 0.1f);
                break;
            case "31":
                var += (preferencesCategory.get(11) * 0.1f);
                break;
            case "32":
                var += (preferencesCategory.get(12) * 0.1f);
                break;
            case "33":
                var += (preferencesCategory.get(13) * 0.1f);
                break;
            case "34":
                var += (preferencesCategory.get(14) * 0.1f);
                break;
            case "35":
                var += (preferencesCategory.get(15) * 0.1f);
                break;
            case "41":
                var += (preferencesCategory.get(16) * 0.1f);
                break;
            case "42":
                var += (preferencesCategory.get(17) * 0.1f);
                break;
            case "43":
                var += (preferencesCategory.get(18) * 0.1f);
                break;
            case "51":
                var += (preferencesCategory.get(19) * 0.1f);
                break;
            case "52":
                var += (preferencesCategory.get(20) * 0.1f);
                break;
            case "53":
                var += (preferencesCategory.get(21) * 0.1f);
        }

        return var;
    }

    public float adjustmentByCooking(String code) {
        float var = 0;

        switch(code) {
            case "1":
                if(preferencesCooking.get(0)) var += 0.1f;
                break;
            case "2":
                if(preferencesCooking.get(1)) var += 0.1f;
                break;
            case "3":
                if(preferencesCooking.get(2)) var += 0.1f;
                break;
            case "4":
                if(preferencesCooking.get(3)) var += 0.1f;
                break;
            case "5":
                if(preferencesCooking.get(4)) var += 0.1f;
                break;
            case "6":
                if(preferencesCooking.get(5)) var += 0.1f;
                break;
            case "7":
                if(preferencesCooking.get(6)) var += 0.1f;
                break;
            case "8":
                if(preferencesCooking.get(7)) var += 0.1f;
        }

        return var;
    }

    public void adjustmentByProficiency(String user_level) {
        for (int i = 0; i < menuScores.size(); i++) {
            menu = menus.get(i);
            menuScore = menuScores.get(i);

            float currentScore = menuScore.getScore();
            if (currentScore == -999) continue;

            if (menu.getLevel().equals(user_level)) currentScore += 0.1f;

            menuScore.setScore(currentScore);
            menuScores.set(i, menuScore);
        }
    }

    // 로그인 화면으로 돌아간다.
    public void next(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
        finish();
    }

    public void onBackPressed() { }
}
