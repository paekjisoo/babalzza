package com.example.babalzza.Boundary;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.babalzza.Controller.RecommendController;
import com.example.babalzza.R;

public class FirstScreen extends AppCompatActivity {
    private RecommendController recommendController;
    private SharedPreferences csvload;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_screen);
        Intent intent = getIntent();

        recommendController = new RecommendController(getApplicationContext());

        csvload = this.getSharedPreferences("is_csv_loaded1703", Activity.MODE_PRIVATE);
        String result = csvload.getString("is_csv_loaded", "");
        if (result.equals("")) {
            recommendController.csvToDB_User(this);
            recommendController.csvToDB_Ingredient(this);
            recommendController.csvToDB_UserIngredient(this);
            recommendController.csvToDB_Menu(this);
            recommendController.csvToDB_MenuIngredient(this);
            recommendController.csvToDB_MenuScore(this);
            recommendController.csvToDB_MealSchedule(this);
            recommendController.csvToDB_ScheduleHistory(this);
            SharedPreferences.Editor editor = csvload.edit();
            editor.putString("is_csv_loaded", "done");
            editor.commit();
        }
    }

    public void activity_LogInScreen(View view) {
        Intent intent = new Intent(this, LogIn.class);
        startActivity(intent);
    }

    public void activity_JoinScreen(View view) {
        Intent intent = new Intent(this, Join_1.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        System.runFinalization();
        System.exit(0);
    }


}
