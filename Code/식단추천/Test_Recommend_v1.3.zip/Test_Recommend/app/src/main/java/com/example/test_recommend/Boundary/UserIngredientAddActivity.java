package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.R;

import java.util.ArrayList;

import static com.example.test_recommend.Controller.RecommendController.getScoreTotal;
import static com.example.test_recommend.Controller.RecommendController.setTotal;

public class UserIngredientAddActivity extends AppCompatActivity {

    Button btn;
    Button btn2;

    RecommendController recommendController;
    Integer user_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btn = (Button) findViewById(R.id.btn_addigd);
        btn2 = (Button) findViewById(R.id.btn_tomain);

        recommendController = new RecommendController(this);
        user_id = RecommendController.getUserID();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recommendController.csvToDB_UserIngredient(UserIngredientAddActivity.this);

                if (recommendController.UserIngredientByUserID(user_id).size()!=0){
                    // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
                    ArrayList<MenuScore> candidateMenuScoreList = recommendController.MenuScoreByUserID(user_id);
                    // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreRecentAssign = recommendController.getScoreRecentAssign(user_id);
                    // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreExpirationDate = recommendController.getScoreExpirationDate(user_id);
                    // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
                    ArrayList<Float> ScoreAmount = recommendController.getScoreAmount(user_id);
                    // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
                    ArrayList<Float> TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
                    candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);
                    // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
                    ArrayList<MenuScore> sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);

                    ArrayList<Integer> avoidList = recommendController.makeTodaySchedule(sortedCandidateMenuScoreList, user_id);
                    recommendController.makeSchedule(sortedCandidateMenuScoreList, user_id, avoidList);
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recommendController.MealScheduleByUserID(user_id).size()!=0) {
                    Intent gotomealmain = new Intent(UserIngredientAddActivity.this, Recommend_Main.class);
                    UserIngredientAddActivity.this.startActivity(gotomealmain);
                }else{
                    Intent dontgotomain = new Intent(UserIngredientAddActivity.this, FirstUsageActivity.class);
                    UserIngredientAddActivity.this.startActivity(dontgotomain);
                }
            }
        });
    }
}
