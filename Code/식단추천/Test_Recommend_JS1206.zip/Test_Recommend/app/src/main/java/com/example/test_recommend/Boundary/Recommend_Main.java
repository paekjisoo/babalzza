package com.example.test_recommend.Boundary;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.util.ArrayList;

import static com.example.test_recommend.Controller.RecommendController.getScoreAmount;
import static com.example.test_recommend.Controller.RecommendController.getScoreExpirationDate;
import static com.example.test_recommend.Controller.RecommendController.getScoreRecentAssign;
import static com.example.test_recommend.Controller.RecommendController.getScoreTotal;
import static com.example.test_recommend.Controller.RecommendController.setTotal;

public class Recommend_Main extends AppCompatActivity {

    Button btn_before;
    Button btn_after;
    Button btn_change;

    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    public Integer user_id;
    private RecommendController recommendController;
    ArrayList<UserIngredient> userIngredientArrayList;
    ArrayList<MenuScore> menuScoreArrayList;
    ArrayList<MenuScore> candidateMenuScoreList;

    ArrayList<ScheduleHistory> scheduleHistoryArrayList;
//    ArrayList<MealSchedule> mealScheduleArrayList;
    ArrayList<MenuIngredient> menuIngredientArrayList;
    ArrayList<Menu> menuList;

    ArrayList<Float> ScoreRecentAssign;
    ArrayList<Float> ScoreExpirationDate;
    ArrayList<Float> ScoreAmount;
    ArrayList<Float> TotalAdjustedScore;

    SharedPreferences csvload;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_main);

        btn_before=findViewById(R.id.btn_before);
        btn_after=findViewById(R.id.btn_after);
        btn_change=findViewById(R.id.btn_change);

        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);

        csvload = getSharedPreferences("is_csv_loaded6", Activity.MODE_PRIVATE);
//
//
//        // 각 button에 대한 클릭효과 정의
//        // 최초 가감된 MenuScore 불러와서 UserIngredient 참고해서 조정
//
        recommendController = new RecommendController(this);
//
        String result = csvload.getString("is_csv_loaded6", "");
        if (result==""){
            recommendController.csvToDB_User(this);
            recommendController.csvToDB_Ingredient(this);
            recommendController.csvToDB_UserIngredient(this);
            recommendController.csvToDB_Menu(this);
            recommendController.csvToDB_MenuIngredient(this);
            recommendController.csvToDB_MenuScore(this);
            SharedPreferences.Editor editor = csvload.edit();
            editor.putString("is_csv_loaded6", "done");
            editor.commit();
        }
        // user_id 기반으로 해서
        user_id = recommendController.getUserID();

        // 1. UserIngredient DB에서 user_id가 같은 목록을 userIngredientList로 뽑아온다
        userIngredientArrayList = recommendController.UserIngredientByUserID(user_id);
        // 2. MenuScore DB에서 user_id가 같은 목록을 menuscoreList로 뽑아온다
        menuScoreArrayList = recommendController.MenuScoreByUserID(user_id);
        // 3. ScheduleHistory DB에서 user_id가 같은 목록을 scheduleHistoryList로 뽑아온다
        scheduleHistoryArrayList = recommendController.ScheduleHistoryByUserID(user_id);
        // 4. MealSchedule DB에서 user_id가 같은 목록을 mealscheduleList로 뽑아온다
        // mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);

        // 5. MenuIngredient DB를 menuIngredientList로 가져온다
        // 6. Menu DB를 menuList로 가져온다.
        menuIngredientArrayList = recommendController.getAllMenuIngredients();
        menuList = recommendController.getAllMenu();

        // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.
        candidateMenuScoreList = menuScoreArrayList;

        // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
        ScoreRecentAssign = getScoreRecentAssign(menuScoreArrayList);
        // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
        ScoreExpirationDate = getScoreExpirationDate(userIngredientArrayList, menuIngredientArrayList);
        // 10. 파라미터를 menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.
        ScoreAmount = getScoreAmount(userIngredientArrayList, menuIngredientArrayList);
        // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
        TotalAdjustedScore = getScoreTotal(ScoreRecentAssign, ScoreExpirationDate, ScoreAmount);
        candidateMenuScoreList = setTotal(candidateMenuScoreList, TotalAdjustedScore);

//        for (int i=0; i<candidateMenuScoreList.size();i++){
//            System.out.println(menuList.get(i).getName()+"의 최종 점수는? "+candidateMenuScoreList.get(i).getScore());
//        }
        // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.
        ArrayList<MenuScore> sortedCandidateMenuScoreList = recommendController.sortCandidate(candidateMenuScoreList);

//        for (int i=0; i<sortedCandidateMenuScoreList.size();i++){
//            String menuNAME = recommendController.MenuNameByMenu_id(sortedCandidateMenuScoreList.get(i).getMenu_id());
//            System.out.println(i+" "+sortedCandidateMenuScoreList.get(i).getMenu_id()+" "+menuNAME+"입니다 ("+sortedCandidateMenuScoreList.get(i).getScore()+"점)");
//        }
        // 이 경우 SELECT * ORDER BY score 형태 쿼리문으로 접근
    }
}
