package com.example.menuschedule;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuSchedule05 extends AppCompatActivity {
    Button btn_before;
    Button btn_after;

    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menuschedule05);

        btn_before=findViewById(R.id.btn_before);
        btn_after=findViewById(R.id.btn_after);

        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);
    }
}
