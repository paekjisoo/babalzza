package com.example.menuschedule;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuSchedule04 extends AppCompatActivity {
    Button btn_recipe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menuschedule04);

        btn_recipe=findViewById(R.id.btn_recipe);
    }
}
