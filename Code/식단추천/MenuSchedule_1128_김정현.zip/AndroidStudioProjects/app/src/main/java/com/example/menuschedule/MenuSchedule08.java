package com.example.menuschedule;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MenuSchedule08 extends AppCompatActivity {
    ConstraintLayout layout_meal1;
    ConstraintLayout layout_meal2;
    ConstraintLayout layout_meal3;
    ConstraintLayout layout_meal4;
    ConstraintLayout layout_meal5;
    ConstraintLayout layout_meal6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menuschedule08);

        layout_meal1=findViewById(R.id.layout_meal1);
        layout_meal2=findViewById(R.id.layout_meal2);
        layout_meal3=findViewById(R.id.layout_meal3);
        layout_meal4=findViewById(R.id.layout_meal4);
        layout_meal5=findViewById(R.id.layout_meal5);
        layout_meal6=findViewById(R.id.layout_meal6);
    }
}
