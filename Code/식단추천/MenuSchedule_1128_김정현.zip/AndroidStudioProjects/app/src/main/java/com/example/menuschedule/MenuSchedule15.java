package com.example.menuschedule;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuSchedule15 extends AppCompatActivity {
    Button btn_before;
    Button btn_after;
    Button btn_recipe;
    Button btn_choice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menuschedule15);

        btn_before=findViewById(R.id.btn_before);
        btn_after=findViewById(R.id.btn_after);
        btn_recipe=findViewById(R.id.btn_recipe);
        btn_choice=findViewById(R.id.btn_choice);
    }
}
