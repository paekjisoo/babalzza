package com.example.test_recommend.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.test_recommend.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

public class Recommend_After extends AppCompatActivity {

    TextView txt_tomorrowdate;
    Button btn_main;
    Button btn_tomorrowchange;
    TextView txt_tomorrowbreakfast;
    TextView txt_tomorrowlunch;
    TextView txt_tomorrowdinner;

    Date tomorrow;
    Calendar cal;
    SimpleDateFormat format;
    String tomorrowdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_after);

        format = new SimpleDateFormat("yyyy-MM-dd");
        cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 1);
        tomorrow = cal.getTime();
        tomorrowdate = format.format(tomorrow);

        txt_tomorrowdate = (TextView) findViewById(R.id.txt_tomorrowdate);
        txt_tomorrowdate.setText(tomorrowdate);

        btn_main = (Button) findViewById(R.id.btn_main);
        btn_tomorrowchange = (Button) findViewById(R.id.btn_tomorrowchange);
        txt_tomorrowbreakfast = (TextView)findViewById(R.id.txt_tomorrowbreakfast);
        txt_tomorrowlunch = (TextView)findViewById(R.id.txt_tomorrowlunch);
        txt_tomorrowdinner = (TextView)findViewById(R.id.txt_tomorrowdinner);

        btn_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent changeintent = new Intent(Recommend_After.this, MainActivity.class);
                Recommend_After.this.startActivity(changeintent);
            }
        });

    }
}
