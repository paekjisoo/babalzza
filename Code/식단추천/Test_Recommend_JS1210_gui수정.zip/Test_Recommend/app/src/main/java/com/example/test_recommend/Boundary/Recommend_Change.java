package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import com.example.test_recommend.R;

public class Recommend_Change extends AppCompatActivity {
    Button btn_before;
    Button btn_after;
    Button btn_recipe;
    Button btn_choice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_change);

        btn_before=findViewById(R.id.btn_before);
        btn_after=findViewById(R.id.btn_after);
        btn_recipe=findViewById(R.id.btn_recipe);
        btn_choice=findViewById(R.id.btn_choice);


    }
}
