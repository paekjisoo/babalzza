package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Controller.RecommendEditController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.R;

import java.util.ArrayList;

public class Recommend_Edit extends AppCompatActivity {

    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    Button btn_move;
    Button btn_change;

    String mealsdate;
    Integer user_id;
    RecommendController recommendController;
    RecommendEditController recommendEditController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_edit);

        Intent intent = getIntent(); /*데이터 수신*/
        mealsdate = intent.getExtras().getString("date");
        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);
        user_id = recommendController.getUserID();


        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);

        ArrayList<MealSchedule> editableMealScheduleList = recommendEditController.getMealScheduleByDate(mealsdate, user_id);

        for (int i=0; i<editableMealScheduleList.size(); i++){
            String menuname = recommendController.MenuNameByMenu_id(editableMealScheduleList.get(i).getMenu_id());
            if (editableMealScheduleList.get(i).getMeal().equals("아침")) {
                txt_breakfast.setText(menuname);
            }
            else if (editableMealScheduleList.get(i).getMeal().equals("점심")){
                txt_lunch.setText(menuname);
            }
            else{
                txt_dinner.setText(menuname);
            }
        }

        txt_breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });

        txt_lunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });

        txt_dinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });
    }
}
