package com.example.test_recommend.Controller;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.test_recommend.Entity.MealSchedule;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class RecommendEditController extends SQLiteOpenHelper {

    private static final String dbName = "dbsetting1646.db";
    private static final String T_USER = "User";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    private static SQLiteDatabase db;

    RecommendController recommendController;
    private Integer user_id = RecommendController.getUserID();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    public RecommendEditController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_USER);
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // Meal Schedule 중에서 알고자 하는 Target Date에 배정된 Meal Schedule만 Arraylist로 받아옴
    public ArrayList<MealSchedule> getMealScheduleByDate(String date, Integer user_id) {
        String dateString = format.format(date);

        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> oneDayMealSchedule = new ArrayList<>(3);    // 하루 세끼만 저장

        for (int i=0; i<mealScheduleArrayList.size(); i++) {
            if (mealScheduleArrayList.get(i).getDate().equals(dateString)) {
                // meal schedule에 배정된 date와 찾고자 하는 target date와 같다면
                oneDayMealSchedule.add(mealScheduleArrayList.get(i));
            }
        }
        return oneDayMealSchedule;
    }

    public ArrayList<MealSchedule> getOptionList(Date date, Integer user_id) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1);
        String today = format.format(date);
        String tomorrow = format.format(cal.getTime());
        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> optionList = new ArrayList<>();

        for (int i=0; i<mealScheduleArrayList.size(); i++) {    // meal schedule 중 오늘이나 내일 배정된 것들이 있다면 추가
            if (mealScheduleArrayList.get(i).getDate().equals(today) ||
                    mealScheduleArrayList.get(i).getDate().equals(tomorrow))
                optionList.add(mealScheduleArrayList.get(i));
        }
        return optionList;
    }
}
