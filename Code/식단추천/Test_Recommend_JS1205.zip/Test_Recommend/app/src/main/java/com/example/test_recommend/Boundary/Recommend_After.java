package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.test_recommend.R;

public class Recommend_After extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_after);
    }
}
