package com.example.test_recommend.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Iterator;

public class RecommendController extends SQLiteOpenHelper {
    private static final String dbName = "igdtest4.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    private static final String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY not null, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null," +
            "FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
            "country text not null, time text not null, level text not null, recipelink text not null)";
    private static final String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
            "igdtype text not null , igdamount double not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id)," +
            " PRIMARY KEY (menu_id, igd_id))";
    private static final String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
            "score double not null , recentassign text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id))";
    private static final String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory (user_id INTEGER, menu_id INTEGER," +
            " meal text NOT NULL, result text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id, meal))";
    private static final String CREATE_MEALSCHEDULE = "CREATE TABLE IF NOT EXISTS MealSchedule (scd_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
            "user_id INTEGER not null, date DATE not null, meal text not null, done BLOB not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (user_id) REFERENCES User(user_id))";

    private static SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

    // 전체 메뉴 read
    public ArrayList<Menu> getAllMenu(){
        ArrayList<Menu> menuList = new ArrayList<Menu>();
        String query = "SELECT * FROM Menu";
        Cursor c = db.rawQuery(query, null);


        if (c!=null){
            while (c.moveToNext()){
                Menu onemenu = new Menu();
                onemenu.setMenu_id(c.getInt(0));
                onemenu.setName(c.getString(1));
                onemenu.setCode(c.getString(2));
                onemenu.setCountry(c.getString(3));
                onemenu.setTime(c.getInt(4));
                onemenu.setLevel(c.getString(5));
                onemenu.setRecipelink(c.getString(6));

                menuList.add(onemenu);
            }
        }
        return menuList;
    }


    // 유저 아이디 받아옴
    public static Integer getUserID() {
        // user_id를 기반으로 하기 때문에 param으로 받아오거나 글로벌 전역변수로 설정
        return 0;
    }

    public ArrayList<UserIngredient> UserIngredientByUserID(Integer user_id) {
        ArrayList<UserIngredient> userIngredientArrayList = new ArrayList<>();
        String query = "SELECT * FROM UserIngredient WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                UserIngredient oneuserigd = new UserIngredient();
                oneuserigd.setUserigd_id(c.getInt(0));
                oneuserigd.setUser_id(c.getInt(1));
                oneuserigd.setIgd_id(c.getInt(2));
                oneuserigd.setAmount(c.getInt(3));
                oneuserigd.setReservedamount(c.getInt(4));
                oneuserigd.setBuydate(c.getString(5));
                oneuserigd.setExpirationdate(c.getString(6));

                userIngredientArrayList.add(oneuserigd);
            }
        }
        db.execSQL(query);
        return userIngredientArrayList;
    }


    public ArrayList<MenuScore> MenuScoreByUserID(Integer user_id) {
        ArrayList<MenuScore> menuScoreArrayList = new ArrayList<>();
        String query = "SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                menuScoreArrayList.add(onemenuscore);
            }
        }
        db.execSQL(query);
        return menuScoreArrayList;
    }

    public ArrayList<ScheduleHistory> ScheduleHistoryByUserID(Integer user_id) {
        ArrayList<ScheduleHistory> scheduleHistoryArrayList = new ArrayList<>();
        String query = "SELECT * FROM ScheduleHistory WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                ScheduleHistory onescdhistory = new ScheduleHistory();
                onescdhistory.setUser_id(c.getInt(0));
                onescdhistory.setMeal(c.getString(1));
                onescdhistory.setMeal(c.getString(2));
                onescdhistory.setResult(c.getInt(3)>0);
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                scheduleHistoryArrayList.add(onescdhistory);
            }
        }
        db.execSQL(query);
        return scheduleHistoryArrayList;
    }

    public ArrayList<MealSchedule> MealScheduleByUserID(Integer user_id) {
        ArrayList<MealSchedule> mealScheduleArrayList = new ArrayList<>();
        String query = "SELECT * FROM MealSchedule WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MealSchedule onemealscd = new MealSchedule();
                onemealscd.setScd_id(c.getInt(0));
                onemealscd.setMenu_id(c.getInt(1));
                onemealscd.setUser_id(c.getInt(2));
                onemealscd.setDate(c.getString(3));
                onemealscd.setMeal(c.getString(4));
                onemealscd.setDone(c.getInt(5)>0);
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                mealScheduleArrayList.add(onemealscd);
            }
        }
        db.execSQL(query);
        return mealScheduleArrayList;
    }

    // csv 읽어오는 함수
    public void csvToDB_Menu(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menu);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Menu csvmenu = new Menu();
                    String[] list = line.split(",");

                    csvmenu.setMenu_id(Integer.parseInt(list[0]));
                    csvmenu.setName(list[1]);
                    csvmenu.setCode(list[2]);
                    csvmenu.setCountry(list[3]);
                    csvmenu.setTime(Integer.parseInt(list[4]));
                    csvmenu.setLevel(list[5]);
                    csvmenu.setRecipelink(list[6]);

                    insertMenu(csvmenu);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MenuIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient csvmenuigd = new MenuIngredient();
                    String[] list = line.split(",");

                    csvmenuigd.setMenu_id(Integer.parseInt(list[0]));
                    csvmenuigd.setIgd_menu(Integer.parseInt(list[1]));
                    csvmenuigd.setIgdamount(Integer.parseInt(list[2]));
                    csvmenuigd.setIgdtype(list[3]);

                    insertMenuIngredient(csvmenuigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    // data insertion
    public boolean insertMenu(Menu newmenu){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenu.getMenu_id());
        cv.put("name", newmenu.getName());
        cv.put("code", newmenu.getCode());
        cv.put("country", newmenu.getCountry());
        cv.put("time", newmenu.getTime());
        cv.put("level", newmenu.getLevel());
        cv.put("recipelink", newmenu.getRecipelink());
        return db.insert(T_MENU, null, cv)!= -1;
    }

    public boolean insertMenuIngredient(MenuIngredient newmenuigd){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenuigd.getMenu_id());
        cv.put("igd_id", newmenuigd.getIgd_menu());
        cv.put("type", newmenuigd.getIgdtype());
        cv.put("amount", newmenuigd.getIgdamount());
        return db.insert(T_MENUINGREDIENT, null, cv)!= -1;
    }

    public ArrayList<MenuScore> ScoreAdjustment(Integer user_id) {
        ArrayList<MenuScore> candidateMenuScoreList = new ArrayList<>();
        String query = "CREATE TABLE IF NOT EXISTS CandidateMenuScore AS SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                candidateMenuScoreList.add(onemenuscore);
            }
        }

        db.execSQL(query);
        return candidateMenuScoreList;
    }

    // 재추천 방지
    public static ArrayList<Double> getScoreRecentAssign(ArrayList<MenuScore> menuScoreArrayList) {
        ArrayList<Double> ScoreRecentAssign = new ArrayList<>();
        Iterator iterator = menuScoreArrayList.iterator();
        MenuScore menuScore = new MenuScore();
        double score = 0;
        int days = 0;

        while (iterator.hasNext()) {
            if (menuScore.getRecentassign().equals("1Day")) score = -10;
            else if (menuScore.getRecentassign().equals("3days")) score = -1;
            else if (menuScore.getRecentassign().equals("7days")) score = -0.1;
            else score = 0;

            ScoreRecentAssign.add(score);
            score = 0;
        }
        return ScoreRecentAssign;
    }

    // 유통기한 체크
    public static ArrayList<Double> getScoreExpirationDate(ArrayList<UserIngredient> userIngredientArrayList, ArrayList<MenuIngredient>) {
        ArrayList<Double> ScoreExpirationDate = new ArrayList<>();
        ArrayList<Integer> AdventageIgdID = new ArrayList<>();
        Iterator firstIterator = userIngredientArrayList.iterator();
        Iterator secondIterator = AdventageIgdID.iterator();

        int today_date = 20191204;
        int igd_id;
        // useringredient 중 오늘 날짜를 갖고와서 차이가 3일 이내인 식재료들에 대해 igd_id를 리스트로 가져옴
        while (firstIterator.hasNext()) {
            if (userIngredientArrayList.get(6).equals("3days")) {
                igd_id = userIngredientArrayList.get(2).getIgd_id();
                AdventageIgdID.add(igd_id);
            }
            else if (userIngredientArrayList.get(6).equals("지남")) {

            }
        }
        // 두 개의 차이가 음수면 그 아이디 받아와서
        // usering
        // for each menu - for each ingredient if menu has ingredient score + 0.1, if checked all user ingredients,
        // do same process for next menu until score adjustment for all menu is done

        return ScoreExpirationDate;
    }

    // 수량 체크
    public static ArrayList<Double> getScoreAmount(ArrayList<Double> ScoreAmount) {
        // create view *** as select * from menuingredient where igdtype = "주" -> 즉 메뉴 재료 중에서도 주재료만 뽑아옴

        return ScoreAmount;
    }

    // 이하 이행여부 체크 (지수)

    // 메뉴 이행 시 갱신 (보유 식재료 및 최근 배정된 날짜)
    public void userMealDid(Integer user_id, ArrayList<MenuIngredient> usedmenuIngredientList, MealSchedule mealSchedule){
        // *Boundary 단에서 어제 날짜인지 체크해서 이행 여부 체크할 수 있는지 판단해야함. OK
        // *이행 여부 체크하려는 식단의 날짜가 '어제'면, 팝업 띄워서 이행여부 체크하기. 이행했다고 응답 시,
        // *Boundary 단에서 더 쓴 Ingredient는 usedmenuIngredientList에 수정해서 보내줄 것!! userDidMeal 호출.

        // 1. UserIngredient DB에서 amount, reservedamount usedmenuIngredientList item의 amount 값 만큼 차감한다.
        // 2. MenuScore DB에서 해당 mealSchedule의 code와 동일한 메뉴들에 대해서 recentassign을 오늘 날짜로 갱신한다.
        // 3. user_id, mealSchedule.date, mealSchedule.meal을 파라미터로 넘겨주는 makeMealDone을 호출한다.
    }

    // 메뉴 미이행 시 갱신 (조리 실패 or 재료 없어서 --> 보유 식재료 갱신)
    public  void userMealDidnt(Integer user_id, ArrayList<MenuIngredient> usedmenuIngredientList, MealSchedule mealSchedule, int option){
        // *Boundary 단에서 이행 안했다고 응답 시, 안한 이유를 묻고 userMealDidnt 호출.
        // *단, '재료가 부족해서'(option==3)라고 이유 응답 시 real amount 묻는다 Ingredient는 usedmenuIngredientList에 수정해서 보내줄 것!!
        // *option==3 이면 UserIngredient의 amount 자체를 차감이 아니라 아예 덮어쓰기

        // 1. usedmenuIngredientList를 돌면서 amount만큼 UserIngredient DB의 amount, reservedamount 값을 갱신.
        // 2. user_id, mealSchedule.date, mealSchedule.meal을 파라미터로 넘겨주는 makeMealDone을 호출한다.
    }

    // 식단에 대해 done 했다고 표시, 어제 3끼 다 이행여부 체크 했으면 내일 3끼 추천하도록 makeSchedule 호출
    public void makeMealDone(Integer user_id, String date, String meal){

        // 1. MealSchedule DB에서 user_id가 같은 목록을 mealScheduleList로 뽑아온다.
        // 2. mealScheduleList에서 date, meal이 같은 item을 찾아서 done을 true로 바꾼다.

        // 3. mealScheduleList에서 date가 같은 item들을 찾아서 alldonecheckList로 뽑아온다.
        // 4. alldonecheckList를 돌면서 모두 true면, (하나라도 false면 break)
        // 5. user_id와 모레 날짜를 파라미터로 넘겨주는, makeSchedule 함수를 호출
    }

    // 3끼 추천하는 함수 (아침, 점심, 저녁). 메뉴 하나씩 추천 받는 menuRecommend 호출
    public void makeSchedule(Integer user_id, String date){
        // "아침"에 대해 menuRecommend를 호출해서 메뉴를 리턴받는다.
        // 리턴받은 메뉴에 대해 MealSchedule DB를 업데이트 한다.

        // "점심"에 대해 위와 똑같이 수행한다.
        // "저녁"에 대해 위와 똑같이 수행한다.

        // 3개의 MealSchedule을 리턴한다.
    }

    // 한끼 메뉴 추천하는 함수
    public Menu menuRecommend(Integer user_id, String meal){

//        // 최초 가감된 MenuScore 불러와서 UserIngredient 참고해서 조정
//        recommendController = new RecommendController(this);
//        // user_id 기반으로 해서
//        user_id = recommendController.getUserID();

        // 1. UserIngredient DB에서 user_id가 같은 목록을 userIngredientList로 뽑아온다
        // 2. MenuScore DB에서 user_id가 같은 목록을 menuscoreList로 뽑아온다
        // 3. ScheduleHistory DB에서 user_id가 같은 목록을 scheduleHistoryList로 뽑아온다
        // 4. MealSchedule DB에서 user_id가 같은 목록을 mealscheduleList로 뽑아온다

        // 5. MenuIngredient DB를 menuIngredientList로 가져온다
        // 6. Menu DB를 menuList로 가져온다.

        // 7. menuscoreList를 copy해서 candidateMenuScoreList를 만든다.

        // 8. 파라미터를 menuscoreList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "재추천방지 함수"를 호출하고 리턴받는다.
        // 9. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "유통기한 체크 함수"를 호출하고 리턴받는다.
        // 10. 파라미터를 menuList, menuIngredientList, userIngredientList로 가지고 리턴타입을 ArrayList<Float>로 가지는 "부족한 식재료 체크 함수"를 호출하고 리턴받는다.

        // 11. candidateMenuScoreList의 score에, 8, 9, 10의 리턴값으로 받은 score를 인덱스에 맞춰서 더한다.
        // 12. candidateMenuScoreList를 score를 기준으로 해서 내림차순으로 정렬한다.

        // 13. candidateMenuScoreList의 위에서부터 돌면서 scheduleHistoryList와 비교, meal에 배정될 수 있는지 체크한다.
        //     t면,
        // 14. mealscheduleList의 가장 마지막 메뉴와 메뉴코드를 비교해서 같은 메뉴는 아닌지, 국가/조리법/주재료1/주재료2 중 2개 이하로 겹치는지 체크한다.
        //     t면,
        // 15. 해당 메뉴의 menuIngredientList에 대해 UserIngredient DB의 reservedamount를 업데이트한다.
        // 16. 해당 메뉴를 리턴한다.

        return
    }

}
