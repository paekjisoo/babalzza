package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.Ingredient;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.example.test_recommend.Controller.RecommendController.getScoreAmount;
import static com.example.test_recommend.Controller.RecommendController.getScoreExpirationDate;
import static com.example.test_recommend.Controller.RecommendController.getScoreRecentAssign;

public class Recommend_Main extends AppCompatActivity {

    Button btn_before;
    Button btn_after;
    Button btn_change;

    TextView txt_todaydate;
    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    public Integer user_id;
    private RecommendController recommendController;
    ArrayList<MealSchedule> mealScheduleArrayList;
    ArrayList<Menu> menuList;

    Date today;
    Date tomorrow;
    Date yesterday;
    Calendar cal;
    SimpleDateFormat format;
    String todaydate;
    String tomorrowdate;
    String yesterdaydate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_main);

        format = new SimpleDateFormat("yyyy-MM-dd");
        today = new Date();
        cal = Calendar.getInstance();
        cal.setTime(today);
        cal.add(Calendar.DATE, 1);
        tomorrow = cal.getTime();
        cal.setTime(today);
        cal.add(Calendar.DATE, -1);
        yesterday = cal.getTime();

        todaydate = format.format(today);
        tomorrowdate = format.format(tomorrow);
        yesterdaydate = format.format(yesterday);

        btn_before=findViewById(R.id.btn_before);
        btn_before.setEnabled(false);
        btn_after=findViewById(R.id.btn_after);
        btn_after.setEnabled(false);
        btn_change=findViewById(R.id.btn_change);

        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);
        txt_todaydate = findViewById(R.id.txt_todaydate);
        txt_todaydate.setText(todaydate);

        boolean chk = false;
        for (MealSchedule s: mealScheduleArrayList){
            if (s.getDate()==yesterdaydate){
                chk = true;
                break;
            }
        }
        if (chk){
            btn_after.setEnabled(true);
        }

        btn_before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent beforeintent = new Intent(Recommend_Main.this, Recommend_Before.class);
                Recommend_Main.this.startActivity(beforeintent);
            }
        });

        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();
        mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        menuList = recommendController.getAllMenu();


        if (mealScheduleArrayList.get(mealScheduleArrayList.size()-1).getDate()==tomorrowdate){
            btn_after.setEnabled(true);
        }

        btn_after.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent afterintent = new Intent(Recommend_Main.this, Recommend_After.class);
                Recommend_Main.this.startActivity(afterintent);
            }
        });

        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent changeintent = new Intent(Recommend_Main.this, Recommend_Edit.class);
                Recommend_Main.this.startActivity(changeintent);
            }
        });

        final ArrayList<MealSchedule> todaymealList = new ArrayList<MealSchedule>();
        for(MealSchedule m : mealScheduleArrayList){
            if (m.getDate() == todaydate){
                if (m.getMeal() == "아침"){
                    todaymealList.add(0, m);
                }
                else if (m.getMeal() == "점심"){
                    todaymealList.add(1, m);
                }
                else if (m.getMeal() == "저녁"){
                    todaymealList.add(2, m);
                }
            }
        }

        txt_breakfast.setText(menuList.get(todaymealList.get(0).getMenu_id()).getName());
        txt_lunch.setText(menuList.get(todaymealList.get(1).getMenu_id()).getName());
        txt_breakfast.setText(menuList.get(todaymealList.get(2).getMenu_id()).getName());

        txt_breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent breakfastintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                breakfastintent.putExtra("menu_id", todaymealList.get(0).getMenu_id());
                Recommend_Main.this.startActivity(breakfastintent);
            }
        });

        txt_lunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lunchintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                lunchintent.putExtra("menu_id", todaymealList.get(1).getMenu_id());
                Recommend_Main.this.startActivity(lunchintent);
            }
        });

        txt_dinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dinnerintent = new Intent(Recommend_Main.this, Recommend_Detail.class);
                dinnerintent.putExtra("menu_id", todaymealList.get(2).getMenu_id());
                Recommend_Main.this.startActivity(dinnerintent);
            }
        });
    }
}
