package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Controller.RecommendEditController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Recommend_Edit extends AppCompatActivity {

    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    Button btn_move;
    Button btn_change;

    String mealsdate;
    String todaydate;
    String tommorrowdate;
    Calendar cal;
    Integer user_id;
    RecommendController recommendController;
    RecommendEditController recommendEditController;
    ArrayList<MealSchedule> editableMealScheduleList;

    SimpleDateFormat format;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_edit);

        Intent intent = getIntent(); /*데이터 수신*/
        mealsdate = intent.getExtras().getString("date");
        format = new SimpleDateFormat("yyyy-MM-dd");
        todaydate = format.format(new Date());
        cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 1);
        tommorrowdate = format.format(cal.getTime());

        Date date = new Date();
        Date tomorrow = new Date();
        try{
            date = format.parse(mealsdate);
            tomorrow = format.parse(tommorrowdate);
        }catch (ParseException e){

        }
        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);
        user_id = recommendController.getUserID();

        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);

        ArrayList<MealSchedule> mealScheduleList = new ArrayList<>();
        ArrayList<MealSchedule> todaymealScheduleList = recommendEditController.getMealScheduleByDate(date, user_id);
        ArrayList<MealSchedule> tomomealScheduleList = recommendEditController.getMealScheduleByDate(tomorrow, user_id);
        mealScheduleList.addAll(tomomealScheduleList);
        mealScheduleList.addAll(todaymealScheduleList);

        final ArrayList<Integer> scdidlist = new ArrayList<>();

        for (int i=0; i<mealScheduleList.size(); i++){
            String menuname = recommendController.MenuNameByMenu_id(mealScheduleList.get(i).getMenu_id());
            if (mealScheduleList.get(i).getMeal().equals("아침")) {
                txt_breakfast.setText(menuname);
                if(mealScheduleList.get(i).getDate().equals(mealsdate)) {
                    scdidlist.add(mealScheduleList.get(i).getScd_id());
                }
            }
            else if (mealScheduleList.get(i).getMeal().equals("점심")){
                txt_lunch.setText(menuname);
                if(mealScheduleList.get(i).getDate().equals(mealsdate)) {
                    scdidlist.add(mealScheduleList.get(i).getScd_id());
                }
            }
            else{
                txt_dinner.setText(menuname);
                if(mealScheduleList.get(i).getDate().equals(mealsdate)) {
                    scdidlist.add(mealScheduleList.get(i).getScd_id());
                }
            }
        }



        // 현재시간을 msec 으로 구한다.
        long now = System.currentTimeMillis();
        // 현재시간을 date 변수에 저장한다.
        Date datetimenow = new Date(now);
        // 시간을 나타냇 포맷을 정한다 ( yyyy/MM/dd 같은 형태로 변형 가능 )
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        // nowDate 변수에 값을 저장한다.
        String formatDate = format.format(datetimenow);
        String whichmealeditable = "";
        Integer nowhouri = Integer.parseInt(formatDate.substring(11,13));
        int nowhour = nowhouri.intValue();

//        System.out.println("참인가요 ?" +  (11<nowhour && nowhour<=15));
        if (nowhour<=11){
            whichmealeditable = "아침";
        } else if (11<nowhour && nowhour<=15){
            whichmealeditable = "점심";
        } else {
            whichmealeditable = "저녁";
        }
//        System.out.println("참인가요 ?" +  whichmealeditable);
        editableMealScheduleList = new ArrayList<>();

        if(whichmealeditable.equals("아침")){
            if (mealsdate.equals(todaydate)){
                editableMealScheduleList.add(mealScheduleList.get(0));
                editableMealScheduleList.add(mealScheduleList.get(1));
                editableMealScheduleList.add(mealScheduleList.get(2));
                editableMealScheduleList.add(mealScheduleList.get(3));
                editableMealScheduleList.add(mealScheduleList.get(4));
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
            else{
                editableMealScheduleList.add(mealScheduleList.get(3));
                editableMealScheduleList.add(mealScheduleList.get(4));
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
        }
        else if (whichmealeditable.equals("점심")){
            txt_breakfast.setEnabled(false);
            if (mealsdate.equals(todaydate)){
                editableMealScheduleList.add(mealScheduleList.get(1));
                editableMealScheduleList.add(mealScheduleList.get(2));
                editableMealScheduleList.add(mealScheduleList.get(3));
                editableMealScheduleList.add(mealScheduleList.get(4));
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
            else{
                editableMealScheduleList.add(mealScheduleList.get(4));
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
        }
        else if (whichmealeditable.equals("저녁")){
            txt_breakfast.setEnabled(false);
            txt_lunch.setEnabled(false);
            if (mealsdate.equals(todaydate)){
                editableMealScheduleList.add(mealScheduleList.get(2));
                editableMealScheduleList.add(mealScheduleList.get(3));
                editableMealScheduleList.add(mealScheduleList.get(4));
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
            else{
                editableMealScheduleList.add(mealScheduleList.get(5));
            }
        }

        txt_breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        mainintent.putParcelableArrayListExtra("editablemealschedule", editableMealScheduleList);
                        mainintent.putExtra("editingscdid", scdidlist.get(0));
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(scdidlist.get(0)));
                        Intent intent = new Intent(Recommend_Edit.this, Recommend_Change.class);
                        intent.putExtra("editingscdid", scdidlist.get(0));
                        Recommend_Edit.this.startActivity(intent);
                    }
                });
                builder.create().show();
            }
        });

        txt_lunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        mainintent.putExtra("editablemealschedule", editableMealScheduleList);
                        mainintent.putExtra("editingscdid", scdidlist.get(1));
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(scdidlist.get(1)));
                        Intent intent = new Intent(Recommend_Edit.this, Recommend_Change.class);
                        intent.putExtra("editingscdid", scdidlist.get(1));
                        Recommend_Edit.this.startActivity(intent);
                    }
                });
                builder.create().show();

            }
        });

        txt_dinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Edit.this);
                final LayoutInflater inflater_popup = getLayoutInflater();
                View popup = inflater_popup.inflate(R.layout.recommend_popuphowto, null);
                builder.setView(popup);

                btn_move = popup.findViewById(R.id.btn_move);
                btn_change = popup.findViewById(R.id.btn_change);

                btn_move.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent mainintent = new Intent(Recommend_Edit.this, Recommend_Move.class);
                        mainintent.putExtra("date", mealsdate);
                        mainintent.putExtra("editablemealschedule", editableMealScheduleList);
                        mainintent.putExtra("editingscdid", scdidlist.get(2));
                        Recommend_Edit.this.startActivity(mainintent);
                    }
                });

                btn_change.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(scdidlist.get(2)));
                        Intent intent = new Intent(Recommend_Edit.this, Recommend_Change.class);
                        intent.putExtra("editingscdid", scdidlist.get(2));
                        Recommend_Edit.this.startActivity(intent);
                    }
                });
                builder.create().show();

            }
        });



    }
}
