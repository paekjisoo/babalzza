package com.example.test_recommend.Boundary;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.Ingredient;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Recommend_Before extends AppCompatActivity {

    Button btn_main;
    TextView txt_yesterdaydate;
    TextView txt_prevbreakfast;
    TextView txt_prevlunch;
    TextView txt_prevdinner;

    Date yesterday;
    Calendar cal;
    SimpleDateFormat format;
    String yesterdaydate;

    public Integer user_id;
    private RecommendController recommendController;
    ArrayList<MealSchedule> mealScheduleArrayList;
    ArrayList<MenuIngredient> menuIngredientList;
    ArrayList<Menu> menuList;
    ArrayList<Ingredient> ingredientList;


    Button btn_yesdone;
    Button btn_nodone;
    AlertDialog.Builder builder;
    AlertDialog dialog;
    AlertDialog dialog2;
    AlertDialog dialog3;
    AlertDialog dialog4;
    Button btn_op1;
    Button btn_op2;
    Button btn_op3;
    Button btn_op4;

    MoreIngredientAdapter adapter;
    ListView lv_moreigd;
    Button btn_nomoreigd;
    Button btn_savemoreigd;
    ListView lv_lackigd;
    Button btn_saverealigd;


    ArrayList<Float> moreigdamountlist;
    ArrayList<MenuIngredient> needMenuIngredientList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_before);

        format = new SimpleDateFormat("yyyy-MM-dd");
        yesterday = new Date();
        cal = Calendar.getInstance();
        cal.setTime(yesterday);
        cal.add(Calendar.DATE, -1);
        yesterday = cal.getTime();

        yesterdaydate = format.format(yesterday);

        btn_main = (Button) findViewById(R.id.btn_main);
        txt_yesterdaydate = (TextView) findViewById(R.id.txt_yesterdaydate);
        txt_yesterdaydate.setText(yesterdaydate);
        txt_prevbreakfast = (TextView) findViewById(R.id.txt_prevbreakfast);
        txt_prevlunch = (TextView) findViewById(R.id.txt_prevlunch);
        txt_prevdinner = (TextView) findViewById(R.id.txt_prevdinner);

        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();
        mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        menuList = recommendController.getAllMenu();
        ingredientList = recommendController.getAllingredients();
        moreigdamountlist = new ArrayList<Float>();

        final ArrayList<MealSchedule> yesterdaymealList = new ArrayList<MealSchedule>();
        for (MealSchedule m : mealScheduleArrayList) {
            if (m.getDate().equals(yesterdaydate)) {
                if (m.getMeal().equals("아침")) {
                    yesterdaymealList.add(0, m);
                    txt_prevbreakfast.setText(menuList.get(m.getMenu_id()-1).getName());
                } else if (m.getMeal().equals("점심")) {
                    yesterdaymealList.add(1, m);
                    txt_prevlunch.setText(menuList.get(m.getMenu_id()-1).getName());
                } else {
                    yesterdaymealList.add(2, m);
                    txt_prevdinner.setText(menuList.get(m.getMenu_id()-1).getName());
                }
            }
        }

        for (MealSchedule y : yesterdaymealList){
            if (y.getDone().equals("TRUE")){
                if (y.getMeal().equals("아침")){
                    txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                    txt_prevbreakfast.setEnabled(false);
                }
                else if (y.getMeal().equals("점심")){
                    txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                    txt_prevlunch.setEnabled(false);
                }
                else {
                    txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                    txt_prevdinner.setEnabled(false);
                }
            }

        }

        btn_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainintent = new Intent(Recommend_Before.this, Recommend_Main.class);
                Recommend_Before.this.startActivity(mainintent);
            }
        });

        txt_prevbreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder = new AlertDialog.Builder(Recommend_Before.this);
                final LayoutInflater inflater_popupdone = getLayoutInflater();
                View popupdone = inflater_popupdone.inflate(R.layout.recommend_popupdone, null);
                builder.setView(popupdone);

                btn_yesdone = (Button) popupdone.findViewById(R.id.btn_yesdone);
                btn_nodone = (Button) popupdone.findViewById(R.id.btn_nodone);

                needMenuIngredientList = recommendController.getAllMenuIngredientByMenuId(yesterdaymealList.get(0).getMenu_id());
                for (int i=0; i<needMenuIngredientList.size(); i++){
                    moreigdamountlist.add(i, 0.0f);
                }

                btn_yesdone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        AlertDialog.Builder builder2 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupmoreigd = inflater_popupdone.inflate(R.layout.recommend_popupmoreigd, null);
                        builder2.setView(popupmoreigd);

                        lv_moreigd = (ListView) popupmoreigd.findViewById(R.id.lv_moreigd);
                        btn_savemoreigd = (Button) popupmoreigd.findViewById(R.id.btn_savemoreigd);
                        btn_nomoreigd = (Button) popupmoreigd.findViewById(R.id.btn_nomoreigd);

                        adapter = new MoreIngredientAdapter(needMenuIngredientList);
                        lv_moreigd.setAdapter(adapter);

                        btn_nomoreigd.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 0);
                                txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevbreakfast.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });

                        btn_savemoreigd.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 0);
                                txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevbreakfast.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });
                        dialog2 = builder2.create();
                        dialog2.show();
                    }
                });

                btn_nodone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        final AlertDialog.Builder builder3 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupreason = inflater_popupdone.inflate(R.layout.recommend_popupreason, null);
                        builder3.setView(popupreason);

                        btn_op1 = (Button) popupreason.findViewById(R.id.btn_op1); // 시간 없음
                        btn_op2 = (Button) popupreason.findViewById(R.id.btn_op2); // 조리 실패
                        btn_op3 = (Button) popupreason.findViewById(R.id.btn_op3); // 식재료 부족
                        btn_op4 = (Button) popupreason.findViewById(R.id.btn_op4); // 기타

                        btn_op1.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 1);
                                txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevbreakfast.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op2.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 2);
                                txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevbreakfast.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog3.dismiss();

                                AlertDialog.Builder builder4 = new AlertDialog.Builder(Recommend_Before.this);
                                View popuplackigd = inflater_popupdone.inflate(R.layout.recommend_popuplackigd, null);
                                builder4.setView(popuplackigd);

                                lv_lackigd = (ListView) popuplackigd.findViewById(R.id.lv_lackigd);
                                btn_saverealigd = (Button) popuplackigd.findViewById(R.id.btn_saverealigd);

                                adapter = new MoreIngredientAdapter(needMenuIngredientList);
                                lv_lackigd.setAdapter(adapter);

                                btn_saverealigd.setOnClickListener(new View.OnClickListener() {
                                    @RequiresApi(api = Build.VERSION_CODES.N)
                                    @Override
                                    public void onClick(View view) {
                                        recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 3);
                                        txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                        txt_prevbreakfast.setEnabled(false);
                                        dialog4.dismiss();
                                    }
                                });
                                dialog4 = builder4.create();
                                dialog4.show();
                            }
                        });

                        btn_op4.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(0), 4);
                                txt_prevbreakfast.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevbreakfast.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });
                        dialog3 = builder3.create();
                        dialog3.show();
                    }
                });
                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });

        // 이 아래 부분 복붙하기

        txt_prevlunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder = new AlertDialog.Builder(Recommend_Before.this);
                final LayoutInflater inflater_popupdone = getLayoutInflater();
                View popupdone = inflater_popupdone.inflate(R.layout.recommend_popupdone, null);
                builder.setView(popupdone);

                btn_yesdone = (Button) popupdone.findViewById(R.id.btn_yesdone);
                btn_nodone = (Button) popupdone.findViewById(R.id.btn_nodone);

                needMenuIngredientList = recommendController.getAllMenuIngredientByMenuId(yesterdaymealList.get(1).getMenu_id());
                for (int i=0; i<needMenuIngredientList.size(); i++){
                    moreigdamountlist.add(i, 0.0f);
                }

                btn_yesdone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        AlertDialog.Builder builder2 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupmoreigd = inflater_popupdone.inflate(R.layout.recommend_popupmoreigd, null);
                        builder2.setView(popupmoreigd);

                        lv_moreigd = (ListView) popupmoreigd.findViewById(R.id.lv_moreigd);
                        btn_savemoreigd = (Button) popupmoreigd.findViewById(R.id.btn_savemoreigd);
                        btn_nomoreigd = (Button) popupmoreigd.findViewById(R.id.btn_nomoreigd);

                        adapter = new MoreIngredientAdapter(needMenuIngredientList);
                        lv_moreigd.setAdapter(adapter);

                        btn_nomoreigd.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 0);
                                txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevlunch.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });

                        btn_savemoreigd.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 0);
                                txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevlunch.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });
                        dialog2 = builder2.create();
                        dialog2.show();
                    }
                });

                btn_nodone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        final AlertDialog.Builder builder3 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupreason = inflater_popupdone.inflate(R.layout.recommend_popupreason, null);
                        builder3.setView(popupreason);

                        btn_op1 = (Button) popupreason.findViewById(R.id.btn_op1); // 시간 없음
                        btn_op2 = (Button) popupreason.findViewById(R.id.btn_op2); // 조리 실패
                        btn_op3 = (Button) popupreason.findViewById(R.id.btn_op3); // 식재료 부족
                        btn_op4 = (Button) popupreason.findViewById(R.id.btn_op4); // 기타

                        btn_op1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 1);
                                txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevlunch.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 2);
                                txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevlunch.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog3.dismiss();

                                AlertDialog.Builder builder4 = new AlertDialog.Builder(Recommend_Before.this);
                                View popuplackigd = inflater_popupdone.inflate(R.layout.recommend_popuplackigd, null);
                                builder4.setView(popuplackigd);

                                lv_lackigd = (ListView) popuplackigd.findViewById(R.id.lv_lackigd);
                                btn_saverealigd = (Button) popuplackigd.findViewById(R.id.btn_saverealigd);

                                adapter = new MoreIngredientAdapter(needMenuIngredientList);
                                lv_lackigd.setAdapter(adapter);

                                btn_saverealigd.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        ArrayList<MenuIngredient> realNowMenuIngredientList = needMenuIngredientList;
                                        for (int i=0; i<moreigdamountlist.size(); i++){
                                            realNowMenuIngredientList.get(i).setIgdamount(adapter.getMoreAmount(i));
                                        }
                                        recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 3);
                                        txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                        txt_prevlunch.setEnabled(false);
                                        dialog4.dismiss();
                                    }
                                });
                                dialog4 = builder4.create();
                                dialog4.show();
                            }
                        });

                        btn_op4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(1), 4);
                                txt_prevlunch.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevlunch.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });
                        dialog3 = builder3.create();
                        dialog3.show();
                    }
                });
                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });

        txt_prevdinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder = new AlertDialog.Builder(Recommend_Before.this);
                final LayoutInflater inflater_popupdone = getLayoutInflater();
                View popupdone = inflater_popupdone.inflate(R.layout.recommend_popupdone, null);
                builder.setView(popupdone);

                btn_yesdone = (Button) popupdone.findViewById(R.id.btn_yesdone);
                btn_nodone = (Button) popupdone.findViewById(R.id.btn_nodone);

                needMenuIngredientList = recommendController.getAllMenuIngredientByMenuId(yesterdaymealList.get(2).getMenu_id());
                for (int i=0; i<needMenuIngredientList.size(); i++){
                    moreigdamountlist.add(i, 0.0f);
                }

                btn_yesdone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        AlertDialog.Builder builder2 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupmoreigd = inflater_popupdone.inflate(R.layout.recommend_popupmoreigd, null);
                        builder2.setView(popupmoreigd);

                        lv_moreigd = (ListView) popupmoreigd.findViewById(R.id.lv_moreigd);
                        btn_savemoreigd = (Button) popupmoreigd.findViewById(R.id.btn_savemoreigd);
                        btn_nomoreigd = (Button) popupmoreigd.findViewById(R.id.btn_nomoreigd);

                        adapter = new MoreIngredientAdapter(needMenuIngredientList);
                        lv_moreigd.setAdapter(adapter);

                        btn_nomoreigd.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 0);
                                txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevdinner.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });

                        btn_savemoreigd.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 0);
                                txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevdinner.setEnabled(false);
                                dialog2.dismiss();
                            }
                        });
                        dialog2 = builder2.create();
                        dialog2.show();
                    }
                });

                btn_nodone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                        final AlertDialog.Builder builder3 = new AlertDialog.Builder(Recommend_Before.this);
                        View popupreason = inflater_popupdone.inflate(R.layout.recommend_popupreason, null);
                        builder3.setView(popupreason);

                        btn_op1 = (Button) popupreason.findViewById(R.id.btn_op1); // 시간 없음
                        btn_op2 = (Button) popupreason.findViewById(R.id.btn_op2); // 조리 실패
                        btn_op3 = (Button) popupreason.findViewById(R.id.btn_op3); // 식재료 부족
                        btn_op4 = (Button) popupreason.findViewById(R.id.btn_op4); // 기타

                        btn_op1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 1);
                                txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevdinner.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 2);
                                txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevdinner.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });

                        btn_op3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog3.dismiss();

                                AlertDialog.Builder builder4 = new AlertDialog.Builder(Recommend_Before.this);
                                View popuplackigd = inflater_popupdone.inflate(R.layout.recommend_popuplackigd, null);
                                builder4.setView(popuplackigd);

                                lv_lackigd = (ListView) popuplackigd.findViewById(R.id.lv_lackigd);
                                btn_saverealigd = (Button) popuplackigd.findViewById(R.id.btn_saverealigd);

                                adapter = new MoreIngredientAdapter(needMenuIngredientList);
                                lv_lackigd.setAdapter(adapter);

                                btn_saverealigd.setOnClickListener(new View.OnClickListener() {
                                    @RequiresApi(api = Build.VERSION_CODES.N)
                                    @Override
                                    public void onClick(View view) {
                                        ArrayList<MenuIngredient> realNowMenuIngredientList = needMenuIngredientList;
                                        for (int i=0; i<moreigdamountlist.size(); i++){
                                            realNowMenuIngredientList.get(i).setIgdamount(adapter.getMoreAmount(i));
                                        }
                                        recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 3);
                                        txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                        txt_prevdinner.setEnabled(false);
                                        dialog4.dismiss();
                                    }
                                });
                                dialog4 = builder4.create();
                                dialog4.show();
                            }
                        });

                        btn_op4.setOnClickListener(new View.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void onClick(View view) {
                                recommendController.userMealDid(user_id, moreigdamountlist, yesterdaymealList.get(2), 4);
                                txt_prevdinner.setBackgroundColor(Color.parseColor("#adebad"));
                                txt_prevdinner.setEnabled(false);
                                dialog3.dismiss();
                            }
                        });
                        dialog3 = builder3.create();
                        dialog3.show();
                    }
                });
                dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
            }
        });

    }

    public class MoreIngredientAdapter extends BaseAdapter {
        private ArrayList<MenuIngredient> needmenuIngredientList;


        public MoreIngredientAdapter() {
        }

        public MoreIngredientAdapter(ArrayList<MenuIngredient> needmenuIngredientList) {
            this.needmenuIngredientList = needmenuIngredientList;
        }

        @Override
        public int getCount() {
            return needmenuIngredientList.size();
        }

        @Override
        public MenuIngredient getItem(int i) {
            return needmenuIngredientList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int position = i;
            final Context context = viewGroup.getContext();
            final ViewHolder holder;

            if (view == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.recommend_popupmoreigd_item, viewGroup, false);
                holder = new ViewHolder();
                holder.editText1 = (EditText)view.findViewById(R.id.moreigd_amount);
                view.setTag(holder);
            }else{
                holder = (ViewHolder)view.getTag();
            }
            holder.ref = position;

            TextView moreigd_name = (TextView) view.findViewById(R.id.moreigd_name);
            EditText moreigd_amount = (EditText) view.findViewById(R.id.moreigd_amount);

            Integer igd_id = needmenuIngredientList.get(i).getIgd_menu()-1;
            moreigd_name.setText(ingredientList.get(igd_id).getName());
            holder.editText1.setText(""+0);
            holder.editText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                    if (charSequence.equals("")||charSequence==null) {
//                        holder.editText1.setText("");
//                    }
                }

                @Override
                public void afterTextChanged(Editable editable) {
                    if (!editable.toString().isEmpty()) {
                        moreigdamountlist.set(holder.ref, Float.parseFloat(editable.toString()));
                    }
                }
            });

            return view;
        }

        public Float getMoreAmount(int position){
            return moreigdamountlist.get(position);
        }
    }

    public class ViewHolder{
        EditText editText1;
        int ref;
    }
}
