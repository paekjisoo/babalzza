package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Controller.RecommendEditController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Recommend_Move extends AppCompatActivity {

    ConstraintLayout layout_meal1;
    ConstraintLayout layout_meal2;
    ConstraintLayout layout_meal3;
    ConstraintLayout layout_meal4;
    ConstraintLayout layout_meal5;
    ConstraintLayout layout_meal6;

    TextView txt_date1;
    TextView txt_date2;
    TextView txt_date3;
    TextView txt_date4;
    TextView txt_date5;
    TextView txt_date6;

    TextView txt_menu1;
    TextView txt_menu2;
    TextView txt_menu3;
    TextView txt_menu4;
    TextView txt_menu5;
    TextView txt_menu6;

    RecommendController recommendController;
    RecommendEditController recommendEditController;
    ArrayList<MealSchedule> editablemealschedule;
    MealSchedule editingmealschedule;
    String mealsdate;
    String todaydate;
    String tommorrowdate;
    Calendar cal;
    Integer user_id;

    SimpleDateFormat format;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_move);

        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);
        user_id = recommendController.getUserID();
        format = new SimpleDateFormat("yyyy-MM-dd");


        Intent intent = getIntent(); /*데이터 수신*/
        mealsdate = intent.getStringExtra("date");
        editablemealschedule = intent.getParcelableArrayListExtra("editablemealschedule");
        Integer scd_id = intent.getIntExtra("editingscdid",1 );
//        System.out.println("scd_id 는 ? "+ scd_id);
        editingmealschedule = recommendController.getMealScheduleByScdId(scd_id);


        todaydate = format.format(new Date());
        cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 1);
        tommorrowdate = format.format(cal.getTime());

        Date date = new Date();
        try{
            date = format.parse(mealsdate);
        }catch (ParseException e){

        }

        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);
        ArrayList<MealSchedule> mealScheduleList = recommendEditController.getMealScheduleByDate(date, user_id);
        user_id = recommendController.getUserID();
        System.out.println("size는??????????????? "+mealScheduleList.size());
        for (int i=0; i<6-mealScheduleList.size(); i++) {
            mealScheduleList.add(null);
        }
        mealScheduleList.add(null);
        System.out.println("size는??????????????? "+mealScheduleList.size());

        layout_meal1=findViewById(R.id.layout_meal1);
        layout_meal2=findViewById(R.id.layout_meal2);
        layout_meal3=findViewById(R.id.layout_meal3);
        layout_meal4=findViewById(R.id.layout_meal4);
        layout_meal5=findViewById(R.id.layout_meal5);
        layout_meal6=findViewById(R.id.layout_meal6);

        txt_date1 = findViewById(R.id.txt_date1);
        if(mealScheduleList.get(0)==null){
            txt_date1.setText("");
        }else{
            txt_date1.setText(mealScheduleList.get(0).getDate()+" 아침");
        }
//        txt_date1.setText(mealScheduleList.get(0).getDate()+" 아침");
        txt_date2 = findViewById(R.id.txt_date2);
        if(mealScheduleList.get(1)==null){
            txt_date2.setText("");
        }else{
            txt_date2.setText(mealScheduleList.get(1).getDate()+" 점심");
        }
//        txt_date2.setText(mealScheduleList.get(1).getDate()+" 점심");
        txt_date3 = findViewById(R.id.txt_date3);
        if(mealScheduleList.get(2)==null){
            txt_date3.setText("");
        }else{
            txt_date3.setText(mealScheduleList.get(2).getDate()+" 저녁");
        }
//        txt_date3.setText(mealScheduleList.get(2).getDate()+" 저녁");
        txt_date4 = findViewById(R.id.txt_date4);
        if(mealScheduleList.get(3)==null){
            txt_date4.setText("");
        }else{
            txt_date4.setText(mealScheduleList.get(3).getDate()+" 아침");
        }
//        txt_date4.setText(mealScheduleList.get(3).getDate()+" 아침");
        txt_date5 = findViewById(R.id.txt_date5);
        if(mealScheduleList.get(4)==null){
            txt_date5.setText("");
        }else{
            txt_date5.setText(mealScheduleList.get(4).getDate()+" 점심");
        }
//        txt_date5.setText(mealScheduleList.get(4).getDate()+" 점심");
        txt_date6 = findViewById(R.id.txt_date6);
        if(mealScheduleList.get(5)==null){
            txt_date6.setText("");
        }else{
            txt_date6.setText(mealScheduleList.get(5).getDate()+" 저녁");
        }
//        txt_date6.setText(mealScheduleList.get(5).getDate()+" 저녁");

        txt_menu1 = findViewById(R.id.txt_menu1);
        if(mealScheduleList.get(0)==null){
            txt_menu1.setText("");
        }else{
            txt_menu1.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(0).getMenu_id()));
        }
//        txt_menu1.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(0).getMenu_id()));
        txt_menu2 = findViewById(R.id.txt_menu2);
        if(mealScheduleList.get(1)==null){
            txt_menu2.setText("");
        }else{
            txt_menu2.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(1).getMenu_id()));
        }
//        txt_menu2.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(1).getMenu_id()));
        txt_menu3 = findViewById(R.id.txt_menu3);
        if(mealScheduleList.get(2)==null){
            txt_menu3.setText("");
        }else{
            txt_menu3.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(2).getMenu_id()));
        }
//        txt_menu3.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(2).getMenu_id()));
        txt_menu4 = findViewById(R.id.txt_menu4);
        if(mealScheduleList.get(3)==null){
            txt_menu4.setText("");
        }else{
            txt_menu4.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(3).getMenu_id()));
        }
//        txt_menu4.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(3).getMenu_id()));
        txt_menu5 = findViewById(R.id.txt_menu5);
        if(mealScheduleList.get(4)==null){
            txt_menu5.setText("");
        }else{
            txt_menu5.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(4).getMenu_id()));
        }
//        txt_menu5.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(4).getMenu_id()));
        txt_menu6 = findViewById(R.id.txt_menu6);
        if(mealScheduleList.get(5)==null){
            txt_menu6.setText("");
        }else{
            txt_menu6.setText(recommendController.MenuNameByMenu_id(mealScheduleList.get(5).getMenu_id()));
        }

        recommendEditController = new RecommendEditController(this);
        final ArrayList<MealSchedule> editableMealSchedule = recommendEditController.getOptionList(date, user_id);

        // 수정 못하는 경우, 6개 레이아웃 중 그거는 안보이게
        switch (editablemealschedule.size()) {
            case 1:
                layout_meal1.setVisibility(View.INVISIBLE);
                layout_meal2.setVisibility(View.INVISIBLE);
                layout_meal3.setVisibility(View.INVISIBLE);
                layout_meal4.setVisibility(View.INVISIBLE);
                layout_meal5.setVisibility(View.INVISIBLE);
                break;
            case 2:
                layout_meal1.setVisibility(View.INVISIBLE);
                layout_meal2.setVisibility(View.INVISIBLE);
                layout_meal3.setVisibility(View.INVISIBLE);
                layout_meal4.setVisibility(View.INVISIBLE);
                break;
            case 3:
                layout_meal1.setVisibility(View.INVISIBLE);
                layout_meal2.setVisibility(View.INVISIBLE);
                layout_meal3.setVisibility(View.INVISIBLE);
                break;
            case 4:
                layout_meal1.setVisibility(View.INVISIBLE);
                layout_meal2.setVisibility(View.INVISIBLE);
                break;
            case 5:
                layout_meal1.setVisibility(View.INVISIBLE);
            default:
                break;
        }

        layout_meal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date1.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("아침")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date1.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date1.getText()+"(이/가) 아침에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(0).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(0).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(0).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(0).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }

            }
        });

        layout_meal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date2.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("점심")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                } else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date2.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date2.getText()+"(이/가) 점심에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(1).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(1).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(1).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(1).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }
            }
        });

        layout_meal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date3.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("저녁")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date3.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date3.getText()+"(이/가) 저녁에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(2).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(2).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(2).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(2).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }
            }
        });

        layout_meal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date4.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("아침")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                } else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date4.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date4.getText()+"(이/가) 아침에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(3).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(3).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(3).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(3).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }
            }
        });
        layout_meal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date5.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("점심")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                } else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date5.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date5.getText()+"(이/가) 점심에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(4).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(4).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(4).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(4).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }
            }
        });

        layout_meal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txt_date6.getText().equals(editingmealschedule.getDate()) && editableMealSchedule.equals("저녁")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    builder.setMessage("다른 식단을 선택해 주세요");
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.show();
                } else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                    String completemsg = txt_date6.getText()+"의 식단을 이동하였습니다.";
                    builder.setMessage(completemsg);
                    builder.setPositiveButton("확인",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                    String msg = "앞으로 "+txt_date6.getText()+"(이/가) 저녁에 배정되지 않도록 할까요?";
                                    builder.setMessage(msg);
                                    builder.setPositiveButton("예",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.setMealBanned(editingmealschedule);
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(5).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(5).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.setNegativeButton("아니오",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    recommendEditController.minusMenuScore(user_id, recommendController.getMealScheduleByScdId(editablemealschedule.get(5).getScd_id()));
                                                    recommendEditController.change(editingmealschedule, recommendController.getMealScheduleByScdId(editablemealschedule.get(5).getScd_id()));
                                                    dialog.dismiss();
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(Recommend_Move.this);
                                                    builder.setMessage("반영되었습니다.");
                                                    builder.setPositiveButton("확인",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    dialog.dismiss();
                                                                    Intent intent = new Intent(Recommend_Move.this, Recommend_Change.class);
                                                                    intent.putExtra("editingscdid", editingmealschedule.getScd_id());
                                                                    Recommend_Move.this.startActivity(intent);
                                                                }
                                                            });
                                                    builder.show();
                                                }
                                            });
                                    builder.show();
                                }
                            });
                    builder.show();
                }
            }
        });




    }
}
