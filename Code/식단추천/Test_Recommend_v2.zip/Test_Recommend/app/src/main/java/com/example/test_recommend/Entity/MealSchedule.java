package com.example.test_recommend.Entity;

import android.os.Parcel;
import android.os.Parcelable;

public class MealSchedule implements Parcelable {
    Integer scd_id;
    Integer menu_id;
    Integer user_id;
    String date;
    String meal;
    String done;

    public MealSchedule() {
    }

    public MealSchedule(Integer scd_id, Integer menu_id, Integer user_id, String date, String meal, String done) {
        this.scd_id = scd_id;
        this.menu_id = menu_id;
        this.user_id = user_id;
        this.date = date;
        this.meal = meal;
        this.done = done;
    }

    public MealSchedule(Parcel src) {
        scd_id = src.readInt();
        menu_id = src.readInt();
        user_id = src.readInt();
        date = src.readString();
        meal = src.readString();
        done = src.readString();
    }


    public static final Creator<MealSchedule> CREATOR = new Creator<MealSchedule>() {
        @Override
        public MealSchedule createFromParcel(Parcel in) {
            return new MealSchedule(in);
        }

        @Override
        public MealSchedule[] newArray(int size) {
            return new MealSchedule[size];
        }
    };

    public Integer getScd_id() {
        return scd_id;
    }

    public void setScd_id(Integer scd_id) {
        this.scd_id = scd_id;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMeal() {
        return meal;
    }

    public void setMeal(String meal) {
        this.meal = meal;
    }

    public String getDone() {
        return done;
    }

    public void setDone(String done) {
        this.done = done;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.scd_id);
        parcel.writeInt(this.menu_id);
        parcel.writeInt(this.user_id);
        parcel.writeString(this.date);
        parcel.writeString(this.meal);
        parcel.writeString(this.done);
    }
}
