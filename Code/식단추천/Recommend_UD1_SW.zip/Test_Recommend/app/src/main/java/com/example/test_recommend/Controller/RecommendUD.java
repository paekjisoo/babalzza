package com.example.test_recommend.Controller;

import android.database.sqlite.SQLiteDatabase;

import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuScore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class RecommendUD {

    RecommendController recommendController;
    private  Integer user_id = RecommendController.getUserID();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    // 수정 삭제 공통

    // Meal Schedule 중에서 알고자 하는 Target Date에 배정된 Meal Schedule만 Arraylist로 받아옴
    public ArrayList<MealSchedule> getMealScheduleByDate(Date date, Integer user_id) {
        String dateString = format.format(date);

        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> oneDayMealSchedule = new ArrayList<>(3);    // 하루 세끼만 저장

        for (int i=0; i<mealScheduleArrayList.size(); i++) {
            if (mealScheduleArrayList.get(i).getDate().equals(dateString)) {
                // meal schedule에 배정된 date와 찾고자 하는 target date와 같다면
                oneDayMealSchedule.add(mealScheduleArrayList.get(i));
            }
        }
        return oneDayMealSchedule;
    }

    public ArrayList<MealSchedule> getOptionList(Date date, Integer user_id) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 1);
        String today = format.format(date);
        String tomorrow = format.format(cal.getTime());
        ArrayList<MealSchedule> mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        ArrayList<MealSchedule> optionList = new ArrayList<>();

        for (int i=0; i<mealScheduleArrayList.size(); i++) {    // meal schedule 중 오늘이나 내일 배정된 것들이 있다면 추가
            if (mealScheduleArrayList.get(i).getDate().equals(today) ||
            mealScheduleArrayList.get(i).getDate().equals(tomorrow))
                optionList.add(mealScheduleArrayList.get(i));
        }

        return optionList;
    }

    // 해당 끼니에 더 배정 안되도록 schedulehistory 조정
    public void setMealBanned(MealSchedule mealSchedule) {
        String query = "UPDATE ScheduleHistory SET result = false WHERE user_id = " + mealSchedule.getUser_id() +
                " AND menu_id = " + mealSchedule.getMenu_id() + " AND meal = " + mealSchedule.getMeal();
        SQLiteDatabase db = recommendController.getWritableDatabase();

        db.execSQL(query);
    }

    // 바꾸고자 하는 식단 확정된 경우, 없애려는 자리에 해당 메뉴 업데이트 (수정, 삭제 공통) -> 옵션자리에 change 정보 넣음
    public void change(MealSchedule change, MealSchedule option) {
        SQLiteDatabase db = recommendController.getWritableDatabase();
        Integer scd_id = option.getScd_id();
        String query = "UPDATE MealSchedule SET scd_id = " + change.getScd_id() + ", menu_id = " + change.getMenu_id() + ", user_id = "
                        + change.getUser_id() + ", date = " + change.getDate() + ", meal = " + change.getMeal() + ", done = " + change.getDone() + "" +
                        ", WHERE scd_id = " + scd_id;

        // 실시간으로 바뀌어야 한다면
        option.setScd_id(change.getScd_id());
        option.setUser_id(change.getUser_id());
        option.setMenu_id(change.getMenu_id());
        option.setDate(change.getDate());
        option.setMeal(change.getMeal());
        option.setDone(change.getDone());
        db.execSQL(query);
    }

    // Delete Algorithm

    // 다른 가능한 메뉴 후보군들 받아오는 함수
    public ArrayList<Menu> getOtherCandidates(MealSchedule change, ArrayList<MenuScore> sortedCandidateList) {
        ArrayList<Integer> avoidList = new ArrayList<>();
        ArrayList<Menu> menuOptionList = new ArrayList<>(6);
        Menu menu;
        Integer menu_id;

        avoidList.add(change.getMenu_id()); // 처음 avoidList에는 바꾸고자 하는 메뉴의 아이디를 저장함

        for (int i=0; i<sortedCandidateList.size(); i++) {  // recommendcontroller getcandidate 참조
            MenuScore sortedCandidate = sortedCandidateList.get(i);
            Integer meal = 0;
            switch (change.getMeal()) {
                case "아침" : meal = 0; break;
                case "점심" : meal = 1; break;
                case "저녁" : meal = 2; break;
            }
            if (recommendController.isSuitable(sortedCandidate, meal, user_id) &&
            recommendController.isDissimilar(sortedCandidate, user_id)){
                menu_id = sortedCandidate.getMenu_id();

                if (menuOptionList.size() >= 6) break;  // 6개 다 들어갔으면 break

                if (recommendController.posinIntegerList(menu_id, avoidList) == -1) {
                    // avoid list에도 없으면
                    menu = recommendController.MenuByMenu_id(menu_id);
                    avoidList.add(menu_id);
                    menuOptionList.add(menu);
                    break;
                }
            }
        }
        return menuOptionList;
    }

    public void selectMenu(MealSchedule change, Menu selectedmenu) {    // changemeal과 거의 동일
        // 바꾸려는 mealschedule 위치에 menu 정보 넣음
        // 필요시 인덱스 인풋 추가 및 메뉴->어레이 리스트로 변경 가능
        SQLiteDatabase db = recommendController.getWritableDatabase();
        String query = "UPDATE MealSchedule SET result = false WHERE user_id = " + mealSchedule.getUser_id() + " +
                 " AND menu_id = \" + mealSchedule.getMenu_id() + \" AND meal = \" + mealSchedule.getMeal()";
        db.execSQL(query);
    }

}
