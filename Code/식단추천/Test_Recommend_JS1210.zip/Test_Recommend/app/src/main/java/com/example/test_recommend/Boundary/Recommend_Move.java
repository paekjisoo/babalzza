package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Controller.RecommendEditController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Recommend_Move extends AppCompatActivity {

    ConstraintLayout layout_meal1;
    ConstraintLayout layout_meal2;
    ConstraintLayout layout_meal3;
    ConstraintLayout layout_meal4;
    ConstraintLayout layout_meal5;
    ConstraintLayout layout_meal6;

    RecommendController recommendController;
    RecommendEditController recommendEditController;
    String mealsdate;
    Integer user_id;

    SimpleDateFormat format;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_move);

        Intent intent = getIntent(); /*데이터 수신*/
        mealsdate = intent.getExtras().getString("date");
        format = new SimpleDateFormat("yyyy-MM-dd");


        Date date = new Date();
        try{
            date = format.parse(mealsdate);
        }catch (ParseException e){

        }

        recommendController = new RecommendController(this);
        recommendEditController = new RecommendEditController(this);
        user_id = recommendController.getUserID();

        layout_meal1=findViewById(R.id.layout_meal1);
        layout_meal2=findViewById(R.id.layout_meal2);
        layout_meal3=findViewById(R.id.layout_meal3);
        layout_meal4=findViewById(R.id.layout_meal4);
        layout_meal5=findViewById(R.id.layout_meal5);
        layout_meal6=findViewById(R.id.layout_meal6);

        recommendEditController = new RecommendEditController(this);

        for (int i=0; i<6; i++){
            ArrayList<MealSchedule> editableMealSchedule = recommendEditController.getOptionList(date, user_id);

            // 현재시간을 msec 으로 구한다.
            long now = System.currentTimeMillis();
            // 현재시간을 date 변수에 저장한다.
            Date datetimenow = new Date(now);
            // 시간을 나타냇 포맷을 정한다 ( yyyy/MM/dd 같은 형태로 변형 가능 )
            SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            // nowDate 변수에 값을 저장한다.
            String formatDate = sdfNow.format(datetimenow);
            String nowhour
        }



    }
}
