package com.example.test_recommend.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.test_recommend.Entity.Ingredient;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;

public class RecommendController extends SQLiteOpenHelper {

    private static final String dbName = "igdtest6.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    private static final String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY not null, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null," +
            "FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
            "country text not null, time text not null, level text not null, recipelink text not null)";
    private static final String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
            "igdtype text not null , igdamount double not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id)," +
            " PRIMARY KEY (menu_id, igd_id))";
    private static final String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
            "score double not null , recentassign text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id))";
    private static final String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory (user_id INTEGER, menu_id INTEGER," +
            " meal text NOT NULL, result text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id, meal))";
    private static final String CREATE_MEALSCHEDULE = "CREATE TABLE IF NOT EXISTS MealSchedule (scd_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
            "user_id INTEGER not null, date DATE not null, meal text not null, done text not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (user_id) REFERENCES User(user_id))";

    private static SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

    // 유저 아이디 받아옴
    public static Integer getUserID() {
        // user_id를 기반으로 하기 때문에 param으로 받아오거나 글로벌 전역변수로 설정
        return 0;
    }



    public ArrayList<UserIngredient> UserIngredientByUserID(Integer user_id) {
        ArrayList<UserIngredient> userIngredientArrayList = new ArrayList<>();
        String query = "SELECT * FROM UserIngredient WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                UserIngredient oneuserigd = new UserIngredient();
                oneuserigd.setUserigd_id(c.getInt(0));
                oneuserigd.setUser_id(c.getInt(1));
                oneuserigd.setIgd_id(c.getInt(2));
                oneuserigd.setAmount(c.getInt(3));
                oneuserigd.setReservedamount(c.getInt(4));
                oneuserigd.setBuydate(c.getString(5));
                oneuserigd.setExpirationdate(c.getString(6));

                userIngredientArrayList.add(oneuserigd);
            }
        }
        db.execSQL(query);
        return userIngredientArrayList;
    }

    public ArrayList<MenuScore> MenuScoreByUserID(Integer user_id) {
        ArrayList<MenuScore> menuScoreArrayList = new ArrayList<>();
        String query = "SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                menuScoreArrayList.add(onemenuscore);
            }
        }
        db.execSQL(query);
        return menuScoreArrayList;
    }

    public ArrayList<ScheduleHistory> ScheduleHistoryByUserID(Integer user_id) {
        ArrayList<ScheduleHistory> scheduleHistoryArrayList = new ArrayList<>();
        String query = "SELECT * FROM ScheduleHistory WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                ScheduleHistory onescdhistory = new ScheduleHistory();
                onescdhistory.setUser_id(c.getInt(0));
                onescdhistory.setMeal(c.getString(1));
                onescdhistory.setMeal(c.getString(2));
                onescdhistory.setResult(Boolean.parseBoolean(c.getString(3)));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                scheduleHistoryArrayList.add(onescdhistory);
            }
        }
        db.execSQL(query);
        return scheduleHistoryArrayList;
    }

    public ArrayList<MealSchedule> MealScheduleByUserID(Integer user_id) {
        ArrayList<MealSchedule> mealScheduleArrayList = new ArrayList<>();
        String query = "SELECT * FROM MealSchedule WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MealSchedule onemealscd = new MealSchedule();
                onemealscd.setScd_id(c.getInt(0));
                onemealscd.setMenu_id(c.getInt(1));
                onemealscd.setUser_id(c.getInt(2));
                onemealscd.setDate(c.getString(3));
                onemealscd.setMeal(c.getString(4));
                onemealscd.setDone(Boolean.parseBoolean(c.getString(5)));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                mealScheduleArrayList.add(onemealscd);
            }
        }
        db.execSQL(query);
        return mealScheduleArrayList;
    }

        // 전체 메뉴 read
    public ArrayList<Menu> getAllMenu(){
        ArrayList<Menu> menuList = new ArrayList<Menu>();
        String query = "SELECT * FROM Menu";
        Cursor c = db.rawQuery(query, null);


        if (c!=null){
            while (c.moveToNext()){
                Menu onemenu = new Menu();
                onemenu.setMenu_id(c.getInt(0));
                onemenu.setName(c.getString(1));
                onemenu.setCode(c.getString(2));
                onemenu.setCountry(c.getString(3));
                onemenu.setTime(c.getInt(4));
                onemenu.setLevel(c.getString(5));
                onemenu.setRecipelink(c.getString(6));

                menuList.add(onemenu);
            }
        }
        return menuList;
    }

    // 전체 식재료 read
    public ArrayList<Ingredient> getAllingredients(){
        ArrayList<Ingredient> ingredientsList = new ArrayList<Ingredient>();
        String query = "SELECT * FROM Ingredient";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                Ingredient oneigd = new Ingredient();
                oneigd.setIgd_id(c.getInt(0));
                oneigd.setName(c.getString(1));
                oneigd.setImage("");
                oneigd.setCode(c.getString(3));
                oneigd.setMeasure(c.getString(4));
                oneigd.setRefrigeratedterm(c.getString(5));
                oneigd.setFreezedterm(c.getString(6));

                ingredientsList.add(oneigd);
            }
        }
        return ingredientsList;
    }

    public ArrayList<MenuIngredient> getNeedMenuIngredient(Integer menu_id){
        ArrayList<MenuIngredient> needMenuIngredientList = new ArrayList<MenuIngredient>();
        String query = "SELECT * FROM MenuIngredient WHERE menu_id=?";
        Cursor c = db.rawQuery(query, new String[]{menu_id.toString()});

        if (c!=null){
            while (c.moveToNext()){
                MenuIngredient onemenuigd = new MenuIngredient();
                onemenuigd.setMenu_id(c.getInt(0));
                onemenuigd.setIgd_menu(c.getInt(1));
                onemenuigd.setIgdtype(c.getString(2));
                onemenuigd.setIgdamount(c.getDouble(3));

                needMenuIngredientList.add(onemenuigd);
            }
        }
        return needMenuIngredientList;
    }

    // csv 읽어오는 함수
    public void csvToDB_Menu(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menu);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Menu csvmenu = new Menu();
                    String[] list = line.split(",");

                    csvmenu.setMenu_id(Integer.parseInt(list[0]));
                    csvmenu.setName(list[1]);
                    csvmenu.setCode(list[2]);
                    csvmenu.setCountry(list[3]);
                    String time = list[4].substring(0, list[4].length()-1);
                    csvmenu.setTime(Integer.parseInt(time));
                    csvmenu.setLevel(list[5]);
                    csvmenu.setRecipelink(list[6]);

                    insertMenu(csvmenu);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MenuIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient csvmenuigd = new MenuIngredient();
                    String[] list = line.split(",");

                    csvmenuigd.setMenu_id(Integer.parseInt(list[0]));
                    csvmenuigd.setIgd_menu(Integer.parseInt(list[1]));
                    csvmenuigd.setIgdtype(list[2]);
                    csvmenuigd.setIgdamount(Double.parseDouble(list[3]));

                    insertMenuIngredient(csvmenuigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_Ingredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.ingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Ingredient csvigd = new Ingredient();
                    String[] list = line.split(",");

                    csvigd.setIgd_id(Integer.parseInt(list[0]));
                    csvigd.setName(list[1]);
                    csvigd.setImage(list[2]);
                    csvigd.setCode(list[3]);
                    csvigd.setMeasure(list[4]);
                    csvigd.setRefrigeratedterm(list[5]);
                    csvigd.setFreezedterm(list[6]);

                    insertIngredient(csvigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_UserIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.useringredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    UserIngredient csvuserigd = new UserIngredient();
                    String[] list = line.split(",");

                    csvuserigd.setUserigd_id(Integer.parseInt(list[0]));
                    csvuserigd.setUser_id(Integer.parseInt(list[1]));
                    csvuserigd.setIgd_id(Integer.parseInt(list[2]));
                    csvuserigd.setAmount(Integer.parseInt(list[3]));
                    csvuserigd.setReservedamount(Integer.parseInt(list[4]));
                    csvuserigd.setBuydate(list[5]);
                    csvuserigd.setExpirationdate(list[6]);

                    insertUserIngredient(csvuserigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 전체 식재료 create
    public boolean insertIngredient(Ingredient newigd){
        ContentValues cv = new ContentValues();
        cv.put("igd_id", newigd.getIgd_id());
        cv.put("name", newigd.getName());
        cv.put("image", "");
        cv.put("code", newigd.getCode());
        cv.put("measure", newigd.getMeasure());
        cv.put("refrigeratedterm", newigd.getRefrigeratedterm());
        cv.put("freezedterm", newigd.getFreezedterm());
        return db.insert(T_INGREDIENT, null, cv)!= -1;
    }

    // 이용자 보유 식재료 create
    public boolean insertUserIngredient(UserIngredient newuserigd){
        ContentValues cv = new ContentValues();
        cv.put("userigd_id", newuserigd.getUserigd_id());
        cv.put("user_id", newuserigd.getUser_id());
        cv.put("igd_id", newuserigd.getIgd_id());
        cv.put("amount", newuserigd.getAmount());
        cv.put("reservedamount", newuserigd.getReservedamount());
        cv.put("buydate", newuserigd.getBuydate());
        cv.put("expirationdate", newuserigd.getExpirationdate());
        return db.insert(T_USERINGREDIENT, null, cv)!= -1;
    }


    // data insertion
    public boolean insertMenu(Menu newmenu){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenu.getMenu_id());
        cv.put("name", newmenu.getName());
        cv.put("code", newmenu.getCode());
        cv.put("country", newmenu.getCountry());
        cv.put("time", newmenu.getTime());
        cv.put("level", newmenu.getLevel());
        cv.put("recipelink", newmenu.getRecipelink());
        return db.insert(T_MENU, null, cv)!= -1;
    }

    public boolean insertMenuIngredient(MenuIngredient newmenuigd){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenuigd.getMenu_id());
        cv.put("igd_id", newmenuigd.getIgd_menu());
        cv.put("type", newmenuigd.getIgdtype());
        cv.put("amount", newmenuigd.getIgdamount());
        return db.insert(T_MENUINGREDIENT, null, cv)!= -1;
    }

    public ArrayList<MenuScore> ScoreAdjustment(Integer user_id) {
        ArrayList<MenuScore> candidateMenuScoreList = new ArrayList<>();
        String query = "CREATE TABLE IF NOT EXISTS CandidateMenuScore AS SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                candidateMenuScoreList.add(onemenuscore);
            }
        }
        db.execSQL(query);
        return candidateMenuScoreList;
    }

    // 각 배열 생성 메커니즘 //

    // 재추천 방지
    public static ArrayList<Float> getScoreRecentAssign(ArrayList<MenuScore> menuScoreArrayList) {
        ArrayList<Float> ScoreRecentAssign = new ArrayList<>();
        float score;
        long difference;
        String recentAssignedDate;

        // 1205 version by getDate using calendar
        Date currentTime = Calendar.getInstance().getTime();

        // current time version by yyyy-mm-dd
        // version 1205_1
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            recentAssignedDate = menuScoreArrayList.get(i).getRecentassign();
            difference = calculateDateDifference(recentAssignedDate, currentTime);

            if (difference <= 1) score = (float)-10;
            else if (difference <= 3) score = (float)-1;
            else if (difference <= 7) score = (float)-0.1;
            else score = (float)0;

            ScoreRecentAssign.add(score);

            /* 함수 호출 안할 경우
            try {
                Date date = format.parse(recentAssignedDate);
                difference = (date.getTime() - currentTime.getTime()) / (24*60*60*1000);

                if (difference <= 1) score = -10;
                else if (difference <= 3) score = -1;
                else if (difference <= 7) score = -0.1;
                else score = 0;

                ScoreRecentAssign.add(score);

            } catch (ParseException e) {
                e.printStackTrace();
            }
             */
        }
        return ScoreRecentAssign;
    }

    // 유통기한 체크
    public static ArrayList<Float> getScoreExpirationDate(ArrayList<UserIngredient> userIngredientArrayList, ArrayList<MenuIngredient> menuIngredientArrayList) {
        ArrayList<Float> ScoreExpirationDate = new ArrayList<>();
        ArrayList<Integer> AdventageIgdID = new ArrayList<>();
        int igd_id;
        int position;
        int defaultMenuID = 1;
        float score = (float)0;

        // 1205 version by getDate using calendar
        Date currentTime = Calendar.getInstance().getTime();
        String expirationdate;
        long difference;

        // useringredient 중 오늘 날짜를 갖고와서 차이가 3일 이내인 식재료들에 대해 igd_id를 AdvantageIgdID 리스트에다 넣어줌
        for (int i=0; i < userIngredientArrayList.size(); i++) {
            igd_id = userIngredientArrayList.get(i).getIgd_id();
            expirationdate = userIngredientArrayList.get(i).getExpirationdate();

            difference = calculateDateDifference(expirationdate, currentTime);

            if (difference <= 3 && difference >= 0) AdventageIgdID.add(igd_id);
            /* 함수 호출 안할 시
            try {
                Date date = format.parse(expirationdate);
                difference = (date.getTime() - currentTime.getTime()) / (24*60*60*1000);

                if (difference <= 3 && difference >= 0) AdventageIgdID.add(igd_id);

            } catch (ParseException e) {
                e.printStackTrace();
            }
             */
        }
        Collections.sort(AdventageIgdID);   // 오름차순으로 정렬 (ex. adventageigdid -> { 1, 3, 5, 11, 23, ... } 으로 정렬됨

        // 가점 및 (감정) 대상 useringredient들에 대해 각 메뉴가 해당 useringredient 개수 포함하는 만큼 0.1씩 가점
        for (int i=0; i<menuIngredientArrayList.size(); i++) {  // menuIngredient에 대해 한번씩 볼건데
            if (menuIngredientArrayList.get(i).getMenu_id() > defaultMenuID && i != menuIngredientArrayList.size()-1) {  // 현재 메뉴에 대한 참조 모두 끝낸 경우 점수 추가하고 reset
                ScoreExpirationDate.add(score); // 지금까지 축적된 스코어를 expirationdate 배열에 삽입
                score = (float)0;  // 이후 리셋
                defaultMenuID += 1;    // 참조 메뉴 번호를 올려줘서 다시 반복문 시작
            }
            position = posinIntegerList(menuIngredientArrayList.get(i).getIgd_menu(), AdventageIgdID);  // 우선 position은 해당 메뉴식재료의 아이디가 가점식재료 리스트의 어디에 있는지 파악함
            if (position != -1) score += 0.1;   // default position = -1 (존재하지 않을 경우)이며 존재하면 어떻게든 조정이 되기 때문에, 존재한다면 0.1 추가
        }
        ScoreExpirationDate.add(score); // 마지막 index 값에 대한 처리

        return ScoreExpirationDate;
    }

    // 수량 체크
    public static ArrayList<Float> getScoreAmount(ArrayList<UserIngredient> userIngredientArrayList, ArrayList<MenuIngredient> menuIngredientArrayList) {
        ArrayList<Float> ScoreAmount = new ArrayList<>();
        int defaultMenuID = 1;  // menu_id 1부터 시작
        int count;
        int position;
        float score = 0;
        boolean flag = true;

        for (int i=0; i<menuIngredientArrayList.size(); i++) {
            MenuIngredient menuIngredient = menuIngredientArrayList.get(i);

            // 1. 만약 하나의 메뉴에 대한 정보를 다 읽고 다음 메뉴로 넘어갈 때 or 마지막 인덱스일 때
            if (menuIngredient.getMenu_id() > defaultMenuID && i != menuIngredientArrayList.size()-1) {
                if (flag == false) {
                    score = 0;
                }
                else {  // 모든 flag = true, 즉 주재료들이 다 있고 양도 충분했다면 부재료 체크
                    count = checkServeIngredient(menuIngredientArrayList.get(i-1).getIgd_menu(), userIngredientArrayList);
                    if (count == 0) score = (float)0.2;
                    else {
                        if (count > 10) count = 10;
                        score = (float)(0.2 - (0.01*count));
                    }
                }
                ScoreAmount.add(score);

                flag = true;
                defaultMenuID += 1;
            }
            // 2. flag = false면 볼 필요도 없음
            if (flag == false) continue;
            // 3. 현재 메뉴 재료의 타입 조회
            if (menuIngredient.getIgdtype().equals("부")) continue;
            else {  // 4. 해당 메뉴의 igd_id가 useringredientlist에 포함되어 있는지 확인
                position = posinUserIgdList(menuIngredient.getIgd_menu(), userIngredientArrayList);
                if (position == -1) {
                    flag = false;
                    continue;
                }
                else {  // 5. 남은 양이 충분한지 확인
                    if (menuIngredient.getIgdamount() < (userIngredientArrayList.get(position).getAmount()
                            - userIngredientArrayList.get(position).getReservedamount())) flag = false;
                    else flag = true;
                    continue;
                }
            }
        }
        ScoreAmount.add(score);

        return ScoreAmount;
    }

    // 특정 재료의 아이디가 UserIngredient 안에 있는지 판별해서 있으면 위치를 return -> 위치 필요없음 boolean으로 바꿀 것
    public static int posinUserIgdList(Integer igd_id, ArrayList<UserIngredient> userIngredientArrayList) {
        int position = -1;

        for (int i=0; i<userIngredientArrayList.size(); i++) {
            if (userIngredientArrayList.get(i).getIgd_id().equals(igd_id)) position = i;
        }

        return position;
    }

    // 특정 재료의 아이디가 가점받을 식재료 리스트에 있으면 위치를 return -> 얘도 위치 필요없음 boolean으로 바꿀 것
    public static int posinIntegerList(Integer igd_id, ArrayList<Integer> integerArrayList) {
        int position = -1;

        for (int i=0; i<integerArrayList.size(); i++) {
            if (integerArrayList.get(i).equals(igd_id)) position = i;
        }

        return position;
    }

    public static int checkServeIngredient(Integer menu_id, ArrayList<UserIngredient> userIngredientArrayList) {
        ArrayList<MenuIngredient> menuIngredientArrayList = new ArrayList<>();
        MenuIngredient candidate = new MenuIngredient();
        int count = 0;
        int position;

        for (int i=0; i<menuIngredientArrayList.size(); i++) {
            if (menuIngredientArrayList.get(i).getMenu_id() == menu_id) {    // 메뉴식재료 DB에서 지금 찾고자하는 메뉴 아이디에 해당
                if (menuIngredientArrayList.get(i).getIgdtype().equals("부")) {  // 식재료가 부재료인 경우만
                    position = posinUserIgdList(candidate.getIgd_menu(), userIngredientArrayList);
                    if (position == -1) {   // 부재료가 없으면
                        count += 1;
                        continue;
                    }
                    else {  // 5. 남은 양이 충분한지 확인
                        if (candidate.getIgdamount() < (userIngredientArrayList.get(position).getAmount()
                                - userIngredientArrayList.get(position).getReservedamount())) count += 1;
                        else count = 0;
                        continue;
                    }
                }
            }
        }
        return count;
    }

    public static long calculateDateDifference(String inputDate, Date currentDate) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
        long difference = 0;

        try {
            Date date = format.parse(inputDate);
            difference = (currentDate.getTime() - date.getTime()) / (24*60*60*1000);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return difference;
    }

    public static ArrayList<Float> getScoreTotal(ArrayList<Float> ScoreRecentAssign, ArrayList<Float> ScoreExpirationDate, ArrayList<Float> ScoreAmount) {
        ArrayList<Float> TotalScore = new ArrayList<>();

        for (int i=0; i<ScoreAmount.size(); i++) {  // size는 recentassign이나 expirationdate나 scoreamount나 같기 때문에 뭐를 써도 상관없음
            TotalScore.set(i, ScoreRecentAssign.get(i) + ScoreExpirationDate.get(i) + ScoreAmount.get(i));
        }

        return TotalScore;
    }

    public static ArrayList<MenuScore> setTotal(ArrayList<MenuScore> candidateMenuList, ArrayList<Float> TotalScore) {
        for (int i=0; i<candidateMenuList.size(); i++) {
            candidateMenuList.get(i).setScore(candidateMenuList.get(i).getScore() + TotalScore.get(i));
        }
        return candidateMenuList;
    }
}
