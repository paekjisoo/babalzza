package com.example.test_recommend.Controller;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class RecommendController extends SQLiteOpenHelper {
    private static final String dbName = "igdtest4.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    String CREATE_INGREDIENT = "CREATE TABLE Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    String CREATE_USERINGREDIENT = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
    String CREATE_MEALSCHEDULE = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
    String CREATE_MENU = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
    String CREATE_MENUINGREDIENT = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
    String CREATE_MENUSCORE = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";
    String CREATE_SCHEDULEHISTORY = "CREATE TABLE UserIngredient (userigd_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null)";

    private SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

}
