package com.example.test_recommend.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import com.example.test_recommend.Entity.Ingredient;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.User;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import androidx.annotation.RequiresApi;

import static java.lang.System.in;

public class RecommendController extends SQLiteOpenHelper {
    private static final String dbName = "dbsetting1222.db";
    private static final String T_USER = "User";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    private static final String CREATE_USER = "CREATE TABLE IF NOT EXISTS User (user_id INTEGER PRIMARY KEY autoincrement, name text not null, email text not null, password text not null)";
    private static final String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY autoincrement, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY autoincrement, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount double not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null," +
            "FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY autoincrement, name text not null , code text not null, " +
            "country text not null, time text not null, level text not null, recipelink text not null)";
    private static final String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
            "igdtype text not null , igdamount double not null, " +
            "FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
            "score double not null , recentassign text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id))";
    private static final String CREATE_MEALSCHEDULE = "CREATE TABLE IF NOT EXISTS MealSchedule (scd_id INTEGER PRIMARY KEY autoincrement, menu_id INTEGER not null," +
            "user_id INTEGER not null, date text not null, meal text not null, done text not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (user_id) REFERENCES User(user_id))";
    private static final String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory (user_id INTEGER, menu_id INTEGER," +
            " meal text NOT NULL, result text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id, meal))";

    private static SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER);
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_USER);
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

    // 유저 아이디 받아옴
    public static Integer getUserID() {
        // user_id를 기반으로 하기 때문에 param으로 받아오거나 글로벌 전역변수로 설정
        return 1;
    }


    // ArrayList에서 모든 column get
    public ArrayList<Ingredient> getAllingredients(){
        ArrayList<Ingredient> ingredientsList = new ArrayList<Ingredient>();
        String query = "SELECT * FROM Ingredient";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                Ingredient oneigd = new Ingredient();
                oneigd.setIgd_id(c.getInt(0));
                oneigd.setName(c.getString(1));
                oneigd.setImage("");
                oneigd.setCode(c.getString(3));
                oneigd.setMeasure(c.getString(4));
                oneigd.setRefrigeratedterm(c.getString(5));
                oneigd.setFreezedterm(c.getString(6));

                ingredientsList.add(oneigd);
            }
        }
        return ingredientsList;
    }

    public ArrayList<Menu> getAllMenu(){
        ArrayList<Menu> menuList = new ArrayList<Menu>();
        String query = "SELECT * FROM Menu";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                Menu onemenu = new Menu();
                onemenu.setMenu_id(c.getInt(0));
                onemenu.setName(c.getString(1));
                onemenu.setCode(c.getString(2));
                onemenu.setCountry(c.getString(3));
                onemenu.setTime(c.getString(4));
                onemenu.setLevel(c.getString(5));
                onemenu.setRecipelink(c.getString(6));

                menuList.add(onemenu);
            }
        }
        return menuList;
    }

    public ArrayList<MenuIngredient> getAllMenuIngredients(){
        ArrayList<MenuIngredient> menuIngredientArrayList = new ArrayList<MenuIngredient>();
        String query = "SELECT * FROM MenuIngredient";
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuIngredient onemenuigd = new MenuIngredient();
                onemenuigd.setMenu_id(c.getInt(0));
                onemenuigd.setIgd_menu(c.getInt(1));
                onemenuigd.setIgdtype(c.getString(2));
                onemenuigd.setIgdamount(c.getFloat(3));

                menuIngredientArrayList.add(onemenuigd);
            }
        }
        return menuIngredientArrayList;
    }


    // 특정 id 기반으로 인풋 받아옴

    public ArrayList<UserIngredient> UserIngredientByUserID(Integer user_id) {
        ArrayList<UserIngredient> userIngredientArrayList = new ArrayList<>();
        String query = "SELECT * FROM UserIngredient WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                UserIngredient oneuserigd = new UserIngredient();
                oneuserigd.setUserigd_id(c.getInt(0));
                oneuserigd.setUser_id(c.getInt(1));
                oneuserigd.setIgd_id(c.getInt(2));
                oneuserigd.setAmount(c.getFloat(3));
                oneuserigd.setReservedamount(c.getInt(4));
                oneuserigd.setBuydate(c.getString(5));
                oneuserigd.setExpirationdate(c.getString(6));

                userIngredientArrayList.add(oneuserigd);
            }
        }
        return userIngredientArrayList;
    }

    public ArrayList<MenuScore> MenuScoreByUserID(Integer user_id) {
        ArrayList<MenuScore> menuScoreArrayList = new ArrayList<>();
        String query = "SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                menuScoreArrayList.add(onemenuscore);
            }
        }
        return menuScoreArrayList;
    }

    public ArrayList<ScheduleHistory> ScheduleHistoryByUserID(Integer user_id) {
        ArrayList<ScheduleHistory> scheduleHistoryArrayList = new ArrayList<>();
        String query = "SELECT * FROM ScheduleHistory WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                ScheduleHistory onescdhistory = new ScheduleHistory();
                onescdhistory.setUser_id(c.getInt(0));
                onescdhistory.setMenu_id(c.getInt(1));
                onescdhistory.setMeal(c.getString(2));
                onescdhistory.setResult(c.getString(3));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                scheduleHistoryArrayList.add(onescdhistory);
            }
        }
        c.close();
        return scheduleHistoryArrayList;
    }

    public ArrayList<MealSchedule> MealScheduleByUserID(Integer user_id) {
        ArrayList<MealSchedule> mealScheduleArrayList = new ArrayList<>();
        String query = "SELECT * FROM MealSchedule WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MealSchedule onemealscd = new MealSchedule();
                onemealscd.setScd_id(c.getInt(0));
                onemealscd.setMenu_id(c.getInt(1));
                onemealscd.setUser_id(c.getInt(2));
                onemealscd.setDate(c.getString(3));
                onemealscd.setMeal(c.getString(4));
                onemealscd.setDone(c.getString(5));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                mealScheduleArrayList.add(onemealscd);
            }
        }
        return mealScheduleArrayList;
    }

    public String MenuNameByMenu_id(Integer menu_id) {
        String menuName = "";
        String query = "SELECT name FROM Menu WHERE menu_id = " + menu_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){

                menuName = c.getString(0);
            }
        }
        return menuName;
    }

    public ArrayList<MenuIngredient> getAllMenuIngredientByMenuId(Integer menu_id){
        ArrayList<MenuIngredient> menuIngredientList = new ArrayList<MenuIngredient>();
        String query = "SELECT * FROM MenuIngredient WHERE menu_id = " + menu_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuIngredient onemenuIgd = new MenuIngredient();
                onemenuIgd.setMenu_id(c.getInt(0));
                onemenuIgd.setIgd_menu(c.getInt(1));
                onemenuIgd.setIgdtype(c.getString(2));
                onemenuIgd.setIgdamount(c.getFloat(3));
                menuIngredientList.add(onemenuIgd);
            }
        }
        return menuIngredientList;
    }

    public String getIngredientNameByIgdId(Integer igd_id) {
        String igdName = "";
        String query = "SELECT name FROM Ingredient WHERE igd_id = " + igd_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                igdName = c.getString(0);
            }
        }
        return igdName;
    }

    public String getIngredientMeasureByIgdId(Integer igd_id) {
        String igdMeasure = "";
        String query = "SELECT measure FROM Ingredient WHERE igd_id = " + igd_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                igdMeasure = c.getString(0);
            }
        }
        return igdMeasure;
    }


    // csv 읽어옴

    public void csvToDB_User(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.user);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    User csvuser = new User();
                    String[] list = line.split(",");

                    csvuser.setName(list[1]);
                    csvuser.setEmail(list[2]);
                    csvuser.setPassword(list[3]);

                    insertUser(csvuser);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_Menu(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menu);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Menu csvmenu = new Menu();
                    String[] list = line.split(",");

                    csvmenu.setName(list[1]);
                    csvmenu.setCode(list[2]);
                    csvmenu.setCountry(list[3]);
                    csvmenu.setTime(list[4]);
                    csvmenu.setLevel(list[5]);
                    csvmenu.setRecipelink(list[6]);

                    insertMenu(csvmenu);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MenuIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient csvmenuigd = new MenuIngredient();
                    String[] list = line.split(",");

                    csvmenuigd.setMenu_id(Integer.parseInt(list[0]));
                    csvmenuigd.setIgd_menu(Integer.parseInt(list[1]));
                    csvmenuigd.setIgdtype(list[2]);
                    csvmenuigd.setIgdamount(Float.parseFloat(list[3]));

                    insertMenuIngredient(csvmenuigd);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MenuScore(Context context){
        InputStream in = context.getResources().openRawResource(R.raw.menuscore);
        try {
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuScore csvmenuscore = new MenuScore();
                    String[] list = line.split(",");

                    csvmenuscore.setUser_id(Integer.parseInt(list[0]));
                    csvmenuscore.setMenu_id(Integer.parseInt(list[1]));
                    csvmenuscore.setScore(Float.parseFloat(list[2]));
                    csvmenuscore.setRecentassign(list[3]);

                    insertMenuScore(csvmenuscore);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MealSchedule(Context context){
        InputStream in = context.getResources().openRawResource(R.raw.mealschedule);
        try {
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MealSchedule mealSchedule = new MealSchedule();
                    String[] list = line.split(",");

                    mealSchedule.setMenu_id(Integer.parseInt(list[1]));
                    mealSchedule.setUser_id(Integer.parseInt(list[2]));
                    mealSchedule.setDate(list[3]);
                    mealSchedule.setMeal(list[4]);
                    mealSchedule.setDone(list[5]);

                    insertMealSchedule(mealSchedule);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_Ingredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.ingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Ingredient csvigd = new Ingredient();
                    String[] list = line.split(",");

                    csvigd.setName(list[1]);
                    csvigd.setImage(list[2]);
                    csvigd.setCode(list[3]);
                    csvigd.setMeasure(list[4]);
                    csvigd.setRefrigeratedterm(list[5]);
                    csvigd.setFreezedterm(list[6]);

                    insertIngredient(csvigd);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_UserIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.useringredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    UserIngredient csvuserigd = new UserIngredient();
                    String[] list = line.split(",");

                    csvuserigd.setUser_id(Integer.parseInt(list[1]));
                    csvuserigd.setIgd_id(Integer.parseInt(list[2]));
                    csvuserigd.setAmount(Float.parseFloat(list[3]));
                    csvuserigd.setReservedamount(Integer.parseInt(list[4]));
                    csvuserigd.setBuydate(list[5]);
                    csvuserigd.setExpirationdate(list[6]);

                    insertUserIngredient(csvuserigd);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_ScheduleHistory(Context context) {
        try {
            InputStream in = context.getResources().openRawResource(R.raw.schedulehistory);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    ScheduleHistory csvscdhist = new ScheduleHistory();
                    String[] list = line.split(",");

                    csvscdhist.setUser_id(Integer.parseInt(list[0]));
                    csvscdhist.setMenu_id(Integer.parseInt(list[1]));
                    csvscdhist.setMeal(list[2]);
                    csvscdhist.setResult(list[3]);

                    insertScheduleHistory(csvscdhist);
                }
            }
            in.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    // db insertion

    public boolean insertUser(User newuser){
        ContentValues cv = new ContentValues();
        cv.put("name", newuser.getName());
        cv.put("email", newuser.getEmail());
        cv.put("password", newuser.getPassword());
        return db.insert(T_USER, null, cv)!= -1;
    }

    public boolean insertIngredient(Ingredient newigd){
        ContentValues cv = new ContentValues();
        cv.put("name", newigd.getName());
        cv.put("image", "");
        cv.put("code", newigd.getCode());
        cv.put("measure", newigd.getMeasure());
        cv.put("refrigeratedterm", newigd.getRefrigeratedterm());
        cv.put("freezedterm", newigd.getFreezedterm());
        return db.insert(T_INGREDIENT, null, cv)!= -1;
    }

    public boolean insertUserIngredient(UserIngredient newuserigd){
        ContentValues cv = new ContentValues();
        cv.put("user_id", newuserigd.getUser_id());
        cv.put("igd_id", newuserigd.getIgd_id());
        cv.put("amount", newuserigd.getAmount());
        cv.put("reservedamount", newuserigd.getReservedamount());
        cv.put("buydate", newuserigd.getBuydate());
        cv.put("expirationdate", newuserigd.getExpirationdate());
        return db.insert(T_USERINGREDIENT, null, cv)!= -1;
    }

    public boolean insertMenu(Menu newmenu){
        ContentValues cv = new ContentValues();
        cv.put("name", newmenu.getName());
        cv.put("code", newmenu.getCode());
        cv.put("country", newmenu.getCountry());
        cv.put("time", newmenu.getTime());
        cv.put("level", newmenu.getLevel());
        cv.put("recipelink", newmenu.getRecipelink());
        return db.insert(T_MENU, null, cv)!= -1;
    }

    public boolean insertMenuIngredient(MenuIngredient newmenuigd){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenuigd.getMenu_id());
        cv.put("igd_id", newmenuigd.getIgd_menu());
        cv.put("igdtype", newmenuigd.getIgdtype());
        cv.put("igdamount", newmenuigd.getIgdamount());
        return db.insert(T_MENUINGREDIENT, null, cv)!= -1;
    }

    public boolean insertMenuScore(MenuScore menuScore){
        ContentValues cv = new ContentValues();
        cv.put("user_id", menuScore.getUser_id());
        cv.put("menu_id", menuScore.getMenu_id());
        cv.put("score", menuScore.getScore());
        cv.put("recentassign", menuScore.getRecentassign());
        return db.insert(T_MENUSCORE, null, cv)!= -1;
    }

    public boolean insertScheduleHistory(ScheduleHistory scheduleHistory) {
        ContentValues cv = new ContentValues();
        cv.put("user_id", scheduleHistory.getUser_id());
        cv.put("menu_id", scheduleHistory.getMenu_id());
        cv.put("meal", scheduleHistory.getMeal());
        cv.put("result", scheduleHistory.getResult());
        return db.insert(T_SCHEDULEHISTORY, null, cv)!= -1;
    }

    public boolean insertMealSchedule(MealSchedule mealSchedule) {
        ContentValues cv = new ContentValues();
        cv.put("menu_id", mealSchedule.getMenu_id());
        cv.put("user_id", mealSchedule.getUser_id());
        cv.put("date", mealSchedule.getDate());
        cv.put("meal", mealSchedule.getMeal());
        cv.put("done", mealSchedule.getDone());
        return db.insert(T_MEALSCHEDULE, null, cv)!= -1;
    }


    // 각 배열 생성 메커니즘 //

    // 재추천 방지
    public ArrayList<Float> getScoreRecentAssign(Integer user_id) {
        ArrayList<Float> ScoreRecentAssign = new ArrayList<>();
        ArrayList<MenuScore> menuScoreArrayList = MenuScoreByUserID(user_id);
        float score;
        long difference;
        String recentAssignedDate;

        // 1205 version by getDate using calendar
        Date currentTime = new Date();

        // current time version by yyyy-mm-dd
        // version 1205_1
        for (int i=0; i<menuScoreArrayList.size(); i++) {
            recentAssignedDate = menuScoreArrayList.get(i).getRecentassign();
            difference = calculateDateDifference(recentAssignedDate, currentTime);

            if (difference <= 1) score = -10;
            else if (difference <= 3) score = -1;
            else if (difference <= 7) score = (float)-0.1;
            else score = 0;

            ScoreRecentAssign.add(score);
        }
        return ScoreRecentAssign;
    }

    // 유통기한 체크
    public ArrayList<Float> getScoreExpirationDate(Integer user_id) {
        ArrayList<Float> ScoreExpirationDate = new ArrayList<>();
        ArrayList<UserIngredient> userIngredientArrayList = UserIngredientByUserID(user_id);
        ArrayList<MenuIngredient> menuIngredientArrayList = getAllMenuIngredients();
        ArrayList<Integer> AdventageIgdID = new ArrayList<>();
        int igd_id;
        int position;
        int defaultMenuID = 1;
        float score = 0;

        // 1205 version by getDate using calendar
        Date currentTime = Calendar.getInstance().getTime();
        String expirationdate;
        long difference;

        // useringredient 중 오늘 날짜를 갖고와서 차이가 3일 이내인 식재료들에 대해 igd_id를 AdvantageIgdID 리스트에다 넣어줌
        for (int i=0; i < userIngredientArrayList.size(); i++) {
            igd_id = userIngredientArrayList.get(i).getIgd_id();
            expirationdate = userIngredientArrayList.get(i).getExpirationdate();

            difference = calculateDateDifference(expirationdate, currentTime);

            if (difference <= 3 && difference >= 0) AdventageIgdID.add(igd_id);
        }
        Collections.sort(AdventageIgdID);   // 오름차순으로 정렬 (ex. adventageigdid -> { 1, 3, 5, 11, 23, ... } 으로 정렬됨

        // 가점 및 (감정) 대상 useringredient들에 대해 각 메뉴가 해당 useringredient 개수 포함하는 만큼 0.1씩 가점
        for (int i=0; i<menuIngredientArrayList.size(); i++) {  // menuIngredient에 대해 한번씩 볼건데
            if (menuIngredientArrayList.get(i).getMenu_id() > defaultMenuID && i != menuIngredientArrayList.size()-1) {  // 현재 메뉴에 대한 참조 모두 끝낸 경우 점수 추가하고 reset
                ScoreExpirationDate.add(score); // 지금까지 축적된 스코어를 expirationdate 배열에 삽입
                score = 0;  // 이후 리셋
                defaultMenuID += 1;    // 참조 메뉴 번호를 올려줘서 다시 반복문 시작
            }
            position = posinIntegerList(menuIngredientArrayList.get(i).getIgd_menu(), AdventageIgdID);  // 우선 position은 해당 메뉴식재료의 아이디가 가점식재료 리스트의 어디에 있는지 파악함
            if (position != -1) score += 0.1;   // default position = -1 (존재하지 않을 경우)이며 존재하면 어떻게든 조정이 되기 때문에, 존재한다면 0.1 추가
        }
        ScoreExpirationDate.add(score); // 마지막 index 값에 대한 처리

        return ScoreExpirationDate;
    }

    // 수량 체크
    public ArrayList<Float> getScoreAmount(Integer user_id) {
        ArrayList<Float> ScoreAmount = new ArrayList<>();
        ArrayList<UserIngredient> userIngredientArrayList = UserIngredientByUserID(user_id);
        ArrayList<MenuIngredient> menuIngredientArrayList = getAllMenuIngredients();
        int defaultMenuID = 1;  // menu_id 1부터 시작
        int count;
        int position;
        float score = 0;
        boolean flag = true;

        for (int i=0; i<menuIngredientArrayList.size(); i++) {
            MenuIngredient menuIngredient = menuIngredientArrayList.get(i);

            // 1. 만약 하나의 메뉴에 대한 정보를 다 읽고 다음 메뉴로 넘어갈 때 or 마지막 인덱스일 때
            if (menuIngredient.getMenu_id() > defaultMenuID && i != menuIngredientArrayList.size()-1) {
                if (flag == false) {
                    score = 0;
                }
                else {  // 모든 flag = true, 즉 주재료들이 다 있고 양도 충분했다면 부재료 체크
                    count = checkServeIngredient(menuIngredientArrayList.get(i-1).getIgd_menu(), userIngredientArrayList);
                    if (count == 0) score = (float)0.2;
                    else {
                        if (count > 10) count = 10;
                        score = (float)(0.2 - (0.01*count));
                    }
                }
                ScoreAmount.add(score);

                flag = true;
                defaultMenuID += 1;
            }
            // 2. flag = false면 볼 필요도 없음
            if (flag == false) continue;
            // 3. 현재 메뉴 재료의 타입 조회
            if (menuIngredient.getIgdtype().equals("부")) continue;
            else {  // 4. 해당 메뉴의 igd_id가 useringredientlist에 포함되어 있는지 확인
                position = posinUserIgdList(menuIngredient.getIgd_menu(), userIngredientArrayList);
                if (position == -1) {
                    flag = false;
                    continue;
                }
                else {  // 5. 남은 양이 충분한지 확인
                    if (menuIngredient.getIgdamount() < (userIngredientArrayList.get(position).getAmount()
                            - userIngredientArrayList.get(position).getReservedamount())) flag = false;
                    else flag = true;
                    continue;
                }
            }
        }
        ScoreAmount.add(score);
        return ScoreAmount;
    }

    // 특정 재료의 아이디가 UserIngredient 안에 있는지 판별해서 있으면 위치를 return
    public static int posinUserIgdList(Integer igd_id, ArrayList<UserIngredient> userIngredientArrayList) {
        int position = -1;

        for (int i=0; i<userIngredientArrayList.size(); i++) {
            if (userIngredientArrayList.get(i).getIgd_id().equals(igd_id)) position = i;
        }

        return position;
    }

    // 특정 재료의 아이디가 가점받을 식재료 리스트에 있으면 위치를 return
    public static int posinIntegerList(Integer igd_id, ArrayList<Integer> integerArrayList) {
        int position = -1;

        for (int i=0; i<integerArrayList.size(); i++) {
            if (integerArrayList.get(i).equals(igd_id)) position = i;
        }

        return position;
    }

    // 특정 부재료가 존재하고, 수량이 충분한지 확인
    public static int checkServeIngredient(Integer menu_id, ArrayList<UserIngredient> userIngredientArrayList) {
        ArrayList<MenuIngredient> menuIngredientArrayList = new ArrayList<>();
        MenuIngredient candidate = new MenuIngredient();
        int count = 0;
        int position;

        for (int i=0; i<menuIngredientArrayList.size(); i++) {
            if (menuIngredientArrayList.get(i).getMenu_id() == menu_id) {    // 메뉴식재료 DB에서 지금 찾고자하는 메뉴 아이디에 해당
                if (menuIngredientArrayList.get(i).getIgdtype().equals("부")) {  // 식재료가 부재료인 경우만
                    position = posinUserIgdList(candidate.getIgd_menu(), userIngredientArrayList);
                    if (position == -1) {   // 부재료가 없으면
                        count += 1;
                        continue;
                    }
                    else {  // 5. 남은 양이 충분한지 확인
                        if (candidate.getIgdamount() > (userIngredientArrayList.get(position).getAmount()
                                - userIngredientArrayList.get(position).getReservedamount())) count += 1;
                        else count = 0;
                        continue;
                    }
                }
            }
        }
        return count;
    }

    public static long calculateDateDifference(String inputDate, Date currentDate) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        long difference = 0;

        try {
            Date date = format.parse(inputDate);
            difference = (currentDate.getTime() - date.getTime()) / (24*60*60*1000);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return difference;
    }

    public static ArrayList<Float> getScoreTotal(ArrayList<Float> ScoreRecentAssign, ArrayList<Float> ScoreExpirationDate, ArrayList<Float> ScoreAmount) {
        ArrayList<Float> TotalScore = new ArrayList<Float>();
        for (int i=0 ; i<198; i++){
            TotalScore.add(i, 0.0f);
        }

        for (int i=0; i<198; i++) {  // size는 recentassign이나 expirationdate나 scoreamount나 같기 때문에 뭐를 써도 상관없음
            Float sum = ScoreRecentAssign.get(i) + ScoreExpirationDate.get(i) + ScoreAmount.get(i);
            TotalScore.set(i, sum);
        }
        return TotalScore;
    }

    public static ArrayList<MenuScore> setTotal(ArrayList<MenuScore> candidateMenuList, ArrayList<Float> TotalScore) {
        for (int i=0; i<candidateMenuList.size(); i++) {
            candidateMenuList.get(i).setScore(candidateMenuList.get(i).getScore() + TotalScore.get(i));
        }
        return candidateMenuList;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public ArrayList<MenuScore> sortCandidate (ArrayList<MenuScore> candidateScoreList){
        candidateScoreList.sort(new Comparator<MenuScore>() {
            @Override
            public int compare(MenuScore m1, MenuScore m2) {
                float score0 = m1.getScore();
                float score1 = m2.getScore();
                if (score0 == score1) return 0;
                else if (score1 > score0) return 1;
                else return -1;
            }
        });

        return candidateScoreList;
    }

    //// 배정 가능성 확인

    // 반복문을 통해 각각의 candidate menu에 대해 1. isSuitable 확인 함
    // isSuitable이 true면, 한번 더 isSimilar를 거침

    public void makeSchedule(ArrayList<MenuScore> menuScoreArrayList, Integer user_id) {
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String today = format.format(date);
        String meal = "";
        String done = "FALSE";
        Integer menu_id;
        ArrayList<Integer> avoidList = new ArrayList<>();
        MealSchedule mealSchedule = new MealSchedule();

        for (int i=0; i<3; i++) {
            menu_id = getCandidate(menuScoreArrayList, i, user_id, avoidList);

            switch (i) {
                case 0 :
                    meal = "아침";
                    break;
                case 1:
                    meal = "점심";
                    break;
                case 2 :
                    meal = "저녁";
                    break;
            }
            avoidList.add(menu_id);

            mealSchedule.setUser_id(user_id);
            mealSchedule.setMenu_id(menu_id);
            mealSchedule.setDate(today);
            mealSchedule.setMeal(meal);
            mealSchedule.setDone(done);

            System.out.println("result : " + user_id + "," + menu_id + "," + today + "," + meal + "," + done);
            insertMealSchedule(mealSchedule);
        }
    }
    // 1207 수정 -> arraylist input 받지 않고 그 자리에서 접근함
    public Integer getCandidate(ArrayList<MenuScore> menuScoreArrayList, Integer meal, Integer user_id, ArrayList<Integer> avoidList) {
        ArrayList<UserIngredient> userIngredientArrayList = UserIngredientByUserID(user_id);

        int menu_id = 0;

        for (int i=0; i<menuScoreArrayList.size(); i++) {
            MenuScore sortedCandidate = menuScoreArrayList.get(i);
            // user_id, menu_id, score, recentassign 갖고 있음 -> menu_id만 필요할듯

            if (isSuitable(sortedCandidate, meal, user_id) &&
                    isDissimilar(sortedCandidate, user_id)) { // 끼니에 적합, 코드 유사 X
                menu_id = sortedCandidate.getMenu_id();

                if (posinIntegerList(menu_id, avoidList) == -1) {
                    updateUserIgd(userIngredientArrayList, menu_id);
                    avoidList.add(menu_id);
                    break;
                }
            }
        }
        return menu_id;
    }

    public void updateUserIgd(ArrayList<UserIngredient> userIngredientArrayList, Integer menu_id) {
        ArrayList<MenuIngredient> menuIngredientArrayList = getAllMenuIngredients();

        // 조정해야 하는 재료들의 코드를 리스트로 받음
        for (int i=0; i<menuIngredientArrayList.size(); i++) {
            MenuIngredient menuIngredient = menuIngredientArrayList.get(i);
            if (menu_id == menuIngredient.getMenu_id()) {
                if (posinUserIgdList(menuIngredient.getIgd_menu(), userIngredientArrayList) != -1) { // 있으면
                    String query = "UPDATE UserIngredient SET reservedamount = reservedamount + "
                            + menuIngredient.getIgdamount() + " WHERE igd_id = " + menuIngredient.getIgd_menu();
                    db.execSQL(query);
                }
            }
        }
    }

    // 13. candidateMenuScoreL를 scheduleHistoryList와 비교, meal에 배정될 수 있는지 체크한다.
    public boolean isSuitable(MenuScore sortedCandidateMenuScore, Integer meal, Integer user_id) {
        ArrayList<ScheduleHistory> scheduleHistoryArrayList = ScheduleHistoryByUserID(user_id);
        Integer candidateMenuID = sortedCandidateMenuScore.getMenu_id();
        String possibility = "";

        // 필요한 스케줄 찾아와
        for (int i = 0; i < scheduleHistoryArrayList.size(); i++) {
            // 후보리스트 가장 상단의 메뉴 아이디와 동일한 메뉴 아이디를 갖는 스케줄 가져옴
//            Log.d("TRONZE", "scheduleHistoryArrayList.get(i).getMenuId : " + scheduleHistoryArrayList.get(i).getMenu_id());
//            Log.d("TRONZE", "candidateMenuID : " + candidateMenuID);

            if (scheduleHistoryArrayList.get(i).getMenu_id() == candidateMenuID && i % 3 == meal % 3) {
                // 아이디 찾았고 찾아야 하는 식단에 대한 포지션을 찾았으면 저장해
                possibility = scheduleHistoryArrayList.get(i).getResult();
//                Log.d("TRONZE", "i % 3 : " + i % 3);
//                Log.d("TRONZE", "meal % 3 : " + meal % 3);

            }
        }
        Log.d("TRONZE", "Possibility : " + possibility);
        if (possibility.equals("TRUE")) return true;
        else return false;
    }

    // 14. mealscheduleList의 가장 마지막 메뉴와 메뉴코드를 비교해서 같은 메뉴는 아닌지, 국가/조리법/주재료1/주재료2 중 2개 이하로 겹치는지 체크한다.
    public boolean isDissimilar(MenuScore sortedCandidateMenuScore, Integer user_id) {
        ArrayList<MealSchedule> mealScheduleArrayList = MealScheduleByUserID(user_id);
        int size = mealScheduleArrayList.size();

        if (mealScheduleArrayList.size() == 0) {    // 만약 최초 배정이라면
            return true;
        }

        else {
            MealSchedule recentSchedule = mealScheduleArrayList.get(size - 1);
            int count = 0;

            Integer candidateMenuID = sortedCandidateMenuScore.getMenu_id();
            Integer compareMenuID = recentSchedule.getMenu_id();
            ArrayList<Menu> menuArrayList = getAllMenu();

            String recentMenuCode = "", menuCode = "";
            String recentMenuCountry = "", recentMenuType = "", recentMenuIgd1 = "", recentMenuIgd2 = "";
            String menuCountry= "", menuType = "", menuIgd1 = "", menuIgd2 = "";

            for (int i = 0; i < menuArrayList.size(); i++) {    // Menu DB에서 최근 메뉴코드랑 지금 메뉴 코드 받아옴
                if (menuArrayList.get(i).getMenu_id().equals(compareMenuID)) {
                    recentMenuCode = menuArrayList.get(i).getCode();
                    recentMenuCountry = recentMenuCode.substring(0, 1);
                    recentMenuType = recentMenuCode.substring(1, 2);
                    recentMenuIgd1 = recentMenuCode.substring(2, 4);
                    recentMenuIgd2 = recentMenuCode.substring(recentMenuCode.length() - 2, recentMenuCode.length());
                }
                if (menuArrayList.get(i).getMenu_id().equals(candidateMenuID)) {
                    menuCode = menuArrayList.get(i).getCode();
                    menuCountry = menuCode.substring(0, 1);
                    menuType = menuCode.substring(1, 2);
                    menuIgd1 = menuCode.substring(2, 4);
                    menuIgd2 = menuCode.substring(menuCode.length() - 2, menuCode.length());
                }
            }

            if (recentMenuCountry.equals(menuCountry)) count += 1;
            if (recentMenuType.equals(menuType)) count += 1;
            if (recentMenuIgd1.equals(menuIgd1) || recentMenuIgd1.equals(menuIgd2)) count += 1;
            if (recentMenuIgd2.equals(menuIgd1) || recentMenuIgd2.equals(menuIgd1)) count += 1;

            if (count >= 3) return false;
            else return true;
        }
    }

    // 이하 이행 여부 체크

        // 메뉴 이행 시 갱신 (보유 식재료 및 최근 배정된 날짜)
    public void userMealDid(Integer user_id, ArrayList<Float> moreIngredientList, MealSchedule mealSchedule, int option){
//        // *Boundary 단에서 어제 날짜인지 체크해서 이행 여부 체크할 수 있는지 판단해야함. OK
//        // *이행 여부 체크하려는 식단의 날짜가 '어제'면, 팝업 띄워서 이행여부 체크하기. 이행했다고 응답 시, OK
//        // *Boundary 단에서 더 쓴 Ingredient는 usedmenuIngredientList에 수정해서 보내줄 것!! userDidMeal 호출. OK
//
        switch (option) {
            // 1. UserIngredient DB에서 amount, reservedamount usedmenuIngredientList item의 amount 값 만큼 차감한다.
            case 0: // 이행 했다! (추가 식재료 조사해서 갱신하는 로직)
                ArrayList<MenuIngredient> menuIngredientsbymenu1 = getAllMenuIngredientByMenuId(mealSchedule.getMenu_id());

                for (int i = 0; i < menuIngredientsbymenu1.size(); i++) {
                    Float totalusedamount = menuIngredientsbymenu1.get(i).getIgdamount() + moreIngredientList.get(i);

                    Float originalamount = 0.0f;
                    Float originalreservedamount = 0.0f;

                    String query = "SELECT amount, reservedamount FROM UserIngredient WHERE igd_id = " + menuIngredientsbymenu1.get(i).getIgd_menu();
                    Cursor c = db.rawQuery(query, null);
                    if (c != null) {
                        while (c.moveToNext()) {
                            originalamount = c.getFloat(0);
                            originalreservedamount = c.getFloat(1);
                        }
                    }

//                    ArrayList<UserIngredient> originaluserigd = UserIngredientByUserID(user_id);
//
//                    for (int k=0; k<originaluserigd.size();k++){
//                        System.out.println(k+"번째 재료"+originaluserigd.get(k).getAmount());
//                    }

                    String query_updateamount = "UPDATE UserIngredient SET amount =? WHERE user_id =? AND igd_id =?" ;
                    Float f1 = (originalamount - totalusedamount);
                    db.rawQuery(query_updateamount, new String[]{f1.toString(), user_id.toString(), menuIngredientsbymenu1.get(i).getIgd_menu().toString()});

                    String query_updatereservedamount = "UPDATE UserIngredient SET reservedamount =? WHERE user_id =? AND igd_id =?";
                    Float f2 = (originalreservedamount - totalusedamount);
                    db.rawQuery(query_updatereservedamount, new String[]{f2.toString(), user_id.toString(),menuIngredientsbymenu1.get(i).getIgd_menu().toString()});

//                    for (int k=0; k<originaluserigd.size();k++){
//                        System.out.println(k+"번째 재료"+originaluserigd.get(k).getAmount());
//                    }
                }

                // 2. MenuScore DB에서 해당 mealSchedule의 code와 동일한 메뉴들에 대해서 recentassign을 오늘 날짜로 갱신한다.
                String assignedMenuCode = "";
                String query_menucode = "SELECT code FROM Menu WHERE menu_id = " + mealSchedule.getMenu_id();
                Cursor c = db.rawQuery(query_menucode, null);
                if (c != null) {
                    while (c.moveToNext()) {
                        assignedMenuCode = c.getString(0);
                    }
                }

                Date today = new Date();
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                String todaydate = format.format(today);

                ArrayList<Integer> sameCodeMenuId = new ArrayList<Integer>();
                String query_samecode = "SELECT menu_id FROM Menu WHERE code=?";
                Cursor c2 = db.rawQuery(query_samecode, new String[]{assignedMenuCode});

                if (c2 != null) {
                    while (c2.moveToNext()) {
                        sameCodeMenuId.add(c2.getInt(0));
                    }
                }

                for (int i = 0; i > sameCodeMenuId.size(); i++) {
                    String query_updaterecentassign = "UPDATE MenuScore SET recentassign =? WHERE user_id=? AND menu_id =?";
                    db.rawQuery(query_updaterecentassign, new String[]{todaydate, user_id.toString(), sameCodeMenuId.get(i).toString()});
                }

            case 1: // 이행 안했다! 이유: 시간이 없어서. (amount는 차감x, reservedamount는 등록된메뉴재료만큼만차감o / recentassign 갱신x)
                ArrayList<MenuIngredient> menuIngredientsbymenu2 = getAllMenuIngredientByMenuId(mealSchedule.getMenu_id());

                for (int i = 0; i < menuIngredientsbymenu2.size(); i++) {
                    Float originalmenuamount = menuIngredientsbymenu2.get(i).getIgdamount();

                    Float originalreservedamount = 0.0f;

                    String query = "SELECT reservedamount FROM UserIngredient WHERE igd_id = " + menuIngredientsbymenu2.get(i).getIgd_menu().toString();
                    Cursor c3 = db.rawQuery(query, null);
                    if (c3 != null) {
                        while (c3.moveToNext()) {
                            originalreservedamount = c3.getFloat(0);
                        }
                    }

                    String query_updatereservedamount = "UPDATE UserIngredient SET reservedamount =? WHERE user_id =? AND igd_id =?";
                    Float f3 = (originalreservedamount - originalmenuamount);
                    db.rawQuery(query_updatereservedamount, new String[]{f3.toString(), user_id.toString(), menuIngredientsbymenu2.get(i).getIgd_menu().toString()});
                }
                break;

            case 2: // 이행 안했다! 이유: 조리를 실패해서 (amount, recentamount 모두 등록된 메뉴재료만큼만 차감o / recentassign 갱신x)
                ArrayList<MenuIngredient> menuIngredientsbymenu3 = getAllMenuIngredientByMenuId(mealSchedule.getMenu_id());

                for (int i = 0; i < menuIngredientsbymenu3.size(); i++) {
                    Float originalmenuamount = menuIngredientsbymenu3.get(i).getIgdamount();

                    Float originalamount = 0.0f;
                    Float originalreservedamount = 0.0f;

                    String query = "SELECT amount, reservedamount FROM UserIngredient WHERE igd_id = " + menuIngredientsbymenu3.get(i).getIgd_menu().toString();
                    Cursor c4 = db.rawQuery(query, null);
                    if (c4 != null) {
                        while (c4.moveToNext()) {
                            originalamount = c4.getFloat(0);
                            originalreservedamount = c4.getFloat(1);
                        }
                    }

                    String query_updateamount = "UPDATE UserIngredient SET amount =? WHERE user_id =? AND igd_id =?";
                    Float f4 = (originalamount - originalmenuamount);
                    db.rawQuery(query_updateamount, new String[]{f4.toString(), user_id.toString(), menuIngredientsbymenu3.get(i).getIgd_menu().toString()});
                    String query_updatereservedamount = "UPDATE UserIngredient SET reservedamount =? WHERE user_id =? AND igd_id =?";
                    Float f5 = (originalreservedamount - originalmenuamount);
                    db.rawQuery(query_updatereservedamount, new String[]{f5.toString(), user_id.toString(), menuIngredientsbymenu3.get(i).getIgd_menu().toString()});
                }
                break;

            case 3: // 이행 안했다! 이유: 식재료가 부족해서 (amount는 덮어쓰기, reservedamount는 등록된 메뉴재료만큼만 차감o / recentassign 갱신x)
                ArrayList<MenuIngredient> menuIngredientsbymenu4 = getAllMenuIngredientByMenuId(mealSchedule.getMenu_id());

                for (int i = 0; i < menuIngredientsbymenu4.size(); i++) {
                    Float originalmenuamount = menuIngredientsbymenu4.get(i).getIgdamount();
                    Float realuserigdamount = moreIngredientList.get(i);

                    Float originalamount = 0.0f;
                    Float originalreservedamount = 0.0f;

                    String query = "SELECT reservedamount FROM UserIngredient WHERE igd_id = " + menuIngredientsbymenu4.get(i).getIgd_menu();
                    Cursor c5 = db.rawQuery(query, null);
                    if (c5 != null) {
                        while (c5.moveToNext()) {
                            originalreservedamount = c5.getFloat(0);
                        }
                    }

                    String query_updateamount = "UPDATE UserIngredient SET amount =? WHERE user_id =? AND igd_id =?";
                    Float f6 = realuserigdamount;
                    db.rawQuery(query_updateamount, new String[]{f6.toString(), user_id.toString(), menuIngredientsbymenu4.get(i).getIgd_menu().toString()});
                    String query_updatereservedamount = "UPDATE UserIngredient SET reservedamount=? WHERE user_id =? AND igd_id =?";
                    Float f7 = (originalreservedamount - originalmenuamount);
                    db.rawQuery(query_updatereservedamount, new String[]{f7.toString(), user_id.toString(), menuIngredientsbymenu4.get(i).getIgd_menu().toString()});
                }
                break;

            default: // 이행 안했다! 이유: 기타 (amount는 차감x, reservedamount는 등록된메뉴재료만큼만차감o / recentassign 갱신x)
                ArrayList<MenuIngredient> menuIngredientsbymenu5 = getAllMenuIngredientByMenuId(mealSchedule.getMenu_id());

                for (int i = 0; i < menuIngredientsbymenu5.size(); i++) {
                    Float originalmenuamount = menuIngredientsbymenu5.get(i).getIgdamount();

                    Float originalreservedamount = 0.0f;

                    String query = "SELECT reservedamount FROM UserIngredient WHERE igd_id = " + menuIngredientsbymenu5.get(i).getIgd_menu();
                    Cursor c3 = db.rawQuery(query, null);
                    if (c3 != null) {
                        while (c3.moveToNext()) {
                            originalreservedamount = c3.getFloat(0);
                        }
                    }

                    String query_updatereservedamount = "UPDATE UserIngredient SET reservedamount=? WHERE user_id =? AND igd_id =?";
                    Float f8 = (originalreservedamount - originalmenuamount);
                    db.rawQuery(query_updatereservedamount, new String[]{f8.toString(), user_id.toString(), menuIngredientsbymenu5.get(i).getIgd_menu().toString()});
                }
        }
        // 3. user_id, mealSchedule.date, mealSchedule.meal을 파라미터로 넘겨주는 makeMealDone을 호출한다.
        makeMealDone(user_id, mealSchedule);
    }

    public String getMealscheduleDoneBYScdId(Integer scd_id, Integer user_id){
        String done = "";
        String query = "SELECT done FROM MealSchedule WHERE user_id =? AND scd_id=?";
        Cursor c = db.rawQuery(query, new String[]{user_id.toString(), scd_id.toString()});
        if (c != null) {
            while (c.moveToNext()) {
                done = c.getString(0);
            }
        }
        return done;
    }

    // 식단에 대해 done 했다고 표시, 어제 3끼 다 이행여부 체크 했으면 내일 3끼 추천하도록 makeSchedule 호출
    public void makeMealDone(Integer user_id, MealSchedule mealSchedule){

//        // 2. mealScheduleList에서 date, meal이 같은 item을 찾아서 done을 true로 바꾼다.
        ContentValues cv = new ContentValues();
        cv.put("scd_id", mealSchedule.getScd_id());
        cv.put("user_id", mealSchedule.getUser_id());
        cv.put("menu_id", mealSchedule.getMenu_id());
        cv.put("date", mealSchedule.getDate());
        cv.put("meal", mealSchedule.getMeal());
        cv.put("done", "TRUE");
        String[] params = new String[]{mealSchedule.getScd_id().toString()};
        db.update(T_MEALSCHEDULE, cv, "scd_id=?", params);

//        // 3. mealScheduleList에서 date가 같은 item들을 찾아서 alldonecheckList로 뽑아온다.
        ArrayList<MealSchedule> alldonecheckList = new ArrayList<MealSchedule>();
        String query_samedatemealList = "SELECT * FROM MealSchedule WHERE date = "+mealSchedule.getDate();
        Cursor c = db.rawQuery(query_samedatemealList, null);
        if (c != null) {
            while (c.moveToNext()) {
                MealSchedule onemealscd = new MealSchedule();
                onemealscd.setScd_id(c.getInt(0));
                onemealscd.setMenu_id(c.getInt(1));
                onemealscd.setUser_id(c.getInt(2));
                onemealscd.setDate(c.getString(3));
                onemealscd.setMeal(c.getString(4));
                onemealscd.setDone(c.getString(5));
                alldonecheckList.add(onemealscd);
            }
        }

        boolean flag = true;
        for (MealSchedule m : alldonecheckList){
            if (m.getDone().equals("FALSE")){
                flag = false;
                break;
            }
        }

        if (flag){ // 3개 다 true면,
            // 식단을 짜는 함수 호출
        }
    }
}
