package com.example.test_recommend.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.Entity.MenuScore;
import com.example.test_recommend.Entity.ScheduleHistory;
import com.example.test_recommend.Entity.UserIngredient;
import com.example.test_recommend.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Time;
import java.util.ArrayList;

public class RecommendController extends SQLiteOpenHelper {
    private static final String dbName = "igdtest4.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    private static final String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY not null, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null," +
            "FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
            "country text not null, time text not null, level text not null, recipelink text not null)";
    private static final String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
            "igdtype text not null , igdamount double not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id)," +
            " PRIMARY KEY (menu_id, igd_id))";
    private static final String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
            "score double not null , recentassign text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id))";
    private static final String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory (user_id INTEGER, menu_id INTEGER," +
            " meal text NOT NULL, result text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id, meal))";
    private static final String CREATE_MEALSCHEDULE = "CREATE TABLE IF NOT EXISTS MealSchedule (scd_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
            "user_id INTEGER not null, date DATE not null, meal text not null, done BLOB not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (user_id) REFERENCES User(user_id))";

    private static SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

    // 유저 아이디 받아옴
    public static Integer getUserID() {
        // user_id를 기반으로 하기 때문에 param으로 받아오거나 글로벌 전역변수로 설정
        return 0;
    }

    public ArrayList<UserIngredient> UserIngredientByUserID(Integer user_id) {
        ArrayList<UserIngredient> userIngredientArrayList = new ArrayList<>();
        String query = "SELECT * FROM UserIngredient WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                UserIngredient oneuserigd = new UserIngredient();
                oneuserigd.setUserigd_id(c.getInt(0));
                oneuserigd.setUser_id(c.getInt(1));
                oneuserigd.setIgd_id(c.getInt(2));
                oneuserigd.setAmount(c.getInt(3));
                oneuserigd.setReservedamount(c.getInt(4));
                oneuserigd.setBuydate(c.getString(5));
                oneuserigd.setExpirationdate(c.getString(6));

                userIngredientArrayList.add(oneuserigd);
            }
        }
        db.execSQL(query);
        return userIngredientArrayList;
    }

    public ArrayList<MenuScore> MenuScoreByUserID(Integer user_id) {
        ArrayList<MenuScore> menuScoreArrayList = new ArrayList<>();
        String query = "SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                menuScoreArrayList.add(onemenuscore);
            }
        }
        db.execSQL(query);
        return menuScoreArrayList;
    }

    public ArrayList<ScheduleHistory> ScheduleHistoryByUserID(Integer user_id) {
        ArrayList<ScheduleHistory> scheduleHistoryArrayList = new ArrayList<>();
        String query = "SELECT * FROM ScheduleHistory WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                ScheduleHistory onescdhistory = new ScheduleHistory();
                onescdhistory.setUser_id(c.getInt(0));
                onescdhistory.setMeal(c.getString(1));
                onescdhistory.setMeal(c.getString(2));
                onescdhistory.setResult(c.getBlob(3));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                scheduleHistoryArrayList.add(onescdhistory);
            }
        }
        db.execSQL(query);
        return scheduleHistoryArrayList;
    }

    public ArrayList<MealSchedule> MealScheduleByUserID(Integer user_id) {
        ArrayList<MealSchedule> mealScheduleArrayList = new ArrayList<>();
        String query = "SELECT * FROM MealSchedule WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MealSchedule onemealscd = new MealSchedule();
                onemealscd.setScd_id(c.getInt(0));
                onemealscd.setMenu_id(c.getInt(1));
                onemealscd.setUser_id(c.getInt(2));
                onemealscd.setDate(c.getString(3));
                onemealscd.setMeal(c.getString(4));
                onemealscd.setDone(c.getBlob(5));
                // 입력된 값은 TRUE, FALSE (String) -> 0,1 형태로 input

                mealScheduleArrayList.add(onemealscd);
            }
        }
        db.execSQL(query);
        return mealScheduleArrayList;
    }

    // csv 읽어오는 함수
    public void csvToDB_Menu(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menu);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    Menu csvmenu = new Menu();
                    String[] list = line.split(",");

                    csvmenu.setMenu_id(Integer.parseInt(list[0]));
                    csvmenu.setName(list[1]);
                    csvmenu.setCode(list[2]);
                    csvmenu.setCountry(list[3]);
                    csvmenu.setTime(Integer.parseInt(list[4]));
                    csvmenu.setLevel(list[5]);
                    csvmenu.setRecipelink(list[6]);

                    insertMenu(csvmenu);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void csvToDB_MenuIngredient(Context context){
        try {
            InputStream in = context.getResources().openRawResource(R.raw.menuingredient);
            if (in!= null) {
                InputStreamReader isr = new InputStreamReader(in, "utf-8");
                BufferedReader br = new BufferedReader(isr);
                // header
                br.readLine();

                String line = "";
                while ((line = br.readLine()) != null) {
                    // Split by ","
                    MenuIngredient csvmenuigd = new MenuIngredient();
                    String[] list = line.split(",");

                    csvmenuigd.setMenu_id(Integer.parseInt(list[0]));
                    csvmenuigd.setIgd_menu(Integer.parseInt(list[1]));
                    csvmenuigd.setIgdamount(Integer.parseInt(list[2]));
                    csvmenuigd.setIgdtype(list[3]);

                    insertMenuIngredient(csvmenuigd);
                }
                in.close();
            }
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    // data insertion
    public boolean insertMenu(Menu newmenu){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenu.getMenu_id());
        cv.put("name", newmenu.getName());
        cv.put("code", newmenu.getCode());
        cv.put("country", newmenu.getCountry());
        cv.put("time", newmenu.getTime());
        cv.put("level", newmenu.getLevel());
        cv.put("recipelink", newmenu.getRecipelink());
        return db.insert(T_MENU, null, cv)!= -1;
    }

    public boolean insertMenuIngredient(MenuIngredient newmenuigd){
        ContentValues cv = new ContentValues();
        cv.put("menu_id", newmenuigd.getMenu_id());
        cv.put("igd_id", newmenuigd.getIgd_menu());
        cv.put("type", newmenuigd.getIgdtype());
        cv.put("amount", newmenuigd.getIgdamount());
        return db.insert(T_MENUINGREDIENT, null, cv)!= -1;
    }

    public ArrayList<MenuScore> ScoreAdjustment(Integer user_id) {
        ArrayList<MenuScore> candidateMenuScoreList = new ArrayList<>();
        String query = "CREATE TABLE IF NOT EXISTS CandidateMenuScore AS SELECT * FROM MenuScore WHERE user_id = " + user_id;
        Cursor c = db.rawQuery(query, null);

        if (c!=null){
            while (c.moveToNext()){
                MenuScore onemenuscore = new MenuScore();
                onemenuscore.setUser_id(c.getInt(0));
                onemenuscore.setMenu_id(c.getInt(1));
                onemenuscore.setScore(c.getFloat(2));
                onemenuscore.setRecentassign(c.getString(3));

                candidateMenuScoreList.add(onemenuscore);
            }
        }

        db.execSQL(query);
        return candidateMenuScoreList;
    }

    // 재추천 방지
    public static ArrayList<Double> getScoreRecentAssign(ArrayList<Double> ScoreRecentAssign) {
        String query = "SELECT recentassign FROM MenuScore";
        Cursor c = db.rawQuery(query, null);
        double score = 0;
        int days = 0;

        if (c!=null){
            while (c.moveToNext()){
                if (days <= 1) score = -10;
                else if (days <= 3) score = -1;
                else if (days <= 7) score = -0.1;

                ScoreRecentAssign.add(score);
                score = 0;
            }
        }

        db.execSQL(query);
        return ScoreRecentAssign;
    }

    // 유통기한 체크
    public static ArrayList<Double> getScoreExpirationDate(ArrayList<Double> ScoreExpirationDate) {
        // useringredient를 호출해서 갖고 옴 (param으로 바꿀것)
        // useringredient 중 오늘 날짜를 갖고와서 차이가 3일 이내인 식재료들에 대해 igd_id를 리스트로 가져옴
        // for each menu - for each ingredient if menu has ingredient score + 0.1, if checked all user ingredients,
        // do same process for next menu until score adjustment for all menu is done

        return ScoreExpirationDate;
    }

    // 수량 체크
    public static ArrayList<Double> getScoreAmount(ArrayList<Double> ScoreAmount) {
        // create view *** as select * from menuingredient where igdtype = "주" -> 즉 메뉴 재료 중에서도 주재료만 뽑아옴
        return ScoreAmount;
    }
}
