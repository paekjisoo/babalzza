package com.example.test_recommend.Entity;

public class MenuIngredient {
    Integer menu_id;
    Integer igd_menu;
    String igdtype;
    Integer igdamount;

    public MenuIngredient() {
    }

    public MenuIngredient(Integer menu_id, Integer igd_menu, String igdtype, Integer igdamount) {
        this.menu_id = menu_id;
        this.igd_menu = igd_menu;
        this.igdtype = igdtype;
        this.igdamount = igdamount;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public Integer getIgd_menu() {
        return igd_menu;
    }

    public void setIgd_menu(Integer igd_menu) {
        this.igd_menu = igd_menu;
    }

    public String getIgdtype() {
        return igdtype;
    }

    public void setIgdtype(String igdtype) {
        this.igdtype = igdtype;
    }

    public Integer getIgdamount() {
        return igdamount;
    }

    public void setIgdamount(Integer igdamount) {
        this.igdamount = igdamount;
    }
}
