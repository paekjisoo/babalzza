package com.example.test_recommend.Controller;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class RecommendController extends SQLiteOpenHelper {
    private static final String dbName = "igdtest4.db";
    private static final String T_INGREDIENT = "Ingredient";
    private static final String T_USERINGREDIENT = "UserIngredient";
    private static final String T_MEALSCHEDULE = "MealSchedule";
    private static final String T_MENU = "Menu";
    private static final String T_MENUINGREDIENT = "MenuIngredient";
    private static final String T_MENUSCORE = "MenuScore";
    private static final String T_SCHEDULEHISTORY = "ScheduleHistory";
    private static final int dbVersion = 1;

    // 실제 RUN할 때는 전체 식재료 Table이랑, 이용자 보유 식재료 Table은 여기서 create하지말 것. (같은 테이블이 여러번 생성될 가능성 o)
    private static final String CREATE_INGREDIENT = "CREATE TABLE IF NOT EXISTS Ingredient (igd_id INTEGER PRIMARY KEY not null, name text not null, image text, "+
            "code text not null, measure text not null, refrigeratedterm text not null, freezedterm text not null)";
    private static final String CREATE_USERINGREDIENT = "CREATE TABLE IF NOT EXISTS UserIngredient (userigd_id INTEGER PRIMARY KEY not null, user_id INTEGER not null ,"+
            "igd_id INTEGER not null, amount INTEGER not null, reservedamount INTEGER not null, buydate text not null, expirationdate text not null," +
            "FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id))";
    private static final String CREATE_MENU = "CREATE TABLE IF NOT EXISTS Menu (menu_id INTEGER PRIMARY KEY not null, name text not null , code text not null, " +
            "country text not null, time text not null, level text not null, recipelink text not null)";
    private static final String CREATE_MENUINGREDIENT = "CREATE TABLE IF NOT EXISTS MenuIngredient (menu_id INTEGER not null, igd_id INTEGER not null," +
            "igdtype text not null , igdamount double not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (igd_id) REFERENCES Ingredient(igd_id)," +
            " PRIMARY KEY (menu_id, igd_id))";
    private static final String CREATE_MENUSCORE = "CREATE TABLE IF NOT EXISTS MenuScore (user_id INTEGER not null, menu_id INTEGER not null," +
            "score double not null , recentassign text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id))";
    private static final String CREATE_SCHEDULEHISTORY = "CREATE TABLE IF NOT EXISTS ScheduleHistory (user_id INTEGER, menu_id INTEGER," +
            " meal text NOT NULL, result text not null, FOREIGN KEY (user_id) REFERENCES User(user_id), FOREIGN KEY (menu_id) REFERENCES Menu(menu_id)," +
            "PRIMARY KEY (user_id, menu_id, meal))";
    private static final String CREATE_MEALSCHEDULE = "CREATE TABLE IF NOT EXISTS MealSchedule (scd_id INTEGER PRIMARY KEY not null, menu_id INTEGER not null," +
            "user_id INTEGER not null, date DATE not null, meal text not null, done BLOB not null, FOREIGN KEY (menu_id) REFERENCES Menu(menu_id), FOREIGN KEY (user_id) REFERENCES User(user_id))";

    private SQLiteDatabase db;

    public RecommendController(Context context){
        super(context, dbName, null, dbVersion);
        db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db.execSQL(CREATE_INGREDIENT);
        db.execSQL(CREATE_MENU);
        db.execSQL(CREATE_MEALSCHEDULE);
        db.execSQL(CREATE_MENUINGREDIENT);
        db.execSQL(CREATE_MENUSCORE);
        db.execSQL(CREATE_USERINGREDIENT);
        db.execSQL(CREATE_SCHEDULEHISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+T_INGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_USERINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MEALSCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENU);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUINGREDIENT);
        db.execSQL("DROP TABLE IF EXISTS "+T_MENUSCORE);
        db.execSQL("DROP TABLE IF EXISTS "+T_SCHEDULEHISTORY);
        onCreate(db);
    }

    // 메뉴 추천에 필요한 operation들이랑, csvtoDB operation들 넣어야함.

    // MenuScore Table 점수 기준 내림차순으로 정렬
    public void topScoreMenu() { // Input param needed
        String query = "SELECT * FROM MenuScore ORDER BY score DESC";
        db.execSQL(query);
    }

}
