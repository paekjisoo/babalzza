package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.test_recommend.R;

public class Recommend_Main extends AppCompatActivity {

    Button btn_before;
    Button btn_after;
    Button btn_change;

    TextView txt_breakfast;
    TextView txt_lunch;
    TextView txt_dinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_main);

        btn_before=findViewById(R.id.btn_before);
        btn_after=findViewById(R.id.btn_after);
        btn_change=findViewById(R.id.btn_change);

        txt_breakfast=findViewById(R.id.txt_breakfast);
        txt_lunch=findViewById(R.id.txt_lunch);
        txt_dinner=findViewById(R.id.txt_dinner);

        // 각 button에 대한 클릭효과 정의
        // 최초 가감된 MenuScore 불러와서 UserIngredient 참고해서 조정
    }
}
