package com.example.test_recommend.Entity;

public class ScheduleHistory {
    Integer user_id;
    Integer menu_id;
    String meal;
    String result;

    public ScheduleHistory() {
    }

    public ScheduleHistory(Integer user_id, Integer menu_id, String meal, String result) {
        this.user_id = user_id;
        this.menu_id = menu_id;
        this.meal = meal;
        this.result = result;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(Integer menu_id) {
        this.menu_id = menu_id;
    }

    public String getMeal() {
        return meal;
    }

    public void setMeal(String meal) {
        this.meal = meal;
    }

    public String isResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
