package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import com.example.test_recommend.R;

public class Recommend_Detail extends AppCompatActivity {
    Button btn_recipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_detail);

        btn_recipe=findViewById(R.id.btn_recipe);

    }
}
