package com.example.test_recommend.Boundary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.MealSchedule;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

public class Recommend_After extends AppCompatActivity {

    TextView txt_tomorrowdate;
    Button btn_main;
    Button btn_tomorrowchange;
    TextView txt_tomorrowbreakfast;
    TextView txt_tomorrowlunch;
    TextView txt_tomorrowdinner;

    public Integer user_id;
    ArrayList<MealSchedule> mealScheduleArrayList;
    ArrayList<Menu> menuList;
    RecommendController recommendController;

    Date tomorrow;
    Calendar cal;
    SimpleDateFormat format;
    String tomorrowdate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_after);

        recommendController = new RecommendController(this);
        user_id = recommendController.getUserID();
        mealScheduleArrayList = recommendController.MealScheduleByUserID(user_id);
        menuList = recommendController.getAllMenu();


        format = new SimpleDateFormat("yyyy-MM-dd");
        cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 1);
        tomorrow = cal.getTime();
        tomorrowdate = format.format(tomorrow);

        txt_tomorrowdate = (TextView) findViewById(R.id.txt_tomorrowdate);
        txt_tomorrowdate.setText(tomorrowdate);

        btn_main = (Button) findViewById(R.id.btn_main);
        btn_tomorrowchange = (Button) findViewById(R.id.btn_tomorrowchange);
        txt_tomorrowbreakfast = (TextView)findViewById(R.id.txt_tomorrowbreakfast);
        txt_tomorrowlunch = (TextView)findViewById(R.id.txt_tomorrowlunch);
        txt_tomorrowdinner = (TextView)findViewById(R.id.txt_tomorrowdinner);

        btn_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent changeintent = new Intent(Recommend_After.this, MainActivity.class);
                Recommend_After.this.startActivity(changeintent);
            }
        });

        final ArrayList<MealSchedule> tomorrowmealList = new ArrayList<MealSchedule>();
        for(MealSchedule m : mealScheduleArrayList){
            if (m.getDate().equals(tomorrowdate)){
                if (m.getMeal().equals("아침")){
                    tomorrowmealList.add(0, m);
                }
                else if (m.getMeal().equals("점심")){
                    tomorrowmealList.add(1, m);
                }
                else if (m.getMeal().equals("저녁")){
                    tomorrowmealList.add(2, m);
                }
            }
        }

        txt_tomorrowbreakfast.setText(menuList.get(tomorrowmealList.get(0).getMenu_id()-1).getName());
        txt_tomorrowlunch.setText(menuList.get(tomorrowmealList.get(1).getMenu_id()-1).getName());
        txt_tomorrowdinner.setText(menuList.get(tomorrowmealList.get(2).getMenu_id()-1).getName());

        txt_tomorrowbreakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent breakfastintent = new Intent(Recommend_After.this, Recommend_Detail.class);
                breakfastintent.putExtra("menu_id", tomorrowmealList.get(0).getMenu_id());
                Recommend_After.this.startActivity(breakfastintent);
            }
        });

        txt_tomorrowlunch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lunchintent = new Intent(Recommend_After.this, Recommend_Detail.class);
                lunchintent.putExtra("menu_id", tomorrowmealList.get(1).getMenu_id());
                Recommend_After.this.startActivity(lunchintent);
            }
        });

        txt_tomorrowdinner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dinnerintent = new Intent(Recommend_After.this, Recommend_Detail.class);
                dinnerintent.putExtra("menu_id", tomorrowmealList.get(2).getMenu_id());
                Recommend_After.this.startActivity(dinnerintent);
            }
        });

    }
}
