package com.example.test_recommend.Boundary;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.R;

public class FirstUsageActivity extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        FirstUsageActivity.DatabaseInitializer databaseInitializer = new FirstUsageActivity.DatabaseInitializer(this, this);
        databaseInitializer.execute();

        btn = (Button) findViewById(R.id.btn_toaddigd);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gotoaddigd = new Intent(FirstUsageActivity.this, UserIngredientAddActivity.class);
                FirstUsageActivity.this.startActivity(gotoaddigd);
            }
        });
    }

    private static class DatabaseInitializer extends AsyncTask {

        ProgressDialog progressDialog;
        Context context;
        Activity activity;

        SharedPreferences csvload;
        RecommendController recommendController;


        public DatabaseInitializer(Context context, Activity activity) {
            super();

            this.context = context;
            this.activity = activity;

            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Initializing...");
            progressDialog.setCancelable(false);
            progressDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Horizontal);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            progressDialog.dismiss();

        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected Object doInBackground(Object[] objects) {
            recommendController = new RecommendController(context);

            csvload = context.getSharedPreferences("is_csv_loaded1120", Activity.MODE_PRIVATE);
            String result = csvload.getString("is_csv_loaded", "");
            if (result.equals("")) {
                recommendController.csvToDB_User(context);
                recommendController.csvToDB_Ingredient(context);
//                recommendController.csvToDB_UserIngredient(context);
                recommendController.csvToDB_Menu(context);
                recommendController.csvToDB_MenuIngredient(context);
                recommendController.csvToDB_MenuScore(context);
//                recommendController.csvToDB_MealSchedule(context);
                recommendController.csvToDB_ScheduleHistory(context);

                SharedPreferences.Editor editor = csvload.edit();
                editor.putString("is_csv_loaded", "done");
                editor.commit();
            }
            return null;
        }
    }
}
