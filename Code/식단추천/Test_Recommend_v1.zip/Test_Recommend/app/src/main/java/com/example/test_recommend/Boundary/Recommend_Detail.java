package com.example.test_recommend.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.test_recommend.Controller.RecommendController;
import com.example.test_recommend.Entity.Menu;
import com.example.test_recommend.Entity.MenuIngredient;
import com.example.test_recommend.R;

import java.util.ArrayList;

public class Recommend_Detail extends AppCompatActivity {
    Button btn_recipe;
    ImageView img_menu;
    TextView txt_menuname;
    TextView txt_info;
    TextView txt_ingredients;

    ArrayList<MenuIngredient> menuIngredientList;
    Menu detailedMenu;
    RecommendController controller;
    Integer menu_id;
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend_detail);

        Intent intent = getIntent(); /*데이터 수신*/
        menu_id = intent.getExtras().getInt("menu_id");

        controller = new RecommendController(this);

        detailedMenu = controller.getAllMenu().get(menu_id-1);
        menuIngredientList = controller.getAllMenuIngredientByMenuId(menu_id);

        final Uri recipeUri = Uri.parse(detailedMenu.getRecipelink());
        img_menu = (ImageView) findViewById(R.id.img_menu);

        txt_menuname = (TextView) findViewById(R.id.txt_menuname);
        txt_menuname.setText(detailedMenu.getName());

        txt_info = (TextView) findViewById(R.id.txt_info);
        String menuinfo = detailedMenu.getCountry()+" / "+detailedMenu.getTime()+ " / "+detailedMenu.getLevel();
        txt_info.setText(menuinfo);

        txt_ingredients = (TextView) findViewById(R.id.txt_ingredients);
        String menuigdtostring = "";
        for (MenuIngredient m : menuIngredientList){
            menuigdtostring += controller.getIngredientNameByIgdId(m.getIgd_menu())+" "+m.getIgdamount()+controller.getIngredientMeasureByIgdId(m.getIgd_menu())+",";
        }
        menuigdtostring = menuigdtostring.substring(0, menuigdtostring.length()-1);
        txt_ingredients.setText(menuigdtostring);

        btn_recipe=findViewById(R.id.btn_recipe);
        btn_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, recipeUri);
                startActivity(intent);
            }
        });

    }

}
