package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;

import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.babalzza.Controller.MemoController;
import com.example.babalzza.Entity.ShoppingMemo;
import com.example.myapplication.R;

import java.util.ArrayList;



public class Memo_Delete extends AppCompatActivity {

    Button btndel;
    Button btncan;

    ListView listview;

    public ArrayList<ShoppingMemo> memoList;
    CustomChoiceListViewAdapter adapter;

    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_delete);

        btndel = (Button) findViewById(R.id.btn_delsave);
        btncan = (Button) findViewById(R.id.btn_delcan);

        memoList = new ArrayList<ShoppingMemo>();

        memoController = new MemoController(this);
        memoList=memoController.getAllMemo();

        adapter = new CustomChoiceListViewAdapter();

        listview = (ListView) findViewById(R.id.listview2);
        listview.setAdapter(adapter);

        for(ShoppingMemo m:memoList){
            adapter.addItem(m.getMemo_Id(), m.getIgdname(), m.getAmount());
        }

        btndel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;

                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
//                        System.out.println(i+"번째 메모를 삭제하는중");
                        memoController.deleteData(adapter.getItem(i).getMemo_Id());
                    }
                }
                // 모든 선택 상태 초기화.
                adapter.notifyDataSetChanged();
                Intent intent=new Intent(getApplicationContext(), Memo_Main.class);
                startActivity(intent);
            }
        });

        btncan.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                finish();
            }
        });
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> listViewItemList = new ArrayList<ShoppingMemo>();

        public CustomChoiceListViewAdapter() {
        }

        @Override
        public int getCount() {
            return listViewItemList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return listViewItemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final int pos = position;
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.igdnamearea);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.amountarea);

            ShoppingMemo listViewItem = listViewItemList.get(position);

            ing_name.setText(listViewItem.getIgdname());
            ing_amount.setText(""+listViewItem.getAmount()+"");

            return convertView;
        }

        public void addItem(int memo_id, String name, int amount){
            ShoppingMemo item = new ShoppingMemo();
            item.setMemo_Id(memo_id);
            item.setIgdname(name);
            item.setAmount(amount);

            listViewItemList.add(item);
        }
    }




}
