package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.babalzza.Controller.MemoController;
import com.example.babalzza.Entity.ShoppingMemo;
import com.example.myapplication.R;

import java.util.ArrayList;

public class Memo_Main extends AppCompatActivity {

    Button btn_memoadd;
    Button btn_memodel;
    Button btnConfirm;
    Button btnCancel;

    EditText et_igdname;
    EditText et_amount;

    ListView listview;

    ArrayList<ShoppingMemo> memoList;
    CustomChoiceListViewAdapter adapter;

    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_main);

        btn_memoadd = (Button) findViewById(R.id.btn_memoadd);
        btn_memodel = (Button) findViewById(R.id.btn_memodel);

        memoController = new MemoController(this);
        memoList=memoController.getAllMemo();

        listview = (ListView) findViewById(R.id.listview1);
        adapter = new CustomChoiceListViewAdapter(getApplicationContext(), memoList);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addData();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;

                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
//                        System.out.println(i+"번째 메모를 삭제하는중");
                        memoController.deleteData(adapter.getItem(i).getMemo_Id());
                    }
                }
                // 모든 선택 상태 초기화.
                memoList = memoController.getAllMemo();
                adapter = new CustomChoiceListViewAdapter(getApplicationContext(), memoList);
                listview.setAdapter(adapter);
            }
        });
    }

    void addData(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.memo_add, (ViewGroup)findViewById(R.id.Relative));
        builder.setTitle("장보기 메모 추가");
        builder.setView(addpopup);


        et_igdname = addpopup.findViewById(R.id.et_igdname);
        et_amount = addpopup.findViewById(R.id.et_amount);
        btnConfirm = addpopup.findViewById(R.id.btnConfirm);
        btnCancel = addpopup.findViewById(R.id.btnCancel);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());

                memoController.InsertMemo(igdname, amount);
                memoList = memoController.getAllMemo();
                adapter = new CustomChoiceListViewAdapter(getApplicationContext(), memoList);
                listview.setAdapter(adapter);
                dialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> listViewItemList = new ArrayList<ShoppingMemo>();

        public CustomChoiceListViewAdapter() {}
        public CustomChoiceListViewAdapter(Context context, ArrayList<ShoppingMemo> listViewItemList){
            this.listViewItemList = listViewItemList;
        }

        @Override
        public int getCount() {
            return listViewItemList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return listViewItemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final int pos = position;
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.igdnamearea);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.amountarea);

            ShoppingMemo listViewItem = listViewItemList.get(position);

            ing_name.setText(listViewItem.getIgdname());
            ing_amount.setText(""+listViewItem.getAmount()+"");

            return convertView;
        }

        public void addItem(int memo_id, String name, int amount){
            ShoppingMemo item = new ShoppingMemo();
            item.setMemo_Id(memo_id);
            item.setIgdname(name);
            item.setAmount(amount);

            listViewItemList.add(item);
        }
    }
}
