package com.example.babalzza;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class ShoppingMemo extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "babalzzadb4.db";
    private static final int DATABASE_VERSION = 1;

    public ShoppingMemo(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS ShoppingMemo (memo_id INTEGER PRIMARY KEY AUTOINCREMENT, igdname TEXT not null , amount INTEGER not null)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old,
                          int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS ShoppingMemo";
        database.execSQL(query);
        onCreate(database);
    }

    public boolean InsertMemo(String igdname, Integer amount) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("igdname", igdname);
            cv.put("amount", amount);
            return  database.insert("ShoppingMemo", null, cv)!= -1;
        } catch (Exception ex) {
            return false;
        }
    }

    public ArrayList<ShoppingMemo.Memo> getAllMemo() {
        String query = "SELECT * FROM ShoppingMemo";
        ArrayList<Memo> memolist = new ArrayList<Memo>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                Integer id = c.getInt(0);
                String igdname = c.getString(1);
                Integer amount = c.getInt(2);

                Memo ing = new Memo(id,igdname, amount);

                memolist.add(ing);
            }
        }
        return memolist;
    }

    public String deleteData(Integer memo_id){
        try{
            SQLiteDatabase database = this.getWritableDatabase();
            database.delete("ShoppingMemo", "memo_id ="+memo_id, null);
            database.close();
            return "Deleted Successfully";
        }catch (Exception ex){
            return ex.getMessage().toString();
        }
    }

    public class Memo{
        private Integer memo_id;
        private String igdname;
        private Integer amount;

        public Memo (String igdname, Integer amount) {
            super();
            this.igdname = igdname;
            this.amount = amount;
        }

        public Memo (Integer id, String igdname, Integer amount) {
            super();
            this.memo_id = id;
            this.igdname = igdname;
            this.amount = amount;
        }

        public Integer getMemo_Id() {return memo_id;}
        public void setMemo_Id(Integer memo_id) {this.memo_id = memo_id;}
        public String getIgdname() {return igdname;}
        public void setIgdname(String igdname) {this.igdname = igdname;}
        public Integer getAmount() {return amount;}
        public void setAmount(Integer amount) {this.amount = amount;}
//        public Boolean getState() {return state;}
//        public void setState(Boolean state) {this.state = state;}
    }
}