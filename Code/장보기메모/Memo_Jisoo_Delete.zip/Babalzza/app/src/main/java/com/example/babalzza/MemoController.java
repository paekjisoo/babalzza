package com.example.babalzza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;

import java.util.ArrayList;


public class MemoController {

    public static void addMemo(ShoppingMemo shoppingmemo, String igdname, Integer amount) {
        shoppingmemo.InsertMemo(igdname, amount);
    }

    public static ArrayList<ShoppingMemo.Memo> readMemo(ShoppingMemo shoppingmemo) {
        ArrayList<ShoppingMemo.Memo> shoppingMemoList = shoppingmemo.getAllMemo();
        return shoppingMemoList;
    }

    public static void deleteMemo(ShoppingMemo shoppingmemo, Integer memo_id){
        shoppingmemo.deleteData(memo_id);
    }
}
