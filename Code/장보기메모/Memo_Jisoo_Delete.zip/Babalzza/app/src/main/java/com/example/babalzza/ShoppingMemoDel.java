package com.example.babalzza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;


import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;

public class ShoppingMemoDel extends AppCompatActivity {

    public static ShoppingMemo shoppingmemo;
    public static ArrayList<ShoppingMemo.Memo> memolist;

    Button btndel;
    Button btncan;
    ListView listview;
    CustomChoiceListViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        memolist = new ArrayList<ShoppingMemo.Memo>();
        if(shoppingmemo == null)
            shoppingmemo = new ShoppingMemo(getApplicationContext());

        this.InitializaeMemoData();

        listview = (ListView) findViewById(R.id.listview2);
        adapter = new CustomChoiceListViewAdapter();
        listview.setAdapter(adapter);

        for(ShoppingMemo.Memo m:memolist){
            adapter.addItem(m.getMemo_Id(), m.getIgdname(), m.getAmount());
        }

        btndel = (Button) findViewById(R.id.btn_delsave);
        btncan = (Button) findViewById(R.id.btn_delcan);

        btndel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;

                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
//                        System.out.println(i+"번째 메모를 삭제하는중");
                        MemoController.deleteMemo(shoppingmemo, adapter.getItem(i).getMemo_id());
                    }
                }
                // 모든 선택 상태 초기화.
                adapter.notifyDataSetChanged();
                Intent intent=new Intent(getApplicationContext(),ShoppingMemoForm.class);
                startActivity(intent);
            }
        });

        btncan.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void InitializaeMemoData(){
        memolist = MemoController.readMemo(shoppingmemo);
    }

}
