package com.example.babalzza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myapplication.R;

import java.util.ArrayList;



public class ShoppingMemoForm extends AppCompatActivity {

    public static ShoppingMemo shoppingmemo;
    public static ArrayList<ShoppingMemo.Memo> memolist;
    public static MemoListAdapter adapter;

    private Button btn_memoadd;
    private Button btn_memodel;
    private Button btnConfirm;
    private EditText et_igdname;
    private EditText et_amount;
    private CheckBox checkBox;
    ListView listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_memoadd = (Button) findViewById(R.id.btn_memoadd);
        btn_memodel = (Button) findViewById(R.id.btn_memodel);

        memolist = new ArrayList<ShoppingMemo.Memo>();
        if(shoppingmemo == null)
            shoppingmemo = new ShoppingMemo(getApplicationContext());

        this.InitializaeMemoData();

        listview = (ListView) findViewById(R.id.listview1);
        adapter = new MemoListAdapter(getApplicationContext(), memolist);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addMemo();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),ShoppingMemoDel.class);
                startActivity(intent);
            }
        });

//        checkBox = (CheckBox)findViewById(R.id.checkBox);
/*
        checkBox.setOnClickListener(new CheckBox.OnClickListener(){
            public void onClick(View v) {
                if (CheckBox.isChecked()){

                }
            }
        });
*/
    }

    public void InitializaeMemoData(){
        memolist = MemoController.readMemo(shoppingmemo);
    }

    void addMemo(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.activity_dialog, null);
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.et_igdname);
        et_amount = addpopup.findViewById(R.id.et_amount);
        btnConfirm = addpopup.findViewById(R.id.btnConfirm);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());

                MemoController.addMemo(shoppingmemo, igdname, amount);
                memolist = MemoController.readMemo(shoppingmemo);
                adapter.setItemList(memolist);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public static class MemoListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<ShoppingMemo.Memo> memolist;

        public MemoListAdapter(Context context, ArrayList<ShoppingMemo.Memo> memolist) {
            this.context = context;
            this.memolist = memolist;
        }

        @Override
        public int getCount() {
            return memolist.size();
        }

        @Override
        public Object getItem(int position) {
            return memolist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo.Memo> memolist){
            this.memolist = memolist;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.d_memo, null);

            TextView ing_name = (TextView) v.findViewById(R.id.igdnamearea);
            TextView ing_amount = (TextView)v.findViewById(R.id.amountarea);

            ing_name.setText(memolist.get(position).getIgdname());
            ing_amount.setText(""+memolist.get(position).getAmount()+"");

            return v;
        }
    }
}
