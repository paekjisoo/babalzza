package com.example.babalzza.Entity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShoppingMemo{
    private Integer memo_id;
    private String igdname;
    private Integer amount;

    public ShoppingMemo(){}

    public ShoppingMemo (Integer id, String igdname, Integer amount) {
        super();
        this.memo_id = id;
        this.igdname = igdname;
        this.amount = amount;
    }

    public Integer getMemo_Id() {return memo_id;}

    public void setMemo_Id(Integer memo_id) {this.memo_id = memo_id;}

    public String getIgdname() {return igdname;}

    public void setIgdname(String igdname) {this.igdname = igdname;}

    public Integer getAmount() {return amount;}

    public void setAmount(Integer amount) {this.amount = amount;}
}
