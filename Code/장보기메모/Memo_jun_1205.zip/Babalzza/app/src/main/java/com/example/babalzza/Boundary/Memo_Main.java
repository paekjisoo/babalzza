package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.babalzza.Controller.MemoController;
import com.example.babalzza.Entity.ShoppingMemo;
import com.example.myapplication.R;

import java.util.ArrayList;

public class Memo_Main extends AppCompatActivity {

    Button btn_memoadd;
    Button btn_memodel;
    Button btnConfirm;

    EditText et_igdname;
    EditText et_amount;

    ListView listview;

    ShoppingMemo shoppingmemo;
    ArrayList<ShoppingMemo> memoList;
    MemoListAdapter adapter;

    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_memoadd = (Button) findViewById(R.id.btn_memoadd);
        btn_memodel = (Button) findViewById(R.id.btn_memodel);

        memoController = new MemoController(this);

        memoList = new ArrayList<ShoppingMemo>();
        if(shoppingmemo == null)
            shoppingmemo = new ShoppingMemo();

        this.InitializaeMemoData();

        listview = (ListView) findViewById(R.id.listview1);
        adapter = new MemoListAdapter(getApplicationContext(), memoList);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addData();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), Memo_Delete.class);
                startActivity(intent);
            }
        });

//        checkBox = (CheckBox)findViewById(R.id.checkBox);
/*
        checkBox.setOnClickListener(new CheckBox.OnClickListener(){
            public void onClick(View v) {
                if (CheckBox.isChecked()){

                }
            }
        });
*/
    }

    public void InitializaeMemoData(){
        memoController.getAllMemo();
    }

    void addData(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.activity_dialog, null);
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.et_igdname);
        et_amount = addpopup.findViewById(R.id.et_amount);
        btnConfirm = addpopup.findViewById(R.id.btnConfirm);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());

                memoController.InsertMemo(igdname, amount);
                memoList = memoController.getAllMemo();
                adapter.setItemList(memoList);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public class MemoListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<ShoppingMemo> memoList;

        public MemoListAdapter(Context context, ArrayList<ShoppingMemo> memoList) {
            this.context = context;
            this.memoList = memoList;
        }

        @Override
        public int getCount() {
            return memoList.size();
        }

        @Override
        public Object getItem(int position) {
            return memoList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo> memoList){
            this.memoList = memoList;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.d_memo, null);

            TextView ing_name = (TextView) v.findViewById(R.id.igdnamearea);
            TextView ing_amount = (TextView)v.findViewById(R.id.amountarea);

            ing_name.setText(memoList.get(position).getIgdname());
            ing_amount.setText(""+memoList.get(position).getAmount()+"");

            return v;
        }
    }
}
