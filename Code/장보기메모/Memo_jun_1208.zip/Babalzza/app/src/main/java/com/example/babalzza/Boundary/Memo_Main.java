package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.babalzza.Controller.MemoController;
import com.example.babalzza.Entity.ShoppingMemo;
import com.example.myapplication.R;

import java.util.ArrayList;

public class Memo_Main extends AppCompatActivity {

    Button btn_memoadd;
    Button btn_memodel;
    Button btnConfirm;
    Button btnCancel;

    EditText et_igdname;
    EditText et_amount;

    ListView listview;

    ArrayList<ShoppingMemo> memoList;
    CustomChoiceListViewAdapter adapter;

    MemoController memoController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo_main);

        btn_memoadd = (Button) findViewById(R.id.memo_add);
        btn_memodel = (Button) findViewById(R.id.memo_del);

        memoController = new MemoController(this);
        memoList=memoController.getAllMemo();

        adapter = new CustomChoiceListViewAdapter(memoList);

        listview = (ListView) findViewById(R.id.memo_listview_main);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addData();
            }
        });

        btn_memodel.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                SparseBooleanArray checkedItems = listview.getCheckedItemPositions();
                int count = adapter.getCount() ;

                for (int i = count-1; i >= 0; i--) {
                    if (checkedItems.get(i)) {
                        memoController.deleteMemo(adapter.getItem(i).getMemo_Id());
                    }
                }
                memoList = memoController.getAllMemo();
                adapter = new CustomChoiceListViewAdapter(memoList);
                listview.setAdapter(adapter);
            }
        });
    }

    void addData(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.memo_add, (ViewGroup)findViewById(R.id.Relative));
        builder.setTitle("장보기 메모 추가");
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.memo_et_igdname);
        et_amount = addpopup.findViewById(R.id.memo_et_amount);
        btnConfirm = addpopup.findViewById(R.id.memo_confirm);
        btnCancel = addpopup.findViewById(R.id.memo_cancel);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());

                memoController.InsertMemo(igdname, amount);
                memoList = memoController.getAllMemo();
                adapter.setItemList(memoList);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public class CustomChoiceListViewAdapter extends BaseAdapter {
        private ArrayList<ShoppingMemo> memoList = new ArrayList<ShoppingMemo>();

        public CustomChoiceListViewAdapter(ArrayList<ShoppingMemo> memoList) {
            this.memoList = memoList;
        }

        @Override
        public int getCount() {
            return memoList.size();
        }

        @Override
        public ShoppingMemo getItem(int position) {
            return memoList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo> memoList){
            this.memoList = memoList;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final Context context = parent.getContext();

            if (convertView == null){
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.memo_layout, parent, false);
            }

            TextView ing_name = (TextView) convertView.findViewById(R.id.memo_igdname);
            TextView ing_amount = (TextView)convertView.findViewById(R.id.memo_amount);

            ShoppingMemo memo = memoList.get(position);

            ing_name.setText(memo.getIgdname());
            ing_amount.setText(""+memo.getAmount()+"");

            return convertView;
        }
    }
}
