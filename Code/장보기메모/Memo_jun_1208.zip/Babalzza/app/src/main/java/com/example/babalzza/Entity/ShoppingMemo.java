package com.example.babalzza.Entity;

public class ShoppingMemo{
    private Integer memo_id;
    private String igdname;
    private Integer amount;

    public ShoppingMemo(){}

    public Integer getMemo_Id() {return memo_id;}

    public void setMemo_Id(Integer memo_id) {this.memo_id = memo_id;}

    public String getIgdname() {return igdname;}

    public void setIgdname(String igdname) {this.igdname = igdname;}

    public Integer getAmount() {return amount;}

    public void setAmount(Integer amount) {this.amount = amount;}
}
