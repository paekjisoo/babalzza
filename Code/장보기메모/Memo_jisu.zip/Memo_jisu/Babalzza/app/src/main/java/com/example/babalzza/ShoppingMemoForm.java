package com.example.babalzza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.example.babalzza.MemoController;

import com.example.myapplication.R;

import java.util.ArrayList;

public class ShoppingMemoForm extends AppCompatActivity {

    public static ShoppingMemo shoppingmemo;
    public static ArrayList<ShoppingMemo.Memo> memos;
    public static MemoListAdapter adapter;

    private Button btn_memoadd;
    private Button btnConfirm;
    private EditText et_igdname;
    private EditText et_amount;
    private CheckBox checkBox;
    ListView listview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_memoadd = (Button) findViewById(R.id.btn_memoadd);

        memos = new ArrayList<ShoppingMemo.Memo>();
        if(shoppingmemo == null)
            shoppingmemo = new ShoppingMemo(getApplicationContext());

        this.InitializaeMemoData();

        listview = (ListView) findViewById(R.id.listview1);
        adapter = new MemoListAdapter(getApplicationContext(), memos);
        listview.setAdapter(adapter);

        btn_memoadd.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                addMemo();
            }
        });
//        checkBox = (CheckBox)findViewById(R.id.checkBox);
//        checkBox.setOnClickListener(new CheckBox.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                if (((CheckBox)v).isChecked()){
//                    TextView row = (TextView)lv.getItemAtPosition(position);
//                    row.setPaintFlags(row.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
//                }
//                else{
//
//                }
//            }
//        });
    }

    public void InitializaeMemoData(){
        memos = MemoController.readMemo(shoppingmemo, memos);
    }

    void addMemo(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater_dg = getLayoutInflater();
        final View addpopup = inflater_dg.inflate(R.layout.activity_dialog, null);
        builder.setView(addpopup);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        et_igdname = addpopup.findViewById(R.id.et_igdname);
        et_amount = addpopup.findViewById(R.id.et_amount);
        btnConfirm = addpopup.findViewById(R.id.btnConfirm);

        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String igdname = et_igdname.getText().toString();
                Integer amount = Integer.parseInt(et_amount.getText().toString());

                MemoController.addMemo(shoppingmemo, getApplicationContext(), igdname, amount);
                memos = MemoController.readMemo(shoppingmemo, memos);
                adapter.setItemList(memos);
                adapter.notifyDataSetChanged();
                dialog.dismiss();

            }
        });

        dialog.show();
    }
//
    public static class MemoListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<ShoppingMemo.Memo> memolist;

        public MemoListAdapter(Context context, ArrayList<ShoppingMemo.Memo> memolist) {
            this.context = context;
            this.memolist = memolist;
        }

        @Override
        public int getCount() {
            return memolist.size();
        }

        @Override
        public Object getItem(int position) {
            return memolist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void setItemList(ArrayList<ShoppingMemo.Memo> memolist){
            this.memolist = memolist;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.a_memo, null);

            TextView ing_name = (TextView) v.findViewById(R.id.igdnamearea);
            TextView ing_amount = (TextView)v.findViewById(R.id.amountarea);

            ing_name.setText(memolist.get(position).getIgdname());
            ing_amount.setText(""+memolist.get(position).getAmount()+"");

            return v;
        }
    }
}
