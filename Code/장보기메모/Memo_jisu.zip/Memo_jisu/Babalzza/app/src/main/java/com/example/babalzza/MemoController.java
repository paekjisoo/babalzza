package com.example.babalzza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;

import java.util.ArrayList;

import static com.example.babalzza.ShoppingMemoForm.memos;
import static com.example.babalzza.ShoppingMemoForm.shoppingmemo;

public class MemoController {

    public static void addMemo(ShoppingMemo shoppingmemo, Context context, String igdname, Integer amount) {
        shoppingmemo.InsertData(igdname, amount);
    }

    public static ArrayList<ShoppingMemo.Memo> readMemo(ShoppingMemo memo, ArrayList<ShoppingMemo.Memo> memolist) {
        memos = shoppingmemo.getAllMemo();
        return memos;
    }

}