package com.example.babalzza;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class ShoppingMemo extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "babalzzadb.db";
    private static final int DATABASE_VERSION = 1;

    public ShoppingMemo(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS ShoppingMemo ( _id INTEGER PRIMARY KEY AUTOINCREMENT, igdname text not null , amount INTEGER not null)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old,
                          int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS ShoppingMemo";
        database.execSQL(query);
        onCreate(database);
    }

    public String InsertData(String igdname, Integer amount) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "INSERT INTO  ShoppingMemo (igdname, amount) VALUES ('" + igdname + "'," + amount + ")";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }
    }

    public ArrayList<ShoppingMemo.Memo> getAllMemo() {
        String query = "SELECT * FROM ShoppingMemo";
        ArrayList<Memo> memolist = new ArrayList<Memo>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                String igdname = c.getString(0);
                Integer amount = c.getInt(1);

                Memo ing = new Memo(igdname, amount);

                memolist.add(ing);
            }
        }
        return memolist;
    }

    public class Memo{
        private Integer memo_id;
        private String igdname;
        private Integer amount;

        public Memo (String igdname, Integer amount) {
            super();
            this.igdname = igdname;
            this.amount = amount;
        }
        public Memo (Integer id, String name, Integer quantity) {
            super();
            this.memo_id = id;
            this.igdname = igdname;
            this.amount = amount;
        }
        public Integer getMemo_Id() {return memo_id;}
        public void setMemo_Id(Integer memo_id) {this.memo_id = memo_id;}
        public String getIgdname() {return igdname;}
        public void setIgdname(String igdname) {this.igdname = igdname;}
        public Integer getAmount() {return amount;}
        public void setAmount(Integer amount) {this.amount = amount;}
    }
}
