package com.example.babalzza;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseController extends SQLiteOpenHelper {
    private static final String LOGCAT = null;

    public DatabaseController(Context applicationcontext) {
        super(applicationcontext, "Babalzza.db", null, 1);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS tblIngredients ( _id INTEGER PRIMARY KEY, IngredientName TEXT)";
        database.execSQL(query);
    }

    public String InsertData(String ingredientName) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "insert into tblIngredients (IngredientName) values ('" + ingredientName + "')";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old,
                          int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS tblIngredients";
        database.execSQL(query);
        onCreate(database);
    }

    public Cursor getIngredients() {
        try {
            String selectQuery = "SELECT * FROM tblIngredients order by _id desc";
            SQLiteDatabase database = this.getWritableDatabase();
            Cursor cursor = database.rawQuery(selectQuery, null);
            return cursor;
        } catch (Exception ex) {
            return null;
        }
    }
}