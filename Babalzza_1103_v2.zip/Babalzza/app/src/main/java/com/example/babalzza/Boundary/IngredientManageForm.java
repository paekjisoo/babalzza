package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class IngredientManageForm extends AppCompatActivity implements View.OnClickListener {

    private Animation fab_open, fab_close;
    private Boolean isFabOpen = false;
    private FloatingActionButton fab;

    public static GridView myIngredients;
    public static IngredientListAdapter adapter;
    public static ArrayList<Ingredient> ingredientList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_main);

        myIngredients = (GridView)findViewById(R.id.myIngredient);
        ingredientList = new ArrayList<Ingredient>();

        adapter = new IngredientListAdapter(getApplicationContext(), ingredientList);
        myIngredients.setAdapter(adapter);

        // test code until here

        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.close);

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(this);
    }

    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.floatingActionButton:
                Toast.makeText(this, "추가", Toast.LENGTH_SHORT).show();
                Intent addintent= new Intent(IngredientManageForm.this, IngredientAdditionForm.class);
                IngredientManageForm.this.startActivity(addintent);
                break;
        }
    }
    public class IngredientListAdapter extends BaseAdapter {
        private Context context;
        private ArrayList<Ingredient> ingredient_list;

        public IngredientListAdapter(Context context, ArrayList<Ingredient> ingredient_list) {
            this.context = context;
            this.ingredient_list = ingredient_list;
        }

        @Override
        public int getCount() {
            return ingredient_list.size();
        }

        @Override
        public Object getItem(int position) {
            return ingredient_list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View v = View.inflate(context, R.layout.ingredient, null);

            ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
            TextView ing_name = (TextView)v.findViewById(R.id.nameText);
            TextView ing_quantity = (TextView)v.findViewById(R.id.quantityText);
            TextView ing_duedate = (TextView)v.findViewById(R.id.duedateText);

            ing_name.setText(ingredient_list.get(position).getName());
            ing_quantity.setText(ingredient_list.get(position).getQuantity().toString());
            ing_duedate.setText(ingredient_list.get(position).getDueDate());

            ing_image.setOnClickListener(new AdapterView.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(IngredientManageForm.this);
                    LayoutInflater inflater_dg = getLayoutInflater();

                    final View view = inflater_dg.inflate(R.layout.my_ingredient, null);


                    TextView show_name = (TextView)v.findViewById(R.id.nameText);
                    TextView show_quantity = (TextView)v.findViewById(R.id.quantityText);
                    TextView show_duedate = (TextView)v.findViewById(R.id.duedateText);


                    builder.setView(view);
                    AlertDialog dialog = builder.create();
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();
                }
            });
            return v;
        }
    }
}