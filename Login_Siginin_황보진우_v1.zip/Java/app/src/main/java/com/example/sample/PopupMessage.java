package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class PopupMessage extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup);
        Intent intent = getIntent();
        String message = intent.getStringExtra("message");

        TextView t_PopupText = findViewById(R.id.t_PopupText);
        t_PopupText.setText(message);
    }

    public void activity_ClosePopUp(View view) {
        finish();
    }
}
