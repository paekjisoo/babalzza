package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LogIn extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }

    //입력받은 ID와 Password로 로그인하고 초기화면으로 넘어가는 함수(미완)
    public void activity_LogIn(View view) {
        EditText et_Email = findViewById(R.id.et_Email);
        EditText et_Password = findViewById(R.id.et_Password);
        String email = et_Email.getText().toString();
        String password = et_Password.getText().toString();

        Intent intent = new Intent(this, LoginResult.class);
        intent.putExtra("email", email);
        intent.putExtra("password", password);
        startActivity(intent);
    }

    //회원가입 화면으로 넘어가는 함수
    public void activity_SignIn(View view) {
        Intent intent = new Intent(this, SignIn.class);
        startActivity(intent);
    }
}