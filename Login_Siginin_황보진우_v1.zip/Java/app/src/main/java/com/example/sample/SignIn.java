package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignIn extends Activity {
    boolean ID_Checked = false;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);
        Intent intent = getIntent();
    }

    //입력받은 ID의 적절성과 중복 여부를 확인하는 함수(미완)
    public void activity_checkID(View view) {
        EditText et_newEmail = findViewById(R.id.et_newEmail);
        String input = et_newEmail.getText().toString();
        ID_Checked = CheckID(input);
    }

    protected boolean CheckID(String input) {
        Intent intent = new Intent(this, PopupMessage.class);
        // 길이 체크
        if (input.length() < 6 || input.length() > 16) {
            intent.putExtra("message", "아이디는 6글자 이상, 16글자 이하의 알파벳, 또는 알파벳+숫자의 조합이어야 합니다.");
            startActivity(intent);
            return false;
        }
        // 패턴 체크(알파벳 또는 알파벳+숫자)
        boolean result = true;
        Pattern p1 = Pattern.compile("^[0-9a-zA-Z]*$");
        Matcher m1 = p1.matcher(input);
        if (m1.find()) {
            Pattern p2 = Pattern.compile("^[0-9]*$");
            Matcher m2 = p2.matcher(input);
            if (m2.find())
                result = false;
        } else
            result = false;
        // DB에 중복된 아이디가 있는지 체크 후 없으면 "사용 가능", 있으면 "사용할 수 없음"(미완)
        if (result) {
            intent.putExtra("message", "사용 가능한 아이디입니다.");
            startActivity(intent);
            return true;
        } else {
            intent.putExtra("message", "사용할 수 없는 아이디입니다.");
            startActivity(intent);
            return false;
        }
    }

    //비밀번호 생성규칙을 표시하는 함수
    public void activity_ShowRestrictions(View view) {
        Intent intent = new Intent(this, PopupMessage.class);
        String message = "비밀번호는 알파벳 대문자, 알파벳 소문자, 특수문자, 숫자의 4개 조합으로 하되\n= 3가지 조합인 경우 8자 이상,\n= 2가지 조합인 경우 10자 이상\n= 최소 2가지 이상의 조합\n= 3자 이상 연속된 값 불가\n= 3자 이상 키보드 상 연속된 값 불가\n= 3자 이상 같은 값 불가";
        intent.putExtra("message", message);
        startActivity(intent);
    }

    //회원가입에 앞서 Password의 적절성을 평가하고 적절하지 않을 경우 팝업창을 띄운다.
    //입력받은 ID와 Password를 회원 DB에 저장하고 로그인 화면으로 되돌아가는 함수(미완)
    public void activity_join(View view) {
        if (!ID_Checked) {
            Intent intent = new Intent(this, PopupMessage.class);
            intent.putExtra("message", "아이디 중복 확인을 해주세요.");
            startActivity(intent);
            return;
        }
        EditText et_newPassword = findViewById(R.id.et_newPassword);
        EditText et_confirmPassowrd = findViewById(R.id.et_confirmPassword);
        String pw1 = et_newPassword.getText().toString();
        String pw2 = et_confirmPassowrd.getText().toString();
        Intent intent = new Intent(this, PopupMessage.class);
        // 비밀번호의 조건 충족 여부에 따라 각기 다른 result 반환
        int result = checkPW(pw1);
        String message = "";
        switch (result) {
            case 0: break;
            case 1: message = "비밀번호를 입력하십시오."; break;
            case 2: message = "비밀번호는 8글자 이상, 16글자 미만입니다."; break;
            case 3: message = "알파벳 대문자, 소문자, 특수문자, 숫자 중 3개 이상을 조합하십시오."; break;
            case 99: message = "알수없는 오류";
        }
        // 오류 메시지 표시
        if (result != 0) {
            intent.putExtra("message", message);
            startActivity(intent);
            return;
        }
        else {
            // 비밀번호 두개의 일치여부 확인
            if (!pw1.equals(pw2)) {
                message = "비밀번호가 일치하지 않습니다!";
                intent.putExtra("message", message);
                startActivity(intent);
                return;
            }
            else {
                // 회원가입승인(미완)
                message = "회원가입이 완료되었습니다!";
                intent.putExtra("message", message);
                startActivity(intent);
                return;
            }
        }
    }

    public static int checkPW(String input) {
        try {
            // 입력 없음
            if (input == null || input.equals(""))
                return 1;
            // 길이 체크
            if (input.length() < 8 || input.length() > 16)
                return 2;
            // 패턴 체크(알파벳 대문자, 알파벳 소문자, 숫자, 특수문자 중 3개 이상 조합)
            Pattern pAlphabetLow = Pattern.compile("[a-z]"); Matcher mAlphabetLow = pAlphabetLow.matcher(input);
            Pattern pAlphabetUp = Pattern.compile("[A-Z]"); Matcher mAlphabetUp = pAlphabetUp.matcher(input);
            Pattern pSymbol = Pattern.compile("\\p{Punct}"); Matcher mSymbol = pSymbol.matcher(input);
            Pattern pNumber = Pattern.compile("[0-9]"); Matcher mNumber = pNumber.matcher(input);
            int result = 0;
            if (mAlphabetLow.find()) result++;
            if (mAlphabetUp.find()) result++;
            if (mSymbol.find()) result++;
            if (mNumber.find()) result++;
            if (result < 3) return 3;
            else return 0;
        }
        catch (Exception ex) {
            return 99;
        }
    }
}