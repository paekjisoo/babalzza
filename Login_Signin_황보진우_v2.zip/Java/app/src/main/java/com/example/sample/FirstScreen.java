package com.example.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

public class FirstScreen extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_screen);
    }

    public void activity_LogInScreen(View view) {
        Intent login = new Intent(this, LogIn.class);
        startActivity(login);
    }

    public void activity_SignInScreen(View view) {
        Intent signin = new Intent(this, SignIn.class);
        startActivity(signin);
    }
}
