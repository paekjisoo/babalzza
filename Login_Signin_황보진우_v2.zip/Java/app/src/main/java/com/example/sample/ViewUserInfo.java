package com.example.sample;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class ViewUserInfo extends Activity{
    private DBOpenHelper mDBOpenHelper;
    private SQLiteDatabase db;
    private Cursor mCursor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewuserinfo);
        mDBOpenHelper = new DBOpenHelper(ViewUserInfo.this, "user.db",null, 1);

        Intent login_successful = getIntent();
        String id = login_successful.getStringExtra("userid");
        String pw = "";

        // DB에서 회원 정보를 불러옴
        Cursor cursor = getAllData();
        while(cursor.moveToNext()) {
            String temp_id = cursor.getString(cursor.getColumnIndex("USERID"));
            if (id.equals(temp_id)) {
                pw = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                break;
            }
        }

        TextView t_viewID = findViewById(R.id.t_viewID);
        TextView t_viewPW = findViewById(R.id.t_viewPW);
        t_viewID.setText(id);
        t_viewPW.setText(pw);
    }

    // 비밀번호를 변경하는 함수 (미완)
    public void activity_changePW(View view) {
    }

    public boolean insert(String userid, String password) {
        db = mDBOpenHelper.getWritableDatabase();
        ContentValues value = new ContentValues();

        value.put("userid", userid);
        value.put("password", password);
        long result = db.insert("user_table", null, value);

        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        db = mDBOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user_table", null);
        return cursor;
    }
}