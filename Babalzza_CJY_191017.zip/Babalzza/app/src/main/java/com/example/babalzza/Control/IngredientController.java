package com.example.babalzza.Control;

import com.example.babalzza.Entity.Ingredient;

import java.util.ArrayList;

public class IngredientController {

    public static void addIngredient(String name, Integer quantity, String duedate) {
        Ingredient ingredient = new Ingredient("",0,"");

        ingredient.setName(name);
        ingredient.setQuantity(quantity);
        ingredient.setDueDate(duedate);

        ingredient.saveIngredient(ingredient);
    }

    public static ArrayList<Ingredient> readIngredient() {
        return Ingredient.showIngredient();
    }

}
