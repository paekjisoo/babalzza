package com.example.babalzza.Control;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;

import java.util.ArrayList;

public class MyListAdapter extends BaseAdapter {
    Context context;
    ArrayList<Ingredient> list_itemArrayList;

    TextView ingredient_textView;
    ImageView ingredient_imageView;

    public MyListAdapter(Context context, ArrayList<Ingredient> list_itemArrayList) {
        this.context = context;
        this.list_itemArrayList = list_itemArrayList;
    }


    @Override
    public int getCount() {
        return this.list_itemArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return this.list_itemArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.ingredient, null);
            ingredient_textView = (TextView)convertView.findViewById(R.id.ingredient_textView);
            ingredient_imageView = (ImageView)convertView.findViewById(R.id.ingredient_imageView);
        }
        ingredient_textView.setText(list_itemArrayList.get(position).getName());

        return convertView;
    }
}
