package com.example.babalzza;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.babalzza.Entity.Ingredient;

import java.util.ArrayList;

public class DatabaseController extends SQLiteOpenHelper {
    private static final String LOGCAT = null;
    private static final String DATABASE_NAME = "InnerDatabase(SQLite).db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseController(Context applicationcontext) {
        super(applicationcontext, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS UserIngredient ( _id INTEGER PRIMARY KEY AUTOINCREMENT, name text not null , quantity INTEGER not null, duedate text not null)";
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old,
                          int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS UserIngredient";
        database.execSQL(query);
        onCreate(database);
    }

    public String InsertData(String name, Integer quantity, String duedate) {
        try {
            SQLiteDatabase database = this.getWritableDatabase();
            String query = "insert into  UserIngredient (name, quantity, duedate) values ('" + name + "'," + quantity + ",'" + duedate + "')";
            database.execSQL(query);
            database.close();
            return "Added Successfully";
        } catch (Exception ex) {
            return ex.getMessage().toString();
        }

    }

    public Cursor getIngredients() {
        try {
            String selectQuery = "SELECT * FROM UserIngredient";
            SQLiteDatabase database = this.getWritableDatabase();
            Cursor cursor = database.rawQuery(selectQuery, null);
            return cursor;
        } catch (Exception ex) {
            return null;
        }
    }

    public ArrayList<Ingredient> getAllIngredients() {
        String query = "SELECT * FROM UserIngredient";
        ArrayList<Ingredient> ingredients = new ArrayList<Ingredient>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                String name = c.getString(1);
                Integer quantity = c.getInt(2);
                String duedate = c.getString(3);

                Ingredient ing = new Ingredient(name, quantity, duedate);

                ingredients.add(ing);
            }
        }

        return ingredients;
    }
}