package com.example.babalzza.Control;

import android.content.Context;

import com.example.babalzza.DatabaseController;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.IngredientListAdapter;

import static com.example.babalzza.Boundary.IngredientManageForm.*;

public class IngredientController {

    public void addIngredient(DatabaseController dbController, Context context, String name, Integer quantity, String duedate) {
        dbController.InsertData(name, quantity, duedate);
        ingredientList = dbController.getAllIngredients();
        adapter = new IngredientListAdapter(context, ingredientList);
        gridvsample.setAdapter(adapter);
    }
}
