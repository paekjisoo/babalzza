/*
찢는건 나중에, 우선은 구현
어댑터 - 실제로 화면에 구현될 것들에 대한 것
 */

package com.example.babalzza;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.babalzza.Entity.Ingredient;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class IngredientListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Ingredient> ingredient_list;

    public IngredientListAdapter(Context context, ArrayList<Ingredient> ingredient_list) {
        this.context = context;
        this.ingredient_list = ingredient_list;
    }

    @Override
    public int getCount() {
        return ingredient_list.size();
    }

    @Override
    public Object getItem(int position) {
        return ingredient_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(context, R.layout.ingredient, null);

        ImageView ing_image = (ImageView)v.findViewById(R.id.ingredientImage);
        TextView ing_name = (TextView)v.findViewById(R.id.nameText);


        ing_name.setText(ingredient_list.get(position).getName());

        return v;
    }
}
