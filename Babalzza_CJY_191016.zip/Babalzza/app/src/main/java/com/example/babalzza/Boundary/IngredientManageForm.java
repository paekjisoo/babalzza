package com.example.babalzza.Boundary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.babalzza.Control.IngredientController;
import com.example.babalzza.Control.MyListAdapter;
import com.example.babalzza.Entity.Ingredient;
import com.example.babalzza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.util.ArrayList;

public class IngredientManageForm extends AppCompatActivity implements View.OnClickListener {

    private Animation fab_open, fab_close;
    private Boolean isFabOpen = false;
    private FloatingActionButton fab, fab1, fab2, fab3;

    SQLiteDatabase sqliteDB;

    ListView listView;
    MyListAdapter myListAdapter;
    ArrayList<Ingredient> list_itemArrayList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fridge_main);

        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.close);

        fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        fab1 = (FloatingActionButton) findViewById(R.id.createButton);
        fab2 = (FloatingActionButton) findViewById(R.id.modifyButton);
        fab3 = (FloatingActionButton) findViewById(R.id.deleteButton);

        fab.setOnClickListener(this);
        fab1.setOnClickListener(this);
        fab2.setOnClickListener(this);
        fab3.setOnClickListener(this);

        sqliteDB = init_database();
        init_tables();

        listView = (ListView)findViewById(R.id.gridview);

        list_itemArrayList = new ArrayList<Ingredient>();

        list_itemArrayList = IngredientController.readIngredient();

        myListAdapter = new MyListAdapter(this,list_itemArrayList);
        listView.setAdapter(myListAdapter);

    }

    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.floatingActionButton:
                anim();
                break;

            case R.id.createButton:
                anim();
                Toast.makeText(this, "추가", Toast.LENGTH_SHORT).show();
                Intent addintent= new Intent(IngredientManageForm.this, IngredientAdditionForm.class);
                IngredientManageForm.this.startActivity(addintent);
                break;

            case R.id.modifyButton:
                anim();

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                LayoutInflater inflater_dg = getLayoutInflater();

                final View view = inflater_dg.inflate(R.layout.fridge_change_popup, null);
                builder.setView(view);
                builder.setPositiveButton("수정", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        /*
                        nText = (EditText)view.findViewById(R.id.nameText);
                        qText = (EditText)view.findViewById(R.id.quantityText);
                        dText = (EditText)view.findViewById(R.id.duedateText);

                        name = nText.getText().toString();
                        quantity = Integer.parseInt(qText.getText().toString());
                        duedate = dText.getText().toString();

                        IngredientController.addIngredient(name, quantity, duedate);
                         */
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();
                break;

            case R.id.deleteButton:
                anim();
                Toast.makeText(this, "삭제", Toast.LENGTH_SHORT).show();
                break;
        }
    }
    // 버튼 애니메이션 효과
    public void anim() {
        if (isFabOpen) {
            fab3.startAnimation(fab_close);
            fab2.startAnimation(fab_close);
            fab1.startAnimation(fab_close);
            fab1.setClickable(false);
            fab2.setClickable(false);
            fab3.setClickable(false);
            isFabOpen = false;
        } else {
            fab3.startAnimation(fab_open);
            fab2.startAnimation(fab_open);
            fab1.startAnimation(fab_open);
            fab1.setClickable(true);
            fab2.setClickable(true);
            fab3.setClickable(true);
            isFabOpen = true;
        }
    }
    // SQLDatabase 클래스 변수 선언 및 초기화
    private SQLiteDatabase init_database() {

        SQLiteDatabase db = null ;
        // File file = getDatabasePath("contact.db") ;
        File file = new File(getFilesDir(), "contact.db") ;

        System.out.println("PATH : " + file.toString()) ;
        try {
            db = SQLiteDatabase.openOrCreateDatabase(file, null) ;
        } catch (SQLiteException e) {
            e.printStackTrace() ;
        }

        if (db == null) {
            System.out.println("DB creation failed. " + file.getAbsolutePath()) ;
        }

        return db ;
    }

    private void init_tables() {

        if (sqliteDB != null) {
            String sqlCreateTbl = "CREATE TABLE IF NOT EXISTS " + "ingredients" + "(" +
                    "USER_ID "           + "TEXT," +
                    "NAME "         + "TEXT," +
                    "QUANTITY "        + "INTEGER NOT NULL," +
                    "DUEDATE "       + "TEXT" + ")" ;

            System.out.println(sqlCreateTbl) ;

            sqliteDB.execSQL(sqlCreateTbl) ;
        }
    }

}
